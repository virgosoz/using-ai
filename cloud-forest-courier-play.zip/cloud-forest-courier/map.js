(function () {
  'use strict';
  const $=id=>document.getElementById(id);
  const firstNames=['바람숲','껍질나무 길','오래된 나무 속','구름다리','반딧불 숲','바람 협곡','폭풍 우체국','구름탑'];
  const stages=window.ForestLevels.stages,collection=window.ForestCollection;
  const desk=[[.10,.66],[.24,.46],[.39,.62],[.49,.31],[.64,.47],[.77,.24],[.88,.45],[.81,.74]];
  const mobile=[[.24,.21],[.74,.21],[.74,.40],[.24,.40],[.24,.59],[.74,.59],[.74,.78],[.24,.78]];
  function create({onPlay,onSelect}){
    let selected='1-1',currentWorld='',visibleStages=[],buttons=[],progress=window.ForestProgress.empty();
    const selectedByWorld={};
    const canvas=$('map-canvas'),ctx=canvas.getContext('2d'),nodes=$('map-nodes');
    function showWorld(id){
      currentWorld=id;visibleStages=stages.filter(stage=>stage.id.startsWith(id+'-'));
      const region=window.ForestLevels.worlds.find(world=>world.id===id);
      $('map-screen').dataset.world=id;$('world-number').textContent='WORLD 0'+id;
      $('world-title').textContent=region.title;$('region-name').textContent=region.english;
      $('region-subtitle').textContent=region.subtitle;$('world-description').textContent=region.description;
      $('world-range').textContent=`${id}-1 — ${id}-8 모두 플레이 가능`;
      $('map-legend-boss').textContent=`${id}-8 · 보스가 기다려요`;
      nodes.setAttribute('aria-label',`월드 ${id} 단계 선택`);
      document.querySelectorAll('.world-switch button[data-world]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.world===id)));
      buttons=visibleStages.map((stage,i)=>{
        const name=stage.shortName||(id==='1'?firstNames[i]:stage.name);
        const button=document.createElement('button');button.type='button';button.className='map-node'+(stage.boss?' boss-node':'');
        button.dataset.stage=stage.id;button.disabled=!stage.available;
        const ring=document.createElement('span');ring.className='map-node-ring';ring.textContent=stage.boss?'♜':stage.id;
        const label=document.createElement('span');label.className='map-node-name';label.textContent=stage.boss?stage.id+' · '+name:name;
        const status=document.createElement('span');status.className='map-node-status';
        const piece=document.createElement('span');piece.className='map-piece';
        button.append(ring,label,status,piece);
        button.addEventListener('click',()=>{select(stage.id);if(onSelect)onSelect(selected);});
        button.setAttribute('aria-label',`${stage.id} ${name}${stage.boss?' · 보스':''}`);
        return button;
      });
      nodes.replaceChildren(...buttons);
    }
    function select(id){
      selected=stages.some(stage=>stage.id===id&&stage.available)?id:'1-1';
      const regionId=selected.split('-')[0];if(regionId!==currentWorld)showWorld(regionId);
      selectedByWorld[regionId]=selected;
      if(!$('map-screen').hidden)document.title='구름숲 배달부 — '+window.ForestLevels.worlds.find(world=>world.id===regionId).title;
      updateCounts();
      buttons.forEach(button=>{
        const active=button.dataset.stage===selected;
        button.classList.toggle('selected',active);
        if(!button.disabled)button.setAttribute('aria-pressed',String(active));
      });
      const stage=stages.find(stage=>stage.id===selected),record=progress.stages[selected];
      const level=window.ForestCore.getLevel(selected);
      $('selected-number').textContent='STAGE '+selected;
      $('selected-state').textContent=record.completed?'배달 완료 ✓':stage.boss?'마지막 배달 · 보스':'배달 가능';
      $('selected-state').classList.toggle('completed',record.completed);
      $('selected-name').textContent=level.name;
      $('selected-description').textContent=level.subtitle||stage.description;
      const tags=[...(stage.tags||level.tags||[stage.description])];
      if(level.expansion||level.bossExpansion){if(!tags.includes('긴 여정')&&!tags.includes('긴 배달길'))tags.push('긴 여정');tags.push(`중간 우체국 ${(level.checkpoints||[level.checkpoint]).length}곳`);}
      $('stage-tags').replaceChildren(...tags.map(text=>{const el=document.createElement('span');el.textContent=text;return el;}));
      const piece=collection.getStagePiece(selected);
      $('selected-piece').textContent=piece?(record.stampCollected?'✦ 수집 완료':'◇ 미발견 · '+(piece.location||'숨은 길을 찾아보세요')):'이 단계에는 없어요';
      $('selected-coins').textContent=`${record.bestCoins} / ${level.totalCoins}`;
      const rooms=level.portals.map(portal=>window.ForestCore.getLevel(portal.target)).filter(Boolean);
      const bonus=rooms.some(room=>room.bonus),discovery=rooms.length>0&&!bonus;
      $('selected-extra-label').textContent=discovery?'비밀 우편실':bonus?'보너스 우체국':'가장 빠른 배달';
      $('selected-extra').textContent=discovery?(record.stampCollected?'우표 수집 완료 ✦':record.secretFound?'발견! 우표를 찾아보세요':'아직 발견 전'):bonus?(record.bonusCompleted?'도전 성공 ✦':record.secretFound?'발견! 다시 도전해요':'아직 발견 전'):record.bestTime?formatTime(record.bestTime):record.legacyBestTime?`새 코스 미기록 · 이전 ${formatTime(record.legacyBestTime)}`:'아직 기록 없음';
      $('map-play-button').firstChild.textContent=record.completed?'다시 배달하기 ':stage.boss?'보스에게 편지 전하기 ':'배달 출발 ';
      drawPreview(stage);draw();
    }
    function formatTime(seconds){const n=Math.floor(seconds);return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;}
    function drawPreview(stage){
      const c=$('preview-canvas'),p=c.getContext('2d'),rect=$('preview-art').getBoundingClientRect();
      if(!rect.width||!rect.height)return;
      const w=rect.width,h=rect.height,dpr=Math.min(window.devicePixelRatio||1,2);
      c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);p.setTransform(dpr,0,0,dpr,0,0);
      p.save();p.scale(w/1200,h/640);
      window.ForestArt.drawBackground(p,{width:1200,height:640,cameraX:300,time:0,theme:stage.theme||'forest'});p.restore();
      p.fillStyle=['cave','night','storm','tower'].includes(stage.theme)?'#83979d':'#9aaf76';p.fillRect(0,h-7,w,7);
      const portrait=w<150,level=window.ForestCore.getLevel(stage.id);
      if(!stage.boss||!portrait)window.ForestArt.drawPlayer(p,{x:portrait?w/2-14:w*.36,y:h-56,w:34,h:49,grounded:true,armored:stage.id==='1-2',powerTime:stage.id==='1-5'?window.ForestCore.BALANCE.powerDuration:0,time:0});
      if(stage.boss)window.ForestArt.drawBoss(p,{...level.boss,x:portrait?w/2-30:w*.73,y:h-59,w:60,h:52,phase:'idle',hp:level.boss.hp,maxHp:level.boss.hp,time:0});
      else if(level.items.some(item=>item.type==='armor'))window.ForestArt.drawArmorItem(p,{x:portrait?w/2:w*.78,y:portrait?h-98:h-30,time:0});
      else if(level.items.some(item=>item.type==='invincible'))window.ForestArt.drawPowerItem(p,{x:portrait?w/2:w*.79,y:portrait?h-98:h-34,time:0});
      else if(level.movingPlatforms.length)window.ForestArt.drawMovingPlatform(p,{x:portrait?16:w*.69,y:portrait?h-100:h-23,w:portrait?w-32:62,h:16,time:0,theme:stage.theme});
    }
    function draw(){
      const bounds=$('map-scene').getBoundingClientRect();if(!bounds.width||!bounds.height)return;
      const w=bounds.width,h=bounds.height,dpr=Math.min(window.devicePixelRatio||1,2),positions=w<540?mobile:desk;
      canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
      const lake=currentWorld==='2',mountain=currentWorld==='3',winter=currentWorld==='4';
      const sky=ctx.createLinearGradient(0,0,w,h);sky.addColorStop(0,winter?'#d9e9ed':mountain?'#f1dfc6':lake?'#e0ece8':'#e8efdf');sky.addColorStop(1,winter?'#c4d7e3':mountain?'#ddd3c0':lake?'#c6dedb':'#e4e9d6');ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
      ctx.fillStyle=winter?'#f0f3eb':mountain?'#cbb496':lake?'#a9cbc7':'#f4f1d9';ctx.beginPath();ctx.ellipse(w*.49,h*.52,w*.47,h*.39,-.035,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle='#f9f8e8';ctx.lineWidth=8;ctx.stroke();
      ctx.fillStyle=winter?'#b2d7df':mountain?'#e4c599':lake?'#d9e2c4':'#dce4c4';ctx.beginPath();ctx.ellipse(w*.42,h*.59,w*.27,h*.25,.2,0,Math.PI*2);ctx.fill();
      ctx.fillStyle=winter?'#c6d4e4':mountain?'#d5ac8b':lake?'#dfe7cd':'#c8d8c4';ctx.beginPath();ctx.ellipse(w*.76,h*.38,w*.17,h*.19,-.2,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle=winter?'#8fc6c9':mountain?'#efdcaa':lake?'#e5eee080':'#bfd4ca';ctx.lineWidth=w<540?20:28;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(w*.1,h*.88);ctx.bezierCurveTo(w*.5,h*.75,w*.3,h*.35,w*.9,h*.11);ctx.stroke();
      if(winter){ctx.save();ctx.globalAlpha=.45;ctx.lineWidth=13;ctx.strokeStyle='#8ebeb6';ctx.beginPath();ctx.moveTo(0,h*.12);ctx.bezierCurveTo(w*.35,-h*.02,w*.50,h*.24,w,h*.07);ctx.stroke();ctx.strokeStyle='#b7a9d0';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(0,h*.09);ctx.bezierCurveTo(w*.35,-h*.04,w*.50,h*.21,w,h*.04);ctx.stroke();ctx.restore();}
      const plants=w<540?[[.12,.09],[.84,.11],[.43,.31],[.84,.51],[.12,.49],[.44,.71],[.86,.91],[.15,.92]]:[[.06,.42],[.20,.29],[.29,.77],[.39,.31],[.56,.77],[.68,.22],[.71,.64],[.93,.70],[.60,.12]];
      for(const [x,y] of plants){const tree=winter?window.ForestArt.drawSnowTree:mountain?window.ForestArt.drawAutumnTree:window.ForestArt.drawTree;tree(ctx,w*x,h*y,.23);tree(ctx,w*x+19,h*y+10,.16);}
      function route(start,end){ctx.beginPath();const a=positions[start];ctx.moveTo(a[0]*w,a[1]*h);for(let i=start+1;i<=end;i++){const b=positions[i],prev=positions[i-1];ctx.bezierCurveTo((prev[0]+b[0])/2*w,prev[1]*h,(prev[0]+b[0])/2*w,b[1]*h,b[0]*w,b[1]*h);}ctx.stroke();}
      ctx.strokeStyle='#f9f4dc';ctx.lineWidth=14;route(0,7);
      ctx.strokeStyle='#bd9e78';ctx.lineWidth=3;ctx.setLineDash([3,7]);route(0,7);ctx.setLineDash([]);
      for(let i=1;i<8;i++)if(progress.stages[visibleStages[i-1].id].completed){ctx.strokeStyle='#88a479';ctx.lineWidth=4;route(i-1,i);}
      positions.forEach(([x,y],i)=>{buttons[i].style.left=x*100+'%';buttons[i].style.top=y*100+'%';});
      // A small envelope in the lower meadow anchors the map's courier theme.
      const ex=w<540?w*.49:w*.47,ey=h*.89;
      ctx.save();ctx.translate(ex,ey);ctx.rotate(-.13);ctx.fillStyle='#fdf9e9';ctx.fillRect(-14,-9,28,18);ctx.strokeStyle='#bba685';ctx.lineWidth=1;ctx.strokeRect(-14,-9,28,18);ctx.beginPath();ctx.moveTo(-14,-9);ctx.lineTo(0,1);ctx.lineTo(14,-9);ctx.stroke();ctx.restore();
    }
    function updateCounts(){
      const completed=visibleStages.filter(stage=>progress.stages[stage.id].completed).length;
      $('world-completed').textContent=completed;
      $('world-finale').hidden=completed!==visibleStages.length;
      $('world-finale').textContent='✉ '+window.ForestLevels.worlds.find(world=>world.id===currentWorld).ending;
      const all=collection.summarize(progress);
      $('collection-total').textContent=`전체 ${all.collected} / ${all.total} 조각`;
      collection.render($('map-collection'),progress,{world:currentWorld});
      buttons.forEach((button,i)=>{
        const record=progress.stages[button.dataset.stage],stage=visibleStages[i];
        button.classList.toggle('completed',record.completed);
        const piece=collection.getStagePiece(stage.id),badge=button.querySelector('.map-piece');
        badge.hidden=!piece;badge.textContent=record.stampCollected?'✦':'◇';
        badge.classList.toggle('found',record.stampCollected);badge.setAttribute('aria-label',record.stampCollected?'엽서 조각 수집 완료':'엽서 조각 미발견');
        button.querySelector('.map-node-status').textContent=record.completed?'배달 완료 ✓':record.bonusCompleted?'보너스 성공 ✦':record.stampCollected?'우표 발견 ✦':stage.boss?'마지막 편지 · 보스':'배달 가능';
      });
    }
    function update(next,id=selected){progress=window.ForestProgress.normalize(next);select(id);}
    document.querySelectorAll('.world-switch button[data-world]').forEach(button=>button.addEventListener('click',()=>{
      const id=button.dataset.world;
      const candidates=stages.filter(stage=>stage.id.startsWith(id+'-'));
      const next=selectedByWorld[id]||(candidates.find(stage=>!progress.stages[stage.id].completed)||candidates[0]).id;
      select(next);if(onSelect)onSelect(next);
    }));
    $('map-play-button').addEventListener('click',()=>onPlay(selected));
    new ResizeObserver(draw).observe($('map-scene'));
    new ResizeObserver(()=>drawPreview(stages.find(stage=>stage.id===selected))).observe($('preview-art'));
    return {update,draw,select};
  }
  window.ForestMap={create};
})();
