(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const core=window.ForestCore, art=window.ForestArt, records=window.ForestProgress,collection=window.ForestCollection;
  const world=new core.World(), canvas=$('game-canvas'), ctx=canvas.getContext('2d');
  const keys=new Set(), touches=new Set();
  const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fx=new window.ForestEffects.Effects({reducedMotion}), sound=new window.ForestAudio.Sound();
  let mode='map', camera=0, viewWidth=1200, scale=1, last=0, accumulator=0, clock=0, toastTimer=0, jumpQueued=false, interactQueued=false, attackQueued=false, saveTimer=0;
  let lastMeter=-1, lastProgress=-1, pausedMode='playing';
  let storage=null;
  try{storage=window.localStorage;}catch(_){}
  const loaded=records.load(storage);let progress=loaded.progress,storageAvailable=loaded.available;
  const map=window.ForestMap.create({onPlay:start,onSelect:id=>{progress.lastStage=id;storageAvailable=records.save(storage,progress);saveStatus();}});
  function saveProgress(){
    progress=records.record(progress,world);
    storageAvailable=records.save(storage,progress);saveTimer=0;saveStatus();
  }
  function saveStatus(){
    $('save-status').textContent=storageAvailable?'이 브라우저에 탐험 기록을 저장해요.':'저장을 사용할 수 없어 이번 방문 동안 기록해요.';
  }
  function cameraTarget(){return world.width<viewWidth?(world.width-viewWidth)/2:Math.max(0,Math.min(world.width-viewWidth,world.player.x-viewWidth*.32));}
  function resize() {
    const rect=canvas.getBoundingClientRect(), dpr=Math.min(window.devicePixelRatio||1,2);
    if(rect.width<=0||rect.height<=0)return;
    canvas.width=Math.round(rect.width*dpr); canvas.height=Math.round(rect.height*dpr);
    scale=canvas.height/640; viewWidth=canvas.width/scale;
    camera=cameraTarget();
  }
  new ResizeObserver(resize).observe(canvas); resize();
  function rounded(x,y,w,h,r,fill) {
    ctx.fillStyle=fill; ctx.beginPath(); ctx.roundRect(x,y,w,h,r); ctx.fill();
  }
  function updateAudioButton() {
    $('sound-label').textContent=sound.enabled?'소리 켜짐':'소리 꺼짐';
    $('sound-button').setAttribute('aria-pressed',String(sound.enabled));
    $('sound-button').setAttribute('aria-label',sound.enabled?'소리 끄기':'소리 켜기');
  }
  function pulse(id,amount=1.18){
    const element=$(id);
    if(reducedMotion||!element.animate)return;
    element.getAnimations().forEach(animation=>animation.cancel());
    element.animate([{transform:'scale(1)'},{transform:`scale(${amount})`,offset:.3},{transform:'scale(1)'}],{duration:350,easing:'ease-out'});
  }
  function resetPresentation(){
    fx.reset();sound.stop();$('finish-skip').hidden=true;
    $('effect-announcement').textContent='';document.querySelector('.game-shell').classList.remove('celebrating');
    ['coin-count','chapter-number','stamp-badge','result-coins'].forEach(id=>$(id).getAnimations?.().forEach(animation=>animation.cancel()));
  }
  function clearInputs() {keys.clear();touches.clear();world.jumpWasDown=false;world.interactWasDown=false;jumpQueued=false;interactQueued=false;attackQueued=false;}
  function showPanel(name) {
    $('overlay').hidden=!name;
    ['pause','win'].forEach(id=>$(id+'-panel').hidden=id!==name);
    if(name)$('portal-button').hidden=true;
  }
  function toast(text,duration=3.5) {
    $('toast').textContent=text; $('toast').classList.add('visible'); toastTimer=duration;
  }
  function start(stageId=world.stageId) {
    if(typeof stageId!=='string')stageId=world.stageId;
    if(mode!=='map')saveProgress();
    world.reset(stageId);camera=0;resetPresentation();mode='playing';accumulator=0;clearInputs();
    $('map-screen').hidden=true;$('play-screen').hidden=false;$('header-map-button').hidden=false;
    $('coin-total').textContent=`/ ${world.totalCoins}`;$('chapter-number').textContent=world.stageId;
    lastMeter=-1;lastProgress=-1;resize();
    showPanel(null);$('pause-button').disabled=false;$('pause-button').setAttribute('aria-label','일시정지');
    document.activeElement?.blur();
    toast(world.level.hint||(world.stageId==='1-2'?'껍질 도토리로 변신! 금 간 벽에 달려가 보세요.':'← → 이동 · Space 점프 · 공중에서 꾹 누르면 활공'),5);
    sound.resume();sound.play('start');updateAudioButton();updateHUD();saveProgress();
    document.title=`구름숲 배달부 — ${world.stageId} ${world.level.name}`;
    $('play-screen').scrollIntoView({block:'nearest'});
  }
  function openMap(){
    if(mode!=='map')saveProgress();
    mode='map';clearInputs();resetPresentation();toastTimer=0;$('toast').classList.remove('visible');
    showPanel(null);$('play-screen').hidden=true;$('map-screen').hidden=false;$('header-map-button').hidden=true;
    map.update(progress,progress.lastStage);saveStatus();
    $('map-screen').scrollIntoView({block:'nearest'});$('map-play-button').focus({preventScroll:true});
  }
  function pause() {
    if(mode!=='playing'&&mode!=='celebrating') return;
    pausedMode=mode;mode='paused';clearInputs();sound.stop();$('finish-skip').hidden=true;
    showPanel('pause');$('pause-button').setAttribute('aria-label','계속하기');$('resume-button').focus();
  }
  function resume() {
    if(mode!=='paused') return;
    mode=pausedMode;accumulator=0;clearInputs();showPanel(null);sound.resume();
    $('finish-skip').hidden=mode!=='celebrating';$('pause-button').setAttribute('aria-label','일시정지');document.activeElement?.blur();
  }
  $('restart-button').addEventListener('click',start);
  $('replay-button').addEventListener('click',start);
  $('resume-button').addEventListener('click',resume);
  $('finish-skip').addEventListener('click',showResults);
  $('next-stage-button').addEventListener('click',()=>{const next=nextStage();if(next)start(next);});
  document.querySelectorAll('[data-map]').forEach(button=>button.addEventListener('click',openMap));
  $('portal-button').addEventListener('click',()=>{if(mode==='playing'){interactQueued=true;document.activeElement?.blur();}});
  $('pause-button').addEventListener('click',()=>mode==='paused'?resume():pause());
  $('sound-button').addEventListener('click',()=>{sound.setEnabled(!sound.enabled);updateAudioButton();if(sound.enabled)sound.play('coin');});
  const leftCodes=['ArrowLeft','KeyA'], rightCodes=['ArrowRight','KeyD'], jumpCodes=['Space','ArrowUp','KeyW'];
  const interactCodes=['KeyE','ArrowDown'],attackCodes=['KeyX','KeyJ'];
  const movementCodes=[...leftCodes,...rightCodes,...jumpCodes,...interactCodes,...attackCodes];
  document.addEventListener('keydown',e=>{
    if(e.metaKey||e.ctrlKey||e.altKey) return;
    if(e.code==='Escape'||e.code==='KeyP') {if(!e.repeat){if(mode==='playing'||mode==='celebrating')pause();else if(mode==='paused')resume();}return;}
    if(e.code==='KeyR'&&!e.repeat&&mode!=='map') {start();return;}
    if(mode==='celebrating'&&!e.repeat&&(e.code==='Enter'||e.code==='Space')){e.preventDefault();showResults();return;}
    if(mode!=='playing') return;
    if(movementCodes.includes(e.code)) {e.preventDefault();keys.add(e.code);if(jumpCodes.includes(e.code)&&!e.repeat)jumpQueued=true;if(interactCodes.includes(e.code)&&!e.repeat)interactQueued=true;if(attackCodes.includes(e.code)&&!e.repeat)attackQueued=true;}
  });
  document.addEventListener('keyup',e=>{keys.delete(e.code);if(mode==='playing'&&movementCodes.includes(e.code))e.preventDefault();});
  document.querySelectorAll('[data-control]').forEach(button=>{
    const control=button.dataset.control;
    button.addEventListener('pointerdown',e=>{e.preventDefault();if(mode!=='playing')return;button.setPointerCapture(e.pointerId);touches.add(control);if(control==='jump')jumpQueued=true;if(control==='attack')attackQueued=true;});
    ['pointerup','pointercancel','lostpointercapture'].forEach(type=>button.addEventListener(type,()=>touches.delete(control)));
  });
  window.addEventListener('blur',pause);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){if(mode!=='map')saveProgress();pause();}});
  window.addEventListener('pagehide',()=>{if(mode!=='map')saveProgress();});
  const pressed=(codes,touch)=>codes.some(code=>keys.has(code))||touches.has(touch);
  function nextStage(){const [region,n]=world.stageId.split('-').map(Number);const next=n<8?`${region}-${n+1}`:`${region+1}-1`;return core.getLevel(next)?next:null;}
  const turtle=()=>world.boss?.kind==='turtle',fox=()=>world.boss?.kind==='fox',bear=()=>world.boss?.kind==='bear';
  function beginFinish(){
    mode='celebrating';clearInputs();showPanel(null);$('finish-skip').hidden=false;
    document.querySelector('.game-shell').classList.add('celebrating');
    $('result-coins').textContent=`${world.collected} / ${world.totalCoins}`;
    $('win-copy').textContent=`${world.stageId} · ${core.getLevel(world.stageId).name} 배달 완료!`;
    $('win-title').textContent=world.stageId==='4-8'?'설원에 오로라가 피었어요!':world.stageId==='3-8'?'시계탑에 새벽이 왔어요!':world.stageId==='2-8'?'호수에 다시 물결이!':world.stageId==='1-8'?'구름숲에 다시 햇살이!':'마음까지 잘 도착했어요.';
    $('next-stage-button').hidden=!nextStage();
    if(nextStage())$('next-stage-button').firstChild.textContent=`${nextStage()} · 다음 편지 배달하기 `;
    const sec=Math.floor(world.elapsed);$('result-time').textContent=`${Math.floor(sec/60)}:${String(sec%60).padStart(2,'0')}`;
    $('result-note').textContent=world.stageId==='4-8'?'서리 왕곰에게 따뜻한 편지가 도착했어요. 네 세계의 엽서를 모아 여행을 간직해 보세요.':world.stageId==='3-8'?'시계탑에 새벽이 밝았어요. 이제 오로라 설원으로 네 번째 여행을 떠나요.':world.stageId==='2-8'?'호수에 편지가 모두 도착했어요. 이제 노을 태엽산으로 새 여행을 떠나요.':world.stageId==='1-8'?'폭풍 부엉이도 편지를 받고 잠들었어요. 이제 물안개 호수로 새 편지를 전하러 가요.':world.bonusCompleted?'보너스 우체국의 도토리 도전도 성공했어요!':world.stampCollected?'이 길의 기념 우표도 함께 간직했어요.':world.retries?`${world.retries}번 다시 일어나 끝까지 도착했어요.`:'한 번도 넘어지지 않은 멋진 배달이었어요.';
    $('effect-announcement').textContent='배달 완료! 편지가 무사히 도착했어요.';
    saveProgress();updateResultCollection();$('toast').classList.remove('visible');toastTimer=0;
  }
  function updateResultCollection(){
    const piece=collection.getStagePiece(world.stageId),summary=collection.summarize(progress,world.stageId.split('-')[0]);
    const found=!!progress.stages[world.stageId].stampCollected;
    $('result-piece').textContent=world.stampCollected?'✦ 이번 배달에서 엽서 조각 수집!':piece?(found?'✦ 이 단계의 조각은 이미 간직했어요':'◇ 이 단계에 놓친 조각이 있어요'):'이 단계에는 엽서 조각이 없어요';
    $('result-collection-count').textContent=summary.complete?`${summary.collected} / ${summary.total} · ${summary.rewardTitle} 완성!`:`월드 ${world.stageId.split('-')[0]} · ${summary.collected} / ${summary.total} 조각 · 앞으로 ${summary.remaining}개`;
    collection.render($('result-puzzle'),progress,{world:world.stageId.split('-')[0],compact:true});
  }
  function showResults(){
    if(mode!=='celebrating')return;
    mode='won';clearInputs();resetPresentation();
    showPanel('win');$('pause-button').disabled=true;
    (nextStage()?$('next-stage-button'):$('win-panel').querySelector('[data-map]')).focus();pulse('result-coins',1.12);
  }
  function events() {
    for(const event of world.events.splice(0)) {
      if(['secretEnter','secretExit','respawn'].includes(event.type))fx.reset();
      const point={x:world.player.x+world.player.w/2,y:Math.max(55,Math.min(575,world.player.y+world.player.h/2)),...event};
      if(event.type==='checkpoint'){const saved=event.point||world.activeCheckpoint||world.level.checkpoint;point.x=saved.flagX;point.y=saved.y-39;}
      if(event.type==='bossDefeated'&&turtle())point.message='호수의 봉인이 풀렸어요!';
      if(event.type==='bossDefeated'&&fox())point.message='멈췄던 시계가 다시 움직여요!';
      if(event.type==='bossDefeated'&&bear())point.message='설원에 오로라가 피었어요!';
      fx.emit(event.type,point);
      const cue={powerStart:'transform',powerHit:'stomp',powerEnd:'secretExit',bossStart:'secretEnter',bossAttack:'break',bossSlam:'break',bossHit:'armorLost',bossGuard:'coin',bossDefeated:'win',bonusComplete:'stamp',bonusTimeout:'secretExit'};
      if(!(event.type==='bossAttack'&&['turtle','fox','bear'].includes(event.kind)))sound.play(cue[event.type]||event.type);
      if(event.type==='coin'){pulse('coin-count',1.22);if(!saveTimer)saveTimer=.8;}
      if(event.type==='transform'){
        toast('갑옷 다람쥐! 속도를 내서 금 간 벽을 부숴보세요.',4);
        $('effect-announcement').textContent='갑옷 변신!';pulse('chapter-number',1.3);
      }
      if(event.type==='armorLost'){
        toast('갑옷이 편지를 지켰어요. 껍질 도토리를 다시 찾아보세요.',3);
        $('effect-announcement').textContent='갑옷이 깨져 작은 배달부로 돌아왔어요.';
      }
      if(event.type==='break')toast(world.portals.some(portal=>portal.lockedBy&&portal.unlocked)?'벽 뒤에 문이 있어요! 문 앞에서 E 또는 ↓':'쿵! 막힌 길을 열었어요. 배달을 이어가요!',4);
      if(event.type==='secretEnter'||event.type==='secretExit'){
        camera=cameraTarget();
        toast(event.type==='secretEnter'?(world.bonus?`보너스 우체국! ${world.bonus.target}개의 도토리를 시간 안에 모아보세요.`:'비밀 우편실 발견! 위쪽의 기념 우표를 찾아보세요.'):'길로 돌아왔어요. 배달을 이어가 볼까요?',4);
        saveProgress();
      }
      if(event.type==='stamp'){saveProgress();const album=collection.summarize(progress,world.stageId.split('-')[0]);toast(album.complete?`${album.rewardTitle} 완성! 지도에서 엽서를 확인하세요.`:`엽서 조각 수집! ${album.collected} / ${album.total} · 앞으로 ${album.remaining}개`,4);pulse('stamp-badge',1.4);}
      if(event.type==='weaponPickup'){toast('불꽃 솔방울! X / J로 발사 · 가까이 다가가 충전 간격에 맞춰 쏘세요.',5);$('effect-announcement').textContent='파이어볼을 사용할 수 있어요.';}
      if(event.type==='weaponLost')toast('불꽃이 꺼졌어요. 솔방울은 잠시 후 다시 나타나요.',3);
      if(event.type==='death')toast(event.reason==='fall'?'괜찮아요, 편지는 무사해요. 다시 출발!':event.reason==='boss'?(bear()?'파동은 점프, 고드름은 파란 표시 밖으로! 금빛 왕관이 뜨면 공격하세요.':fox()?'낮은 톱니는 점프, 높은 톱니는 땅에서 피하세요. 금빛 고리가 뜨면 공격!':turtle()?'충격파는 점프로! 쉬는 동안 금빛 껍질을 밟거나 불꽃을 쏘세요.':'돌진을 피하고, 지쳤을 때 머리 위로 점프!'):'작은 숲 친구들을 뛰어넘어 보세요. 다시 출발!',2.5);
      if(event.type==='powerStart')toast(`별빛 무적! ${core.BALANCE.powerDuration}초 동안 적에게 닿아도 괜찮아요. 낭떠러지는 조심!`,4);
      if(event.type==='powerEnd')toast('별빛이 잦아들었어요. 다시 조심조심!',2);
      if(event.type==='bonusComplete'){toast('보너스 성공! 남은 도토리와 우표도 모은 뒤 문으로 돌아가세요.',4);saveProgress();}
      if(event.type==='bonusTimeout')toast('시간 끝! 모은 도토리는 모두 가져왔어요.',4);
      if(event.type==='bonusClosed')toast('이번 도전은 끝났어요. 단계 재시작으로 다시 도전할 수 있어요.',3);
      if(event.type==='bossStart')toast(bear()?'서리 왕곰! 파동은 점프, 파란 고드름 표시는 옆으로 피한 뒤 금빛 왕관을 공격하세요.':fox()?'태엽 여우! 낮은 톱니는 점프, 높은 톱니는 땅에서 피한 뒤 금빛 약점을 공격하세요.':turtle()?'이끼 왕거북! 충격파를 넘고, 쉬는 동안 금빛 껍질을 밟거나 불꽃을 쏘세요.':'폭풍 부엉이! 돌진 뒤 금빛 고리가 뜨면 머리를 밟으세요.',5);
      if(event.type==='bossGuard')toast(bear()?'얼음 왕관이 단단해요! 공격을 피한 뒤 금빛 고리가 열릴 때 공격하세요.':fox()?'태엽을 돌릴 때는 단단해요. 금빛 고리가 뜰 때 불꽃이나 점프로 공격하세요.':turtle()?'아직 단단해요! 껍질에 금빛 고리가 뜰 때 공격하세요.':'아직 힘이 넘쳐요! 머리에 금빛 고리가 뜰 때 공격하세요.',2);
      if(event.type==='bossHit')pulse('encounter-value',1.3);
      if(event.type==='bossDefeated')toast(bear()?'설원에 오로라가 피었어요! 오른쪽 우편함에 따뜻한 편지를 전하세요.':fox()?'시계가 다시 움직여요! 오른쪽 우편함에 새벽의 편지를 전하세요.':turtle()?'호수의 봉인이 풀렸어요! 오른쪽 우편함으로 가세요.':'폭풍이 멎었어요! 오른쪽 우편함에 마지막 편지를 전하세요.',5);
      if(event.type==='respawn') camera=cameraTarget();
      if(event.type==='checkpoint')toast(`중간 우체국 ${world.checkpointIndex+1} 도착! 실패하면 여기서 다시 출발해요.`,4);
      if(event.type==='win')beginFinish();
    }
  }
  function updateHUD() {
    $('coin-count').textContent=String(world.collected).padStart(2,'0');
    const leaf=Math.round(world.player.glide/.8*100);
    if(lastMeter!==leaf) {$('glide-meter').firstElementChild.style.transform=`scaleX(${leaf/100})`;$('glide-meter').setAttribute('aria-valuenow',leaf);lastMeter=leaf;}
    const main=core.getLevel(world.stageId),inSecret=world.sceneId!==world.stageId;
    const position=inSecret?(world.returnSpawn?.x||100):world.player.x;
    const route=Math.round(Math.max(0,Math.min(100,(position-main.spawn.x)/(main.finish-main.spawn.x)*100)));
    if(lastProgress!==route) {$('route-progress').style.width=route+'%';document.querySelector('.route-track').setAttribute('aria-valuenow',route);lastProgress=route;}
    const points=main.checkpoints||[main.checkpoint].filter(Boolean);
    const nextPoint=points[Math.min(world.checkpointIndex+1,points.length-1)];
    $('route-label').textContent=inSecret?world.level.name:world.checkpoint?`우체국 ${world.checkpointIndex+1} / ${points.length} 저장`:'출발 우체국';
    $('checkpoint-tick').hidden=!nextPoint;
    if(nextPoint)$('checkpoint-tick').style.left=((nextPoint.triggerX-main.spawn.x)/(main.finish-main.spawn.x)*100)+'%';
    const x=world.player.x;
    $('area-name').textContent=world.level.areas.filter(a=>a.x<=x).slice(-1)[0]?.name||world.level.name;
    $('form-label').textContent=world.player.powerTime>0?`별빛 무적 · ${Math.ceil(world.player.powerTime)}초`:world.player.armored?'갑옷 다람쥐 · 벽을 향해 달리기':'잎사귀 배달부';
    document.querySelector('.chapter').classList.toggle('armored',world.player.armored);
    document.querySelector('.game-shell').classList.toggle('secret',!world.boss?.defeated&&(inSecret||['cave','night','storm','tower','crystal','mist','sanctuary','workshop','starmine','observatory','clockhall','clocktower','icecave','aurora','blizzard','polarpalace'].includes(world.level.theme)));
    $('stamp-badge').hidden=!(main.stamps.length||main.portals.some(portal=>core.getLevel(portal.target)?.stamps.length));$('stamp-badge').classList.toggle('collected',world.stampCollected);
    const pieceOwned=!!progress.stages[world.stageId].stampCollected;
    $('stamp-badge').textContent=pieceOwned?'✦':'✧';$('stamp-badge').setAttribute('aria-label',pieceOwned?'엽서 조각 수집 완료':'엽서 조각 미발견');
    $('stamp-badge').classList.toggle('collected',pieceOwned);
    $('ice-status').hidden=!world.player.onIce;
    const armed=world.player.weapon==='fire';
    const charging=armed&&world.player.fireCooldown>0;
    const fireCharge=armed?Math.round(Math.max(0,Math.min(1,1-world.player.fireCooldown/core.BALANCE.fireCooldown))*100):0;
    $('weapon-status').textContent=armed?(charging?'불꽃 충전 · X / J':'불꽃 준비 · X / J 발사'):'불꽃 솔방울을 찾아보세요';
    $('weapon-status').classList.toggle('ready',armed);
    $('weapon-status').style.backgroundSize=`${fireCharge}% 3px`;
    $('jump-status').textContent=world.player.grounded?'2단 점프 준비':world.player.doubleJumpReady?'공중 점프 1회':'착지하면 점프 충전';
    $('attack-button').classList.toggle('ready',armed);$('attack-button').setAttribute('aria-disabled',String(!armed));
    $('attack-button').querySelector('span').textContent=armed?(charging?'충전 중':'꾹 · 연사'):'아이템 필요';
    $('portal-button').hidden=mode!=='playing'||!world.nearPortal;
    if(world.nearPortal)$('portal-label').textContent=world.nearPortal.label;
    $('play-hint').textContent=world.level.hint||(inSecret?'우표를 찾았다면 문으로 돌아가세요.':world.stageId==='1-2'?'갑옷으로 금 간 벽을 부수면 비밀길이 열려요.':'조금 떨어져도 괜찮아요. 다시 뛰면 되니까.');
    const boss=world.boss,bonus=world.bonus,encounter=!!bonus||!!(boss&&boss.active&&!boss.defeated);
    $('encounter-hud').hidden=!encounter||mode==='celebrating'||mode==='won';
    document.querySelector('.game-shell').classList.toggle('has-encounter',encounter);
    if(bonus){
      $('encounter-title').textContent=bonus.completed?'보너스 성공!':'보너스 우체국';
      $('encounter-value').textContent=`${bonus.collected} / ${bonus.target} · ${Math.ceil(bonus.remaining)}초`;
      $('encounter-hint').textContent=bonus.completed?'문으로 돌아가 배달을 이어가요':'시간 안에 도토리를 모아요';
    }else if(encounter){
      $('encounter-title').textContent=boss.name||(turtle()?'이끼 왕거북':'폭풍 부엉이');$('encounter-value').textContent='♥'.repeat(boss.hp)+'♡'.repeat(boss.maxHp-boss.hp);
      $('encounter-hint').textContent=bear()?(boss.phase==='recovery'?'지금! 금빛 왕관을 밟거나 불꽃 발사':boss.phase==='hurt'?'명중! 남은 얼음 공격도 피하세요':boss.attackType==='icicle'?(boss.phase==='windup'?'고드름 준비 · 파란 표시 밖으로 이동!':'고드름 낙하! 표시된 자리에서 벗어나세요'):boss.phase==='windup'?'얼음 파동 준비 · 내려찍는 순간 점프!':'얼음 파동! 점프해서 넘으세요'):fox()?(boss.phase==='recovery'?'톱니가 지나가면 금빛 약점을 공격하세요!':boss.phase==='hurt'?'명중! 남은 톱니도 피하세요':boss.volleyHeight==='high'?'높은 톱니 · 땅에서 지나가길 기다리세요':boss.phase==='windup'?'낮은 톱니 준비 · 발사되면 점프!':'낮은 톱니 발사! 지금 점프하세요'):turtle()?(boss.phase==='recovery'?'지금! 금빛 껍질을 밟거나 불꽃을 쏘세요':boss.phase==='windup'?'충격파 준비 · 내려찍는 순간 점프!':boss.phase==='slam'?'충격파! 점프해서 넘으세요':'명중! 남은 충격파도 피하세요'):(boss.phase==='recovery'?'지금! 금빛 머리를 밟거나 불꽃을 쏘세요':boss.phase==='windup'?'돌진 준비 · 다가오면 점프!':boss.phase==='hurt'?'명중! 남은 깃털도 피하세요':'돌진을 피하고 틈을 기다려요');
    }
  }
  function drawTerrain(block) {
    const {x,y,w,h}=block;
    if(world.stageId.startsWith('4-')){art.drawSnowPlatform(ctx,{...block,time:reducedMotion?0:clock,theme:world.level.theme});return;}
    if(block.moving){art.drawMovingPlatform(ctx,{...block,time:reducedMotion?0:clock,theme:world.level.theme});return;}
    const palette={cave:['#7c6654','#a08a68','#8aab8b'],clouds:['#b4c3b6','#d3d8c1','#a5c4b9'],night:['#5e6f7a','#819591','#a6c7a3'],canyon:['#b29278','#d2b497','#b6bf91'],storm:['#747a87','#9aa3a4','#b9c6ac'],tower:['#747b93','#a0a7b2','#d8c99d'],lakeside:['#8caa99','#c0ccb0','#b8dbad'],waterworks:['#927a60','#c1a987','#ddd6ab'],mushrooms:['#98788a','#c7aab2','#e2d29d'],crystal:['#596b8c','#8496b0','#a6d6d0'],ruins:['#819282','#aeb79b','#bcd19b'],mist:['#5f7e80','#8ca5a0','#bddac1'],aqueduct:['#8c9991','#b8c7b6','#e4dfb7'],sanctuary:['#576e78','#8aa7a6','#d7d8ac'],sunset:['#a28368','#c7a984','#d7c98b'],windmill:['#9e8c65','#c5b38a','#dacb96'],workshop:['#716961','#a9977c','#d5ba87'],starmine:['#615b79','#8d849b','#c9b9a0'],railway:['#857665','#b9a38b','#ddc090'],observatory:['#686d8c','#999eb0','#ddd1b1'],clockhall:['#776d7b','#a4949b','#d9bd8c'],clocktower:['#78747f','#a99c9b','#e5c99a']}[world.level.theme];
    if(palette){
      rounded(x,y,w,h,5,palette[0]);ctx.fillStyle=palette[1];ctx.fillRect(x+3,y+12,w-6,Math.max(0,h-15));rounded(x-2,y-3,w+4,12,4,palette[2]);
      ctx.strokeStyle=palette[0];ctx.lineWidth=1;for(let i=32;i<w;i+=66){ctx.beginPath();ctx.moveTo(x+i,y+16);ctx.lineTo(x+i,y+Math.min(h,40));ctx.stroke();}
      if(block.belt)art.drawConveyor(ctx,{...block,time:reducedMotion?0:clock});return;
    }
    rounded(x,y,w,h,6,'#bba87d');
    ctx.fillStyle='#cbb996';ctx.fillRect(x+3,y+12,w-6,Math.max(0,h-15));
    if(h>50) {ctx.fillStyle='#baa680';for(let i=24;i<w-15;i+=63){const yy=y+35+(i*7%37);ctx.beginPath();ctx.ellipse(x+i,yy,3,2,.3,0,Math.PI*2);ctx.fill();}}
    const secret=world.level.theme==='secret',amber=world.level.theme==='amber';
    rounded(x-2,y-3,w+4,14,5,secret?'#a17b4b':amber?'#9caa57':'#6f965e');
    ctx.fillStyle=secret?'#d6b278':amber?'#c6c779':'#bad292';ctx.fillRect(x+3,y-2,w-6,4);
    ctx.strokeStyle='#94ac76';ctx.lineWidth=1.5;
    for(let i=17;i<w-12;i+=51){ctx.beginPath();ctx.moveTo(x+i,y);ctx.lineTo(x+i-2,y-6);ctx.moveTo(x+i,y);ctx.lineTo(x+i+4,y-5);ctx.stroke();}
    if(h<30){ctx.fillStyle='#a08f66';ctx.beginPath();ctx.moveTo(x+20,y+h);ctx.lineTo(x+w*.4,y+h+13);ctx.lineTo(x+w-22,y+h);ctx.fill();}
  }
  function acorn(x,y,t) {
    ctx.save();ctx.translate(x,y+Math.sin(t*2+x*.07)*3);ctx.rotate(.18);
    ctx.fillStyle='#d5a35d';ctx.beginPath();ctx.ellipse(0,2,7,9,0,0,Math.PI*2);ctx.fill();
    rounded(-9,-6,18,7,4,'#927952');ctx.strokeStyle='#806c4c';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,-6);ctx.quadraticCurveTo(-1,-12,3,-13);ctx.stroke();
    ctx.fillStyle='#eed296';ctx.beginPath();ctx.ellipse(-2,2,1.5,4,-.2,0,Math.PI*2);ctx.fill();ctx.restore();
  }
  function mailbox(x,y,finished=false) {
    ctx.fillStyle='#947953';ctx.fillRect(x-5,y-82,10,82);
    rounded(x-26,y-111,52,39,9,finished?'#d27f5b':'#90a77c');
    rounded(x-20,y-100,34,4,2,'#657951');
    ctx.fillStyle='#e7d3aa';ctx.fillRect(x+16,y-119,3,26);ctx.fillStyle='#d8825c';ctx.fillRect(x+19,y-119,18,12);
    ctx.fillStyle='#f3ecd4';ctx.font='9px sans-serif';ctx.textAlign='center';ctx.fillText('POST',x-1,y-82);
    if(finished){ctx.strokeStyle='#a1ae80';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y-62,66,Math.PI,0);ctx.stroke();}
  }
  function sign(x,y,text) {
    y+=60;
    ctx.font='12px -apple-system, sans-serif';ctx.textAlign='center';
    const width=ctx.measureText(text).width+24;
    ctx.fillStyle='#a89970';ctx.fillRect(x-2,y-13,4,25);
    rounded(x-width/2,y-35,width,25,4,'#ede6cd');ctx.fillStyle='#7d8464';ctx.fillText(text,x,y-18);
  }
  function checkpoint(point,index) {
    const x=point.flagX,y=point.y+46,saved=world.checkpointIndex>=index;
    ctx.fillStyle='#ad9570';ctx.fillRect(x-4,y-102,8,102);
    ctx.fillStyle=saved?'#ce825b':'#a8ba8c';
    ctx.beginPath();ctx.moveTo(x,y-103);ctx.lineTo(x+50,y-98);ctx.lineTo(x+41,y-83);ctx.lineTo(x,y-88);ctx.fill();
    rounded(x-28,y-75,56,30,4,'#f6eacc');ctx.fillStyle='#a38b65';ctx.textAlign='center';ctx.font='18px sans-serif';ctx.fillText('✉',x,y-54);
    ctx.font='12px -apple-system, sans-serif';ctx.fillStyle='#718268';ctx.fillText(saved?'여기까지 저장했어요':`중간 우체국 ${index+1}`,x,y-122);
  }
  function draw() {
    ctx.setTransform(scale,0,0,scale,0,0);ctx.clearRect(0,0,viewWidth,640);
    const t=reducedMotion?0:clock;
    art.drawBackground(ctx,{width:viewWidth,height:640,cameraX:camera,time:t,theme:world.boss?.defeated?(bear()?'aurora':fox()?'sunset':turtle()?'lakeside':'clouds'):world.level.theme});
    const shake=fx.cameraOffset();
    ctx.save();ctx.translate(-camera+shake.x,shake.y);
    for(const wind of world.level.winds||[])if(wind.x+wind.w>camera&&wind.x<camera+viewWidth)art.drawWind(ctx,{...wind,time:t});
    for(const tree of world.level.trees) if(tree.x>camera-200&&tree.x<camera+viewWidth+200)(world.stageId.startsWith('4-')?art.drawSnowTree:world.stageId.startsWith('3-')?art.drawAutumnTree:art.drawTree)(ctx,tree.x,tree.y,tree.s);
    for(const block of world.platforms) if(block.x+block.w>camera-30&&block.x<camera+viewWidth+30)drawTerrain(block);
    for(const portal of world.portals)if(portal.x>camera-100&&portal.x<camera+viewWidth+100)art.drawPortal(ctx,{...portal,time:t,active:portal.unlocked,label:portal.unlocked?portal.label:'벽 뒤의 문'});
    for(const block of world.breakables)if(!block.broken&&block.x>camera-100&&block.x<camera+viewWidth+100)art.drawBreakable(ctx,{...block,time:t});
    if(world.sceneId===world.stageId&&camera<220) mailbox(75,515);
    const points=world.level.checkpoints||[world.level.checkpoint].filter(Boolean);
    points.forEach((point,index)=>{if(camera<point.flagX+100&&camera+viewWidth>point.flagX-100)checkpoint(point,index);});
    if(world.finish!==null&&camera+viewWidth>world.finish-100) {mailbox(world.finish+50,515,true);sign(world.finish+145,503,'배달 도착!');}
    for(const [x,y,text] of world.level.signs) if(x>camera-220&&x<camera+viewWidth+220)sign(x,y,text);
    for(const coin of world.coins)if(!coin.taken&&coin.x>camera-15&&coin.x<camera+viewWidth+15)acorn(coin.x,coin.y,t);
    for(const enemy of world.enemies)if(enemy.alive&&enemy.x>camera-60&&enemy.x<camera+viewWidth+60)art.drawEnemy(ctx,{...enemy,time:t});
    for(const item of world.items)if(!item.taken&&item.x>camera-40&&item.x<camera+viewWidth+40)(item.type==='fire'?art.drawFireItem:item.type==='invincible'?art.drawPowerItem:art.drawArmorItem)(ctx,{...item,time:t});
    for(const stamp of world.stamps)if(!stamp.taken)art.drawStamp(ctx,{...stamp,time:t});
    for(const spring of world.springs||[])if(spring.x+spring.w>camera&&spring.x<camera+viewWidth)art.drawSpring(ctx,{...spring,time:t});
    if(world.boss){
      art.drawBoss(ctx,{...world.boss,time:t});
      for(const feather of world.projectiles)art.drawProjectile(ctx,{...feather,time:t});
      if(!world.boss.defeated){
        const gx=world.bossGateX;ctx.save();ctx.globalAlpha=.55;rounded(gx,335,10,180,5,'#ead4a0');
        for(let i=0;i<5;i++){ctx.strokeStyle='#eee4c2';ctx.lineWidth=2;ctx.beginPath();ctx.arc(gx+5,350+i*33,16,0,Math.PI*2);ctx.stroke();}ctx.restore();
      }
    }
    for(const shot of world.playerProjectiles||[])art.drawFireProjectile(ctx,{...shot,time:t});
    const p=world.player;
    const pose=fx.actorPose(p),anchorX=p.x+p.w/2,anchorY=p.y+p.h;
    ctx.save();ctx.translate(anchorX,anchorY+pose.offsetY);ctx.rotate(pose.rotation);ctx.scale(pose.scaleX,pose.scaleY);ctx.translate(-anchorX,-anchorY);
    if(world.respawnTimer)ctx.globalAlpha=.4;
    art.drawPlayer(ctx,{...p,armored:pose.armored,time:t});ctx.restore();
    fx.drawWorld(ctx,{player:p,time:t});
    ctx.restore();
    if(p.gliding){ctx.fillStyle='#f4f5df';ctx.font='11px -apple-system,sans-serif';ctx.textAlign='center';const px=p.x-camera+17;rounded(px-25,p.y-56,50,4,2,'#dfe6cb');rounded(px-25,p.y-56,50*p.glide/.8,4,2,'#87a26e');}
    fx.drawScreen(ctx,{width:viewWidth,height:640,playerScreenX:p.x+p.w/2-camera,playerScreenY:p.y+p.h/2,mailboxScreenX:world.finish===null?undefined:world.finish+50-camera,mailboxScreenY:423});
  }
  function frame(now) {
    const dt=last?Math.min((now-last)/1000,.08):0;last=now;
    const wasStopped=fx.hitStopRemaining>0;
    if(mode!=='paused'&&mode!=='map'){clock+=dt;fx.update(dt);}
    if(mode==='playing') {
      // Impact pauses consume real time instead of accumulating physics catch-up.
      if(wasStopped)accumulator=0;else accumulator+=dt;
      const input={left:pressed(leftCodes,'left'),right:pressed(rightCodes,'right'),jump:false,interact:false,attack:false};
      while(accumulator>=1/120&&mode==='playing'){
        input.jump=pressed(jumpCodes,'jump')||jumpQueued;input.interact=pressed(interactCodes,'interact')||interactQueued;
        input.attack=pressed(attackCodes,'attack')||attackQueued;
        jumpQueued=false;interactQueued=false;attackQueued=false;world.step(1/120,input);events();accumulator-=1/120;
        if(fx.hitStopRemaining>0){accumulator=0;break;}
      }
      const target=cameraTarget();
      camera+=(target-camera)*(1-Math.exp(-dt*8));
      updateHUD();
      if(saveTimer>0){saveTimer-=dt;if(saveTimer<=0)saveProgress();}
    }
    if(mode==='celebrating'&&fx.finishProgress>=1)showResults();
    if(mode!=='paused'&&mode!=='map') {
      if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$('toast').classList.remove('visible');}
    }
    updateAudioButton();
    if(mode!=='map')draw();requestAnimationFrame(frame);
  }
  map.update(progress,progress.lastStage);saveStatus();requestAnimationFrame(frame);
})();
