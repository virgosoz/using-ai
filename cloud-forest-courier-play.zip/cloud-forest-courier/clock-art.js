/* Brass, autumn leaves and the first light over the clockwork highlands. */
(function(){
  'use strict';
  const base=window.ForestArt,TAU=Math.PI*2;
  const palettes={sunset:['#e4baaa','#f7e3b1','#b58d88'],windmill:['#c6cfbb','#f4dcac','#9caa8b'],workshop:['#73666a','#d7b88e','#8e7c79'],starmine:['#302e52','#797698','#636587'],railway:['#d2b6ae','#e6d3ad','#9a8992'],observatory:['#333a5c','#a3a4b7','#666d8b'],clockhall:['#4d4a5c','#b5a49e','#797183'],clocktower:['#42485f','#d3b8a0','#797c99']};
  function oval(c,x,y,rx,ry,color){c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.fill();}
  function box(c,x,y,w,h,r,color){c.fillStyle=color;c.beginPath();c.roundRect(x,y,w,h,r);c.fill();}
  function gear(c,x,y,r,t,color='#c5a875'){
    c.save();c.translate(x,y);c.rotate(t);c.fillStyle=color;c.strokeStyle='#786951';c.lineWidth=Math.max(1,r*.05);
    c.beginPath();for(let i=0;i<48;i++){const a=i*TAU/48,rr=r*(i%4<2?1:.83);c[i?'lineTo':'moveTo'](Math.cos(a)*rr,Math.sin(a)*rr);}c.closePath();c.fill();c.stroke();
    oval(c,0,0,r*.61,r*.61,'#766e61');oval(c,0,0,r*.44,r*.44,'#ddc692');
    c.strokeStyle=color;c.lineWidth=r*.13;for(let i=0;i<4;i++){const a=i*TAU/4;c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(a)*r*.68,Math.sin(a)*r*.68);c.stroke();}
    oval(c,0,0,r*.13,r*.13,'#73654e');c.restore();
  }
  function dial(c,x,y,r,t){
    oval(c,x,y,r+8,r+8,'#ad956c');oval(c,x,y,r,r,'#e8d4a4');c.strokeStyle='#8f7d60';c.lineWidth=2;
    for(let i=0;i<12;i++){const a=i*TAU/12;c.beginPath();c.moveTo(x+Math.cos(a)*r*.79,y+Math.sin(a)*r*.79);c.lineTo(x+Math.cos(a)*r*.91,y+Math.sin(a)*r*.91);c.stroke();}
    c.lineWidth=4;c.beginPath();c.moveTo(x-r*.33,y-r*.29);c.lineTo(x,y);c.lineTo(x+Math.sin(t*.2)*r*.6,y-Math.cos(t*.2)*r*.6);c.stroke();oval(c,x,y,5,5,'#a87850');
  }
  function drawAutumnTree(c,x,y,s=1){
    c.save();c.translate(x,y);c.scale(s,s);box(c,-9,-156,18,156,7,'#987456');
    c.strokeStyle='#987456';c.lineWidth=9;c.beginPath();c.moveTo(0,-65);c.lineTo(-47,-121);c.moveTo(1,-105);c.lineTo(43,-148);c.stroke();
    for(const [dx,dy,r,color] of [[-36,-148,51,'#b48468'],[18,-190,55,'#d3a06b'],[55,-144,47,'#d9b376'],[-8,-116,49,'#bd8e62']])oval(c,dx,dy,r,r*.88,color);
    oval(c,1,-207,22,12,'#e5bc80');oval(c,55,-159,18,10,'#edc994');c.restore();
  }
  function drawBackground(c,o){
    const {width:w,height:h,cameraX:cam=0,time:t=0,theme}=o,p=palettes[theme];if(!p){base.drawBackground(c,o);return;}
    const dark=['starmine','observatory','clockhall','clocktower'].includes(theme);
    c.save();const gradient=c.createLinearGradient(0,0,0,h);gradient.addColorStop(0,p[0]);gradient.addColorStop(1,p[1]);c.fillStyle=gradient;c.fillRect(0,0,w,h);
    const sx=w*.74-cam*.02%75,sy=160;const glow=c.createRadialGradient(sx,sy,12,sx,sy,175);glow.addColorStop(0,dark?'#f6e5b74a':'#fff0be88');glow.addColorStop(1,'#fff2ce00');c.fillStyle=glow;c.fillRect(sx-175,sy-175,350,350);
    if(theme!=='workshop'&&theme!=='starmine')oval(c,sx,sy,38,38,dark?'#f1e8c2':'#f5d596');
    if(dark)for(let i=0;i<38;i++){const x=((i*127-cam*.03)%(w+50)+w+50)%(w+50),y=40+(i*71)%285;c.globalAlpha=.25+Math.sin(i+t*.5)*.15;oval(c,x,y,i%4===0?2:1,1.4,'#fff0c7');}c.globalAlpha=1;
    for(let k=0;k<3;k++){
      c.globalAlpha=.25+k*.15;c.fillStyle=p[2];const span=410-k*60,off=cam*(.07+k*.08)%span;
      c.beginPath();c.moveTo(-span,h);for(let i=-1;i<w/span+2;i++){const x=i*span-off,y=330+k*76;c.lineTo(x,y+88);c.lineTo(x+span*.38,y-65);c.quadraticCurveTo(x+span*.48,y-79,x+span*.58,y-32);c.lineTo(x+span,y+92);}c.lineTo(w+span,h);c.closePath();c.fill();
    }c.globalAlpha=1;
    if(theme==='sunset'||theme==='railway')for(let i=-1;i<w/330+2;i++){c.save();c.globalAlpha=.36;drawAutumnTree(c,i*330-cam*.23%330,520,1.1);c.restore();}
    if(theme==='windmill')for(let i=-1;i<w/570+2;i++){
      const x=i*570-cam*.2%570+210,y=300;c.save();c.globalAlpha=.48;box(c,x-24,y-10,48,208,7,'#a68f70');c.fillStyle='#bd9569';c.beginPath();c.moveTo(x-38,y-13);c.lineTo(x,y-49);c.lineTo(x+38,y-13);c.closePath();c.fill();
      c.translate(x,y);c.rotate(t*.35);for(let j=0;j<4;j++){c.rotate(TAU/4);box(c,-9,-105,18,109,4,'#f0dcad');for(let n=20;n<103;n+=17){c.strokeStyle='#bda579';c.lineWidth=2;c.beginPath();c.moveTo(-9,-n);c.lineTo(9,-n);c.stroke();}}oval(c,0,0,13,13,'#9a7e58');c.restore();
    }
    if(theme==='workshop'||theme==='clockhall'){
      for(let i=-1;i<w/260+2;i++){const x=i*260-cam*.15%260;c.save();c.globalAlpha=.28;box(c,x,100,20,420,3,'#dbc29a');box(c,x-10,145,280,15,3,'#b69576');gear(c,x+114,240,72,t*(i%2?-.15:.15),'#c6a570');gear(c,x+214,342,53,t*.19,'#a58d68');c.restore();}
      if(theme==='clockhall'){c.save();c.globalAlpha=.42;dial(c,w*.62-cam*.04%140,180,71,t);c.restore();}
    }
    if(theme==='starmine')for(let i=-1;i<w/165+2;i++){
      const x=i*165-cam*.2%165,y=70+(Math.abs(i)%3)*45;c.save();c.globalAlpha=.45;c.fillStyle=i%2?'#cbb68b':'#aca3bd';c.beginPath();c.moveTo(x-25,0);c.lineTo(x+27,0);c.lineTo(x+12,y+60);c.lineTo(x-13,y+90);c.closePath();c.fill();c.strokeStyle='#f5d9aa';c.lineWidth=2;c.beginPath();c.moveTo(x,4);c.lineTo(x+4,y+50);c.stroke();gear(c,x+45,468,29,t*.12,'#bba37f');c.restore();
    }
    if(theme==='railway'){
      c.save();c.globalAlpha=.35;c.strokeStyle='#7e6c68';c.lineWidth=8;c.beginPath();c.moveTo(0,350);c.lineTo(w,350);c.moveTo(0,370);c.lineTo(w,370);c.stroke();
      for(let i=-1;i<w/150+2;i++){const x=i*150-cam*.18%150;c.beginPath();c.moveTo(x,366);c.lineTo(x,575);c.moveTo(x,381);c.lineTo(x+150,526);c.moveTo(x,526);c.lineTo(x+150,381);c.stroke();}c.restore();
    }
    if(theme==='observatory'){
      const x=w*.56-cam*.06%160;c.save();c.globalAlpha=.5;box(c,x-95,310,190,200,5,'#878b99');c.fillStyle='#aaaab2';c.beginPath();c.arc(x,310,95,Math.PI,0);c.fill();
      c.strokeStyle='#d0b891';c.lineWidth=11;c.beginPath();c.moveTo(x-34,264);c.lineTo(x+80,202);c.stroke();box(c,x-21,362,42,83,20,'#5b637f');c.restore();
      c.strokeStyle='#f3dfb74d';c.lineWidth=1;c.beginPath();for(let i=0;i<5;i++)c[i?'lineTo':'moveTo'](w*.12+i*42,110+(i%2)*33);c.stroke();
    }
    if(theme==='clocktower'){
      const x=w*.56;c.save();c.globalAlpha=.42;box(c,x-112,105,224,445,8,'#65728a');box(c,x-135,104,270,22,4,'#b69e7b');dial(c,x,235,89,t);box(c,x-27,380,54,122,26,'#bd9a75');
      for(const dx of[-83,70]){box(c,x+dx,354,16,154,4,'#a9a294');}c.restore();
      for(let i=0;i<3;i++){c.save();c.globalAlpha=.14;gear(c,75+i*(w-150)/2,530,83,t*(i%2?.16:-.16),'#e2bd7c');c.restore();}
    }
    for(let i=0;i<3;i++){const x=((i*430-cam*.06+t*5)%(w+500)+w+500)%(w+500)-250;c.globalAlpha=.09;oval(c,x,190+i*160,250,22,'#f8ead1');}c.globalAlpha=1;c.restore();
  }
  function drawConveyor(c,{x,y,w,belt,time:t=0}){
    c.save();box(c,x,y-2,w,20,7,'#736757');box(c,x+3,y,w-6,8,3,'#dbc08c');
    c.beginPath();c.rect(x+4,y,w-8,20);c.clip();const offset=((t*belt)%32+32)%32;
    for(let dx=-32;dx<w+32;dx+=32){const xx=x+dx+offset,dir=belt<0?-1:1;c.strokeStyle='#897246';c.lineWidth=2;c.beginPath();c.moveTo(xx-dir*4,y+1);c.lineTo(xx+dir*3,y+4);c.lineTo(xx-dir*4,y+7);c.stroke();}
    for(let dx=14;dx<w;dx+=54)gear(c,x+dx,y+14,5,t*belt/20,'#c1a578');c.restore();
  }
  function drawMovingPlatform(c,p){
    if(!palettes[p.theme]){base.drawMovingPlatform(c,p);return;}
    c.save();box(c,p.x,p.y,p.w,p.h,5,'#897e71');box(c,p.x+2,p.y-2,p.w-4,8,3,'#dfc593');
    for(const dx of[10,p.w-10]){oval(c,p.x+dx,p.y+13,4,4,'#e9d4aa');}c.restore();
  }
  function drawEnemy(c,e){
    if(e.kind!=='clockbug'){base.drawEnemy(c,e);return;}
    c.save();c.translate(e.x+e.w/2,e.y+e.h);c.scale(e.w/38,e.h/24);
    for(const side of[-1,1]){gear(c,side*11,-4,7,e.time*3,'#9d8766');c.strokeStyle='#7a6958';c.lineWidth=2;c.beginPath();c.moveTo(side*9,-14);c.lineTo(side*14,-25);c.stroke();oval(c,side*14,-25,3,3,'#e2c38b');}
    oval(c,0,-14,17,10,'#c69662');box(c,-12,-23,24,14,5,'#dcc091');for(const dx of[-6,6]){oval(c,dx,-17,4,4,'#faf0cd');oval(c,dx+1,-17,1.7,2,'#65584e');}c.restore();
  }
  function drawProjectile(c,p){
    if(p.kind!=='gear'){base.drawProjectile(c,p);return;}
    c.save();gear(c,p.x+p.w/2,p.y+p.h/2,p.w*.56,(p.time||0)*(p.vx<0?-8:8),'#e1ba75');c.restore();
  }
  function drawBoss(c,b){
    if(b.kind!=='fox'){base.drawBoss(c,b);return;}
    const {x,y,w=100,h=80,time:t=0,phase='idle'}=b,weak=phase==='recovery',sleep=b.defeated||phase==='defeated',dir=b.dir===1?1:-1;
    c.save();c.translate(x+w/2,y+h);c.scale(w/100,h/80);oval(c,0,-1,60,7,'#3c394033');
    c.save();c.scale(dir,1);
    c.fillStyle=b.flash>0?'#f8d6a5':'#c99661';c.strokeStyle='#826651';c.lineWidth=2;c.beginPath();c.moveTo(-20,-16);c.bezierCurveTo(-77,0,-80,-55,-55,-75);c.bezierCurveTo(-69,-41,-32,-54,-15,-31);c.closePath();c.fill();c.stroke();
    c.fillStyle='#f1d8a4';c.beginPath();c.moveTo(-55,-75);c.bezierCurveTo(-67,-58,-57,-39,-47,-37);c.lineTo(-47,-52);c.closePath();c.fill();
    for(const xx of[-21,19]){gear(c,xx,-10,13,t*.2,'#a58f6c');box(c,xx-10,-9,22,11,5,'#846b50');}
    oval(c,0,-37,32,28,b.flash>0?'#fbe0b3':sleep?'#c4ac88':'#c49462');oval(c,7,-34,18,18,'#ead3a7');gear(c,0,-37,14,t*.55,weak?'#ffe094':'#b99968');
    c.fillStyle='#ca9869';c.beginPath();c.moveTo(-16,-55);c.lineTo(-22,-93);c.lineTo(2,-73);c.lineTo(24,-91);c.lineTo(24,-58);c.closePath();c.fill();c.stroke();
    c.fillStyle='#ecbe93';c.beginPath();c.moveTo(-16,-80);c.lineTo(-11,-65);c.lineTo(-5,-73);c.moveTo(19,-78);c.lineTo(12,-67);c.lineTo(19,-64);c.fill();
    oval(c,8,-58,30,22,'#d4a16d');c.fillStyle='#f2dcac';c.beginPath();c.moveTo(-6,-58);c.lineTo(43,-47);c.lineTo(12,-38);c.closePath();c.fill();oval(c,41,-48,5,4,'#69594c');
    if(weak||sleep){c.strokeStyle='#6d594b';c.lineWidth=2;c.beginPath();c.arc(15,-61,5,0,Math.PI);c.stroke();}else{oval(c,15,-62,6,7,'#faf0d0');oval(c,17,-62,2.4,3.8,'#725c48');}
    c.strokeStyle='#8d775b';c.lineWidth=3;c.beginPath();c.moveTo(-15,-44);c.lineTo(-33,-48);c.stroke();gear(c,-39,-49,11,t,'#dabb84');c.restore();
    if(phase==='windup'){
      const yy=b.volleyHeight==='high'?-86:-12;c.strokeStyle='#f3ce92';c.lineWidth=2;c.setLineDash([6,7]);c.beginPath();c.moveTo(-220,yy);c.lineTo(200,yy);c.stroke();c.setLineDash([]);
      c.fillStyle='#ffe1a0';c.font='bold 21px sans-serif';c.textAlign='center';c.fillText(b.volleyHeight==='high'?'↑':'↓',0,-108);
    }
    if(weak){c.strokeStyle='#ffe094';c.lineWidth=3;c.beginPath();c.ellipse(0,-103,30,8,0,0,TAU);c.stroke();}
    if(sleep){c.fillStyle='#f5e6c6';c.font='16px sans-serif';c.fillText('z Z',28,-93);}
    c.restore();
  }
  window.ForestArt=Object.freeze({...base,drawBackground,drawAutumnTree,drawConveyor,drawMovingPlatform,drawEnemy,drawProjectile,drawBoss});
})();
