(function(root){
  'use strict';
  // The old entrance and arena remain recognizable. These four connecting
  // districts add a full platforming route before the final checkpoint.
  const LENGTH=8200;
  const designs=[
    {name:'성벽 오르막',ledges:[[350,450,170,65],[700,385,185,24],[1490,455,180,60]],
      gaps:[[1000,170],[1900,150]],patrols:[[730,660,850],[1400,1375,1440],[1830,1810,1850]]},
    {name:'좁은 다리 순찰로',ledges:[[360,445,165,70],[710,385,170,24],[1490,450,175,65]],
      gaps:[[1010,175],[1890,160]],patrols:[[770,680,865],[1400,1375,1440],[1830,1810,1850]]},
    {name:'높은 탑 연결길',ledges:[[350,455,175,60],[690,390,180,24],[1490,450,195,65]],
      gaps:[[1000,170],[1900,150]],patrols:[[740,670,860],[1400,1375,1440],[1830,1810,1850]]},
    {name:'마지막 수비대',ledges:[[355,450,170,65],[710,385,180,24],[1490,450,185,65]],
      gaps:[[1020,175],[1900,150]],patrols:[[770,690,870],[1400,1375,1440],[1830,1810,1850]]}
  ];
  const cuts={'1-8':1380,'2-8':1450,'3-8':1450,'4-8':1500};
  const names={1:['구름 성벽','바람 다리','하늘 탑 회랑','폭풍 수비대'],
    2:['이끼 성벽','수문 다리','호수 성소 회랑','물결 수비대'],
    3:['톱니 성벽','태엽 다리','시계 회랑','새벽 수비대'],
    4:['눈꽃 성벽','빙하 다리','오로라 회랑','북극성 수비대']};
  function shiftObject(object,cut){
    const copy={...object};
    for(const key of ['x','min','max','triggerX','maxX','flagX'])
      if(Number.isFinite(copy[key])&&copy[key]>=cut)copy[key]+=LENGTH;
    if(copy.returnSpawn)copy.returnSpawn=shiftObject(copy.returnSpawn,cut);
    return copy;
  }
  function apply(levels,stages){
    for(const stage of stages){
      const level=levels[stage.id];
      if(!level?.boss||!cuts[stage.id]||level.bossExpansion)continue;
      const cut=cuts[stage.id],world=Number(stage.id[0]);
      const original={width:level.width,finish:level.finish,bossTrigger:level.boss.triggerX,
        enemies:level.enemies.length,coins:level.coins.length};
      const entryFire=level.items.find(item=>item.type==='fire');
      level.platforms=level.platforms.flatMap(block=>{
        if(block.x<cut&&block.x+block.w>cut)return[
          {...block,w:cut-block.x},{...block,x:cut+LENGTH,w:block.x+block.w-cut}];
        return[shiftObject(block,cut)];
      });
      for(const key of ['movingPlatforms','winds','springs','coins','enemies','items','breakables','portals','stamps','trees','areas'])
        level[key]=(level[key]||[]).map(object=>shiftObject(object,cut));
      level.signs=(level.signs||[]).map(([x,...rest])=>[x>=cut?x+LENGTH:x,...rest]);
      level.boss=shiftObject(level.boss,cut);
      level.checkpoint=shiftObject(level.checkpoint,cut);
      level.checkpoints=[2170,6270].map((offset,index)=>({
        id:`${stage.id}-gauntlet-post-${index+1}`,x:cut+offset,y:469,
        triggerX:cut+offset-50,maxX:cut+offset+130,flagX:cut+offset-20
      })).concat(level.checkpoint);
      if(entryFire)level.items.push({...entryFire,id:`${stage.id}-gauntlet-entry-fire`});
      level.width+=LENGTH;level.finish+=LENGTH;
      level.bossExpansion={start:cut,length:LENGTH,originalWidth:original.width,
        originalFinish:original.finish,originalEnemyCount:original.enemies,originalCoinCount:original.coins};
      for(let index=0;index<designs.length;index++){
        const design=designs[index],base=cut+index*2050;
        const [[gapA,sizeA],[gapB,sizeB]]=design.gaps;
        const floors=[[0,515,gapA,180],[gapA+sizeA,515,gapB-gapA-sizeA,180]];
        for(const [localX,y,w,h]of floors)level.platforms.push({x:base+localX,y,w,h,
          ...(world===4&&localX>0?{ice:true}:{}),
          ...(world===3&&localX>0?{belt:index%2?-48:48}: {})});
        for(const [x,y,w,h]of design.ledges)level.platforms.push({x:base+x,y,w,h});
        for(let enemyIndex=0;enemyIndex<design.patrols.length;enemyIndex++){
          const [x,min,max]=design.patrols[enemyIndex];
          level.enemies.push({id:`${stage.id}-gauntlet-${index}-${enemyIndex}`,
            kind:world===4?(enemyIndex%2?'frostcrab':'snowbug'):world===2?'crab':'beetle',
            x:base+x,y:enemyIndex===0?design.ledges[1][1]-24:491,w:38,h:24,
            min:base+(enemyIndex===0?design.ledges[1][0]+10:min),max:base+(enemyIndex===0?design.ledges[1][0]+design.ledges[1][2]-48:max),
            speed:62+world*4+index*4+enemyIndex*3});
        }
        for(const [x,y,count]of[[395,407,3],[730,342,3],[950,409,6],[1530,407,3],[1840,408,6]])
          for(let coin=0;coin<count;coin++)level.coins.push({
            id:`${stage.id}-gauntlet-acorn-${index}-${x}-${coin}`,x:base+x+coin*36,y});
        level.trees.push({x:base+120,y:515,s:.85},{x:base+1240,y:515,s:.8});
        level.areas.push({x:base,name:names[world][index]});
        level.signs.push([base+130,504,index===0?'성벽을 넘어 보스에게! 중간 우체통에서 이어 갈 수 있어요':
          index===3?'마지막 수비대를 넘으면 보스 앞 우체통이에요':
          world===4?'얼음길에서 반대로 제동 · 틈 앞에서 점프!':
          world===3?'벨트 방향과 순찰병을 살펴보고 건너요':'높은 발판과 다리 사이를 이어서 점프!']);
      }
      // Checkpoint supplies stay on the safe, wide landing at each district.
      for(let index=0;index<2;index++){
        const point=level.checkpoints[index];
        level.items.push({id:`${stage.id}-gauntlet-armor-${index}`,type:'armor',x:point.x+50,y:475,renewable:true},
          {id:`${stage.id}-gauntlet-fire-${index}`,type:'fire',x:point.x-60,y:475,renewable:true});
      }
      level.totalCoins=level.coins.length;
      level.areas.sort((a,b)=>a.x-b.x);
      level.hint='성벽의 적과 틈을 넘어 보스에게! 세 곳의 중간 우체통에서 이어갈 수 있어요.';
      stage.tags=[...stage.tags.filter(tag=>tag!=='긴 여정'),'긴 여정'];
    }
  }
  const api={apply};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.ForestLongBoss=api;
})(typeof window!=='undefined'?window:null);
