(function (root) {
  'use strict';
  const catalogue = typeof module !== 'undefined' && module.exports ? require('./levels.js') : root.ForestLevels;
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const postcards = {
    '1': { title: '햇살이 돌아온 구름숲', caption: '편지가 닿은 숲에, 다시 따뜻한 아침이 찾아왔어요.',
      pieces: ['아침의 잎사귀', '햇살 한 조각', '멀리 보이는 구름탑', '나무 그늘의 편지', '숲의 작은 우체국', '도토리꽃 언덕'] },
    '2': { title: '물안개 너머의 호수', caption: '모든 물길이 하나로 이어지고, 호수에 새 편지가 도착했어요.',
      pieces: ['안개 걷힌 물가', '호수 위의 달빛', '버드나무의 인사', '수련 사이의 물길', '작은 배의 편지', '갈대밭의 쉼터'] },
    '3': { title: '새벽을 여는 시계탑', caption: '노을 태엽산의 시계가 다시 움직이고, 새벽의 첫 편지가 하늘을 건너요.',
      pieces: ['바람을 깨우는 풍차', '산 너머 첫 햇살', '다시 움직이는 시계', '별빛 광산의 선물', '새벽 배달부의 편지', '황금빛 능선'] },
    '4': { title: '북극성 아래 도착한 편지', caption: '얼어 있던 궁전에 따뜻한 편지가 닿고, 오로라가 설원 위로 길게 펼쳐져요.',
      pieces: ['얼음 호수의 반짝임', '밤하늘의 오로라', '북극성 궁전', '눈꽃 우체국의 인사', '설원을 건넌 편지', '눈소나무의 약속'] }
  };
  const stages = catalogue.stages.filter(stage => stage.available);
  const stageIds = new Set(stages.map(stage => stage.id));
  const worldOf = id => String(id).split('-')[0];
  const worldId = world => world === undefined || world === null ? null : String(typeof world === 'object' ? world.id : world);
  const worldDetails = id => catalogue.worlds.find(world => String(world.id) === id) || { id, name: `월드 ${id}` };

  // Follow room portals, including their return links, without assigning a
  // neighboring stage's collectible to this stage. The visited set breaks cycles.
  function findStamps(stageId) {
    const queue = [stageId], visited = new Set(), result = [];
    while (queue.length) {
      const id = queue.shift();
      if (visited.has(id)) continue;
      visited.add(id);
      if (id !== stageId && stageIds.has(id)) continue;
      const level = catalogue.get(id);
      if (!level) continue;
      for (const stamp of level.stamps || []) result.push({ sceneId: id, stampId: stamp.id });
      for (const portal of level.portals || []) if (portal.target) queue.push(portal.target);
    }
    return result;
  }

  const pieces = [];
  for (const stage of stages) {
    const locations = findStamps(stage.id);
    if (!locations.length) continue;
    const world = worldOf(stage.id), number = pieces.filter(piece => piece.world === world).length + 1;
    const postcard = postcards[world];
    const firstScene = catalogue.get(locations[0].sceneId);
    const firstStamp = (firstScene.stamps || []).find(stamp => stamp.id === locations[0].stampId);
    const area = (firstScene.areas || []).filter(item => item.x <= firstStamp.x).slice(-1)[0];
    const location = firstScene.id === stage.id ? `${area?.name || stage.name}${firstStamp.y < 330 ? ' 위쪽' : ''}` : firstScene.name;
    pieces.push({ id: stage.id, stageId: stage.id, world, worldName: worldDetails(world).name,
      stageName: stage.name, number, title: postcard?.pieces[number - 1] || `${stage.name}의 여행 퍼즐 조각`,
      location,
      rewardTitle: postcard?.title || `${worldDetails(world).name} 여행 엽서`,
      sceneIds: [...new Set(locations.map(item => item.sceneId))],
      stampIds: [...new Set(locations.map(item => item.stampId))] });
  }
  for (const piece of pieces) piece.totalWorldPieces = pieces.filter(other => other.world === piece.world).length;
  const clonePiece = piece => ({ ...piece, sceneIds: [...piece.sceneIds], stampIds: [...piece.stampIds] });

  function getPieces() { return pieces.map(clonePiece); }
  function getStagePiece(stageId) {
    const piece = pieces.find(item => item.id === stageId);
    return piece ? clonePiece(piece) : null;
  }
  function summarize(progress, world) {
    const selected = worldId(world);
    const selectedPieces = pieces.filter(piece => selected === null || piece.world === selected)
      .map(piece => ({ ...clonePiece(piece), collected: progress?.stages?.[piece.id]?.stampCollected === true }));
    const collected = selectedPieces.filter(piece => piece.collected).length;
    const complete = selectedPieces.length > 0 && collected === selectedPieces.length;
    return { world: selected, worldName: selected === null ? '전체 여행' : worldDetails(selected).name,
      collected, total: selectedPieces.length, remaining: selectedPieces.length - collected,
      complete, pieces: selectedPieces,
      noPieceStages: stages.filter(stage => (selected === null || worldOf(stage.id) === selected) && !pieces.some(piece => piece.id === stage.id))
        .map(stage => ({ id: stage.id, name: stage.name, world: worldOf(stage.id) })),
      rewardTitle: selected === null ? catalogue.worlds.map(world => world.name).join(', ')+'의 여행 엽서' : postcards[selected]?.title || `${worldDetails(selected).name} 여행 엽서`,
      rewardUnlocked: complete };
  }

  function svgNode(document, parent, name, attributes) {
    const node = document.createElementNS(SVG_NS, name);
    for (const [key, value] of Object.entries(attributes || {})) node.setAttribute(key, String(value));
    parent.appendChild(node);
    return node;
  }

  // Each collected tile reveals one crop of a single 600 × 300 illustration.
  // Local SVG geometry keeps postcards crisp, offline, and independent of assets.
  function picture(document, world, index, count) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    const columns = 3, rows = Math.ceil(count / columns), height = 300 / rows;
    svg.setAttribute('viewBox', `${index % columns * 200} ${Math.floor(index / columns) * height} 200 ${height}`);
    svg.setAttribute('preserveAspectRatio', 'xMidYMid slice');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.setAttribute('class', 'collection-piece-art');
    const add = (name, attributes, parent = svg) => svgNode(document, parent, name, attributes);
    const circle = (cx, cy, r, fill) => add('circle', { cx, cy, r, fill });
    const path = (d, fill, more = {}) => add('path', { d, fill, ...more });
    add('rect', { x: 0, y: 0, width: 600, height: 300, fill: world === '4' ? '#354b69' : world === '3' ? '#f0c8a7' : world === '2' ? '#beddd9' : '#f5e8b9' });
    if (world === '4') {
      path('M0 77 Q103 5 218 68 T424 56 T600 42 L600 81 Q515 131 420 94 T216 111 T0 116Z','#80c9c0',{opacity:.65});
      path('M0 65 Q102 18 218 79 T423 72 T600 59','none',{stroke:'#c0a8df','stroke-width':13,opacity:.6});
      for(const [x,y] of [[32,24],[120,46],[194,19],[266,48],[325,22],[378,60],[552,27]])circle(x,y,1.8,'#eef6e9');
      path('M482 16 L487 32 L502 36 L487 41 L482 57 L477 41 L462 36 L477 32Z','#fff1b5');
      path('M0 164 L88 100 L162 157 L234 93 L320 156 L387 109 L464 165 L547 111 L600 156 L600 300 L0 300Z','#8facbf');
      path('M55 124 L88 100 L119 124 L98 120 L87 134 L77 119Z M201 118 L234 93 L267 118 L244 113 L233 126 L222 112Z','#e0eef0');
      path('M0 200 Q85 165 182 201 Q295 166 401 201 Q509 173 600 198 L600 300 L0 300Z','#d8e9e9');
      path('M0 253 Q107 211 218 244 Q310 271 402 248 T600 250 L600 300 L0 300Z','#a2c8d3');
      path('M0 278 Q113 244 228 279 T467 269 T600 283','none',{stroke:'#edf5ed','stroke-width':4});
      // Three spires point to the north star above the ice palace.
      for(const [x,y,w,h] of [[421,132,39,80],[462,97,46,115],[509,142,36,70]]) {
        add('rect',{x,y,width:w,height:h,rx:3,fill:'#a8d0de'});
        path(`M${x-7} ${y} L${x+w/2} ${y-29} L${x+w+7} ${y}Z`,'#e9f3ee');
        add('rect',{x:x+8,y:y+12,width:7,height:h-20,fill:'#d9eff0'});
      }
      add('rect',{x:438,y:168,width:87,height:47,rx:4,fill:'#bce0e6'});
      add('rect',{x:471,y:175,width:24,height:40,rx:12,fill:'#7298b3'});
      circle(483,143,11,'#f5e6b4');
      for(const [x,y,s] of [[28,221,1],[171,237,.8],[356,236,.67],[552,246,.9],[593,231,.7]]) {
        add('rect',{x:x-3,y:y-30*s,width:6,height:36*s,fill:'#738f9a'});
        for(const dy of [0,18,35])path(`M${x-28*s} ${y-dy*s} L${x} ${y-(dy+45)*s} L${x+28*s} ${y-dy*s}Z`,'#5e8a94');
        for(const dy of [0,18,35])path(`M${x-20*s} ${y-(dy+13)*s} L${x} ${y-(dy+45)*s} L${x+20*s} ${y-(dy+13)*s} L${x+7*s} ${y-(dy+16)*s} L${x} ${y-(dy+11)*s}Z`,'#f0f5ed');
      }
      add('rect',{x:75,y:192,width:66,height:48,rx:3,fill:'#8fb1bb'});
      path('M65 192 L108 159 L151 192Z','#f8f5e9');
      add('rect',{x:96,y:207,width:24,height:33,rx:10,fill:'#f2daa5'});
      add('rect',{x:80,y:199,width:11,height:13,rx:2,fill:'#f6e7b6'});
      add('rect',{x:252,y:217,width:8,height:51,fill:'#8e9e9f'});
      add('rect',{x:229,y:208,width:54,height:33,rx:8,fill:'#bd7b72'});
      path('M227 210 Q229 199 245 202 L277 202 Q286 203 286 211Z','#fff8e8');
      add('rect',{x:238,y:218,width:31,height:17,rx:2,fill:'#fff2d5'});
      path('M239 219 L254 229 L268 219','none',{stroke:'#c29d7d','stroke-width':1.5});
      path('M287 291 Q319 274 348 271 T411 240','none',{stroke:'#7fa8ba','stroke-width':3,'stroke-dasharray':'3 10','stroke-linecap':'round'});
      for(const [x,y] of [[16,150],[179,105],[308,176],[392,136],[560,178],[219,210],[403,275]])circle(x,y,2.5,'#f5f7e9');
    } else if (world === '3') {
      circle(291, 79, 45, '#fce4a3');
      circle(291, 79, 33, '#ffd37b');
      for (const [x,y,dx,dy] of [[291,12,0,12],[239,29,8,8],[345,30,-8,8],[225,78,12,0],[357,78,-12,0]])
        path(`M${x} ${y} l${dx} ${dy}`, 'none', {stroke:'#f8e3b1','stroke-width':3,'stroke-linecap':'round'});
      path('M0 156 L76 106 L148 154 L251 95 L341 160 L429 109 L522 159 L584 106 L600 125 L600 300 L0 300Z','#c18c77');
      path('M0 200 L105 139 L212 205 L325 141 L445 209 L542 149 L600 192 L600 300 L0 300Z','#b78362');
      path('M0 228 Q110 190 215 231 Q368 191 466 236 Q538 200 600 221 L600 300 L0 300Z','#cfa663');
      path('M230 300 Q237 274 311 255 Q387 233 410 196 L435 198 Q411 252 342 269 Q301 282 291 300Z','#f2d398');
      // The left skyline's windmill and right clocktower share the sunrise.
      path('M71 173 L79 105 L107 105 L116 173Z','#e9c493');
      path('M73 108 L93 89 L113 108Z','#966a5b');
      add('rect',{x:87,y:145,width:14,height:28,rx:6,fill:'#9b795d'});
      const sails=add('g',{transform:'translate(93 112) rotate(-18)'});
      for(const angle of [0,90,180,270]){
        const arm=add('g',{transform:`rotate(${angle})`},sails);
        add('path',{d:'M0 0 L0 -48',fill:'none',stroke:'#9b7961','stroke-width':3},arm);
        add('path',{d:'M2 -14 L16 -18 L16 -47 L2 -47Z',fill:'#fae3b3',stroke:'#ba9670','stroke-width':1},arm);
      }
      circle(93,112,6,'#896950');
      add('rect',{x:440,y:91,width:69,height:138,rx:3,fill:'#d5b089'});
      add('rect',{x:446,y:93,width:10,height:136,fill:'#e6c296'});
      path('M429 94 L474 50 L518 94Z','#946957');
      add('rect',{x:470,y:35,width:6,height:23,fill:'#937251'});
      path('M477 36 L499 43 L477 48Z','#f2d093');
      circle(474,124,27,'#9e7657');circle(474,124,22,'#fae8b9');
      for(const [x1,y1,x2,y2] of [[474,105,474,109],[493,124,489,124],[474,143,474,139],[455,124,459,124]])
        path(`M${x1} ${y1} L${x2} ${y2}`,'none',{stroke:'#a17c56','stroke-width':2,'stroke-linecap':'round'});
      path('M474 111 L474 124 L484 130','none',{stroke:'#8e6a50','stroke-width':3,'stroke-linecap':'round','stroke-linejoin':'round'});
      circle(474,124,3,'#b18356');
      add('rect',{x:461,y:173,width:26,height:56,rx:13,fill:'#967454'});
      path('M439 159 L510 159 M439 164 L510 164','none',{stroke:'#bd926c','stroke-width':3});
      // A mine lantern, letter satchel, and golden grasses fill the lower row.
      path('M25 245 Q36 186 96 184 Q157 184 175 245Z','#9d745d');
      path('M55 245 Q63 205 96 205 Q127 205 138 245Z','#6e5c51');
      path('M75 243 L90 219 L102 237 L119 215 L130 245Z','#dab18a');
      add('rect',{x:28,y:222,width:22,height:33,rx:3,fill:'#a07851'});
      add('rect',{x:33,y:228,width:12,height:18,rx:2,fill:'#f9d182'});
      path('M33 220 Q39 207 45 220','none',{stroke:'#98724f','stroke-width':3});
      add('rect',{x:226,y:221,width:56,height:44,rx:9,fill:'#a97754'});
      path('M236 225 Q233 195 267 204 Q278 208 277 224','none',{stroke:'#986a4e','stroke-width':6});
      add('rect',{x:244,y:217,width:42,height:28,rx:3,fill:'#fff0ca',transform:'rotate(8 265 231)'});
      path('M247 221 L264 236 L284 225','none',{stroke:'#c19669','stroke-width':2,'stroke-linejoin':'round'});
      circle(264,235,4,'#ba7957');
      for(const [x,y] of [[23,283],[170,275],[350,286],[541,259],[575,281]]) {
        path(`M${x} ${y+12} Q${x-3} ${y-4} ${x+1} ${y-19}`,'none',{stroke:'#a3844e','stroke-width':2});
        path(`M${x+1} ${y-15} q-12 -9 -7 -14 q11 3 7 14 M${x+1} ${y-9} q12 -9 7 -14 q-11 3 -7 14`,'#ead191');
      }
      path('M331 66 q9 -10 18 0 q9 -10 18 0 M192 82 q7 -8 14 0 q7 -8 14 0','none',{stroke:'#b28067','stroke-width':2,'stroke-linecap':'round'});
    } else if (world === '2') {
      circle(285, 52, 27, '#fff1cf');
      path('M0 139 Q76 72 153 139 Q241 55 354 144 Q461 72 600 144 L600 235 L0 235Z', '#8fbcba');
      path('M0 158 Q115 132 233 160 T600 159 L600 300 L0 300Z', '#69aaa9');
      path('M0 190 Q145 169 302 194 T600 187 M18 229 Q130 211 254 229 M380 246 Q493 225 600 237', 'none', { stroke: '#d7eadc', 'stroke-width': 5, 'stroke-linecap': 'round' });
      path('M274 78 L302 78 L353 298 L219 298Z', '#dce8bd', { opacity: 0.25 });
      path('M512 7 Q489 83 531 175 L544 174 Q511 76 537 0Z', '#627f68');
      for (const [x, y, r] of [[498,22,63],[554,27,73],[578,85,44],[462,39,42]]) circle(x,y,r,'#799c70');
      for (const x of [462,486,514,543,571]) path(`M${x} 56 Q${x-25} 116 ${x-8} 149`, 'none', { stroke:'#86aa79','stroke-width':7,'stroke-linecap':'round' });
      path('M249 224 L356 224 L338 243 L270 243Z', '#b77e55');
      path('M297 220 L297 159 L338 213Z', '#f4e5ba');
      add('rect',{x:281,y:209,width:27,height:17,rx:3,fill:'#f7eed8'});
      path('M282 210 L295 220 L307 210', 'none',{stroke:'#bd8b69','stroke-width':2});
      for (const [x,y] of [[75,217],[154,263],[439,264],[489,218]]) {
        add('ellipse',{cx:x,cy:y,rx:23,ry:8,fill:'#507f62'});
        path(`M${x-10} ${y-2} Q${x-10} ${y-23} ${x} ${y-10} Q${x+14} ${y-24} ${x+10} ${y-1}Z`,'#f2c9b7');
      }
      path('M0 269 Q65 246 112 278 L114 300 L0 300Z M472 296 Q540 244 600 267 L600 300Z','#739263');
      for (const x of [25,46,63,550,573,588]) {
        path(`M${x} 290 Q${x-4} 254 ${x+4} 239`, 'none',{stroke:'#567a58','stroke-width':3});
        add('rect',{x:x+1,y:228,width:6,height:21,rx:3,fill:'#977b53'});
      }
    } else {
      circle(295,55,30,'#f3bc67');
      for (const [x,y] of [[105,62],[377,75]]) {
        add('ellipse',{cx:x,cy:y,rx:46,ry:14,fill:'#fff7df'});
        circle(x-9,y-9,19,'#fff7df');circle(x+13,y-9,16,'#fff7df');
      }
      path('M0 154 Q82 76 178 152 Q307 75 404 155 Q490 95 600 153 L600 300 L0 300Z','#b5c994');
      path('M0 208 Q99 127 235 205 Q370 135 600 195 L600 300 L0 300Z','#8fae76');
      add('rect',{x:491,y:85,width:38,height:76,rx:4,fill:'#b69a73'});
      path('M483 86 L511 56 L538 86Z','#aa785e');
      add('rect',{x:505,y:104,width:11,height:18,rx:5,fill:'#f7e8bb'});
      path('M0 283 Q140 208 283 238 Q475 177 600 224 L600 300 L0 300Z','#aec080');
      path('M231 300 Q243 267 315 244 Q366 227 376 197 L398 197 Q392 242 343 260 Q294 280 294 300Z','#e4cd94');
      add('rect',{x:88,y:88,width:22,height:146,rx:10,fill:'#98774f'});
      for (const [x,y,r] of [[64,80,52],[105,42,57],[143,86,49],[93,117,47]])circle(x,y,r,'#72975f');
      for (const [x,y,r] of [[59,63,20],[125,37,26],[139,88,22]])circle(x,y,r,'#88a56a');
      add('rect',{x:337,y:182,width:70,height:57,rx:5,fill:'#e9d59e'});
      path('M326 184 L372 151 L417 184Z','#bf805c');
      add('rect',{x:364,y:209,width:19,height:30,rx:7,fill:'#8d9b66'});
      add('rect',{x:344,y:195,width:12,height:14,rx:2,fill:'#fff2cd'});
      add('rect',{x:390,y:195,width:11,height:14,rx:2,fill:'#fff2cd'});
      add('rect',{x:432,y:214,width:5,height:37,fill:'#a38760'});
      add('rect',{x:422,y:209,width:27,height:18,rx:5,fill:'#be7955'});
      path('M426 214 L435 220 L445 214','none',{stroke:'#f4e4bb','stroke-width':2});
      for(const [x,y] of [[35,270],[170,256],[483,265],[540,239],[562,289]]) {
        path(`M${x} ${y+12} L${x} ${y}`, 'none', {stroke:'#648b54','stroke-width':2});
        circle(x-4,y,4,'#f2ddaa');circle(x+4,y,4,'#f2ddaa');circle(x,y-4,4,'#f2ddaa');circle(x,y,3,'#d5a056');
      }
    }
    return svg;
  }

  function render(container, progress, options = {}) {
    const selected = worldId(options.world), summary = summarize(progress, selected);
    if (!container || !container.ownerDocument) return summary;
    const document = container.ownerDocument;
    const element = (name, className, text) => {
      const node = document.createElement(name);
      node.className = className;
      if (text !== undefined) node.textContent = text;
      return node;
    };
    container.replaceChildren();
    container.classList.add('collection-panel');
    container.classList.toggle('compact', options.compact === true);
    const worlds = selected === null ? [...new Set(pieces.map(piece => piece.world))] : [selected];
    for (const world of worlds) {
      const state = summarize(progress, world);
      if (!state.total) continue;
      const section = element('section', `collection-world${state.complete ? ' complete' : ''}`);
      section.setAttribute('data-world', world);
      section.setAttribute('aria-label', `${state.worldName} 여행 퍼즐, ${state.total}개 중 ${state.collected}개 수집`);
      const head = element('div', 'collection-head');
      head.append(element('p','collection-eyebrow',`WORLD ${world} · 여행 퍼즐`),
        element('h3','collection-title',state.rewardTitle),
        element('p','collection-count',`${state.collected} / ${state.total} 조각`));
      if (!options.compact) section.append(head);
      const grid = element('ol', 'collection-puzzle');
      grid.setAttribute('aria-label', `${state.worldName} 엽서 조각`);
      for (const [index, piece] of state.pieces.entries()) {
        const tile = element('li', `collection-piece ${piece.collected ? 'collected' : 'locked'}`);
        tile.setAttribute('data-stage', piece.id);
        tile.setAttribute('aria-label', `${piece.id} ${piece.stageName} · ${piece.title} · ${piece.collected ? '수집 완료' : '아직 찾지 못함'}`);
        tile.setAttribute('title', `${piece.id} ${piece.stageName} · ${piece.title}`);
        if (piece.collected) tile.append(picture(document, world, index, state.total));
        else {
          const mystery = element('span','collection-mystery','?');
          mystery.setAttribute('aria-hidden','true');tile.append(mystery);
        }
        const label = element('span','collection-piece-label',piece.id);
        label.setAttribute('aria-hidden','true');tile.append(label);
        const status = element('span','collection-piece-status',piece.collected ? '✦' : '미발견');
        status.setAttribute('aria-hidden','true');tile.append(status);
        grid.append(tile);
      }
      section.append(grid);
      const caption = options.compact
        ? state.complete ? `엽서 완성! 「${state.rewardTitle}」` : `여행 퍼즐 ${state.collected} / ${state.total} · ${state.remaining}개 더 찾으면 엽서가 완성돼요.`
        : state.complete ? `엽서 완성! ${postcards[world]?.caption || '여행의 풍경을 모두 모았어요.'}` : `${state.remaining}개만 더 찾으면 여행 엽서가 완성돼요. 조각은 단계 클리어와 별도로 모을 수 있어요.`;
      section.append(element('p','collection-caption',caption));
      if (!options.compact) section.append(element('p','collection-unavailable',`${state.noPieceStages.map(stage => stage.id).join(' · ')}에는 퍼즐 조각이 없어요. 나머지 단계와 비밀·보너스 공간을 찾아보세요.`));
      container.append(section);
    }
    return summary;
  }

  const api = { getPieces, getStagePiece, summarize, render };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ForestCollection = api;
})(typeof window !== 'undefined' ? window : null);
