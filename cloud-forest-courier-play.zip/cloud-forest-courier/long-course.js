(function(root){
  'use strict';
  // Each strip is authored in playable island units. Coordinates in the existing
  // route are deliberately untouched so secret entrances and old saves agree.
  const strips=[
    {kind:'stair-islands',blocks:[[0,515,330],[330,435,300],[835,480,360],
      [1410,440,330],[1950,515,450]]},
    {kind:'ferry-crossing',blocks:[[0,515,380],[610,500,300],[1170,465,340],
      [1735,500,280],[2015,515,385]]},
    {kind:'high-low-ridge',blocks:[[0,515,300],[300,425,280],[790,485,350],
      [1140,405,300],[1660,470,330],[2200,515,200]]}
  ];
  const labels={
    1:['나무 위 징검길','깊은 구름다리','폭풍 가지 능선'],
    2:['갈대섬 징검길','물안개 나룻배','호숫가 절벽길'],
    3:['엇갈린 태엽 계단','운반 벨트 다리','시계탑 외곽 능선'],
    4:['서리 계단 섬','빙하 나룻배','눈보라 얼음 능선']
  };
  function apply(levels,stages){
    for(const stage of stages){
      const level=levels[stage.id];
      if(!level||stage.boss||level.boss||!level.finish||level.expansion)continue;
      const world=Number(stage.id.split('-')[0]),ordinal=Number(stage.id.split('-')[1]);
      const originalFinish=level.finish,originalWidth=level.width;
      const originalEnemyCount=level.enemies.length,originalCoinCount=level.coins.length;
      const originalTotalCoins=level.totalCoins;
      const startX=originalWidth;
      const minimumFinish=Math.max(9000,level.spawn.x+2*(originalFinish-level.spawn.x));
      const count=Math.max(2,Math.ceil((minimumFinish-startX-440)/2400));
      const route=[],sections=[],addedEnemyStart=level.enemies.length;
      level.checkpoints=level.checkpoint?[{...level.checkpoint}]:[];
      level.movingPlatforms=level.movingPlatforms||[];
      level.trees=level.trees||[];level.signs=level.signs||[];level.areas=level.areas||[];
      let coinCount=0;
      function coin(x,y){level.coins.push({id:`${level.id}-long-acorn-${++coinCount}`,x,y});}
      for(let section=0;section<count;section++){
        const variant=(section+ordinal-1)%strips.length,strip=strips[variant];
        const x=startX+section*2400;
        const sectionBlocks=strip.blocks.map(([offset,y,w],index)=>{
          const block={x:x+offset,y,w,h:695-y};
          if(world===4&&index>0&&index<strip.blocks.length-1)block.ice=true;
          if(world===3&&index>0&&index<strip.blocks.length-1)
            block.belt=(index%2?-1:1)*(48+ordinal*3);
          level.platforms.push(block);return block;
        });
        sections.push({kind:strip.kind,name:labels[world][variant],start:x,end:x+2400,
          firstPlatform:level.platforms.length-sectionBlocks.length});
        // A broad landing precedes every rest flag; no patrol or belt crosses it.
        const checkpoint={x:x+92,y:469,triggerX:x+32,maxX:x+220,flagX:x+62};
        level.checkpoints.push(checkpoint);
        level.areas.push({x,name:labels[world][variant]});
        level.signs.push([x+25,504,section===0?'긴 배달길 시작 · 중간 우체통에서 이어가요':
          '중간 우체통 · 다음 섬을 보고 점프!']);
        level.trees.push({x:x+55,y:515,s:.82});
        if(section===0||section===Math.floor(count/2)){
          level.items.push({id:`${level.id}-long-fire-${section}`,type:'fire',x:x+140,y:475},
            {id:`${level.id}-long-armor-${section}`,type:'armor',x:x+80,y:395});
        }
        route.push({type:'walk',x:x+92});
        for(let index=0;index<sectionBlocks.length;index++){
          const block=sectionBlocks[index],next=sectionBlocks[index+1];
          if(index>0){
            // Land clear of the patrol, then choose when to advance or shoot.
            const speed=50+world*7+ordinal*2+(section%2)*3;
            const last=index===sectionBlocks.length-1;
            const min=block.x+160,max=block.x+block.w-(last?200:46);
            if(max>=min){
              level.enemies.push({kind:world===4?'snowbug':world===2?'crab':world===3?'clockbug':undefined,
                x:min+Math.min(30,(max-min)/2),y:block.y-24,w:38,h:24,min,max,speed});
              if(block.w>=300&&!last){
                const rearMin=block.x+block.w-130,rearMax=block.x+block.w-46;
                level.enemies.push({kind:world===4?'frostcrab':world===2?'crab':world===3?'clockbug':undefined,
                  x:rearMax,y:block.y-24,w:38,h:24,min:rearMin,max:rearMax,speed:speed+5});
              }
            }
            for(let n=0;n<3;n++)coin(block.x+45+n*42,block.y-43);
            level.trees.push({x:block.x+block.w-25,y:block.y,s:.55+(index%2)*.13});
          }
          if(next){
            const gap=next.x-block.x-block.w;
            route.push({type:'walk',x:block.x+block.w-(gap?72:98)});
            route.push({type:'jump',x:next.x+22,y:next.y-46,double:gap>=225});
            if(gap>0){coin(block.x+block.w+gap/2,Math.min(block.y,next.y)-90);}
          }
        }
        if(variant===1){
          level.movingPlatforms.push({id:`${level.id}-long-ferry-${section}`,x:x+955,y:530,
            w:125,h:24,axis:'x',range:80,speed:48+world*3});
        }
        route.push({type:'walk',x:x+2390});
      }
      const end=startX+count*2400;
      level.platforms.push({x:end,y:515,w:700,h:180});
      level.finish=end+440;level.width=end+700;
      route.push({type:'walk',x:level.finish+8});
      level.areas.push({x:end,name:'긴 여행 끝 우편함'});
      level.signs.push([end+90,504,'먼 길을 건너온 편지 · 마지막 우편함 →']);
      for(let n=0;n<5;n++)coin(end+180+n*42,472);
      level.expansion={originalFinish,originalWidth,originalEnemyCount,originalCoinCount,originalTotalCoins,
        startX,sections,route,
        addedEnemies:level.enemies.length-addedEnemyStart,addedCoins:coinCount,
        lengthRatio:(level.finish-level.spawn.x)/(originalFinish-level.spawn.x)};
      level.hint=level.hint||'길어진 배달길을 건너요. 연속 점프와 불꽃을 쓰고, 중간 우체통에서 이어가세요.';
      for(const sign of level.signs)if(sign[0]<originalWidth&&sign[0]>originalFinish-800&&
        /우편함|도착|마지막 편지/.test(sign[2]))sign[2]='쉼터를 지나 다음 배달길로 →';
      stage.tags=[...stage.tags.filter(tag=>tag!=='긴 배달길'),'긴 배달길'];
      const rooms=new Set((level.portals||[]).map(portal=>portal.target)
        .filter(id=>levels[id]&&levels[id].finish===null));
      level.totalCoins=level.coins.length+[...rooms].reduce((sum,id)=>sum+levels[id].coins.length,0);
    }
    return levels;
  }
  const api={apply};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.ForestLongCourse=api;
})(typeof window!=='undefined'?window:null);
