(function (root) {
  'use strict';
  const catalogue=typeof module!=='undefined'&&module.exports ? require('./levels.js') : root.ForestLevels;
  const BALANCE=Object.freeze({fireCooldown:.48,projectileSpeed:600,projectileLife:.8,
    maxPlayerProjectiles:3,powerDuration:6,hurtInvulnerability:1.25,itemRespawn:6,
    initialBossWindup:1.1,bossDashMultiplier:1.15,bossProjectileMultiplier:1.2,
    iceCoastDeceleration:260,
    bossWindup:Object.freeze({owl:.82,turtle:.8,fox:.8,bear:.92}),
    bossRecovery:Object.freeze({owl:1.35,turtle:1.42,fox:1.35,bear:1.45})});
  const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
  class World {
    constructor(stageId='1-1') {this.reset(stageId);}
    reset(stageId=this.stageId||'1-1') {
      if(!catalogue.stages.some(stage=>stage.id===stageId&&stage.available)) stageId='1-1';
      this.stageId=stageId;this.sceneId=stageId;this.scenes={};
      this.player={x:0,y:0,w:34,h:46,vx:0,vy:0,facing:1,grounded:true,gliding:false,onIce:false,
        glide:.8,coyote:.1,buffer:0,invulnerable:0,armored:false,powerTime:0,springBoost:false,
        weapon:null,fireCooldown:0,doubleJumpReady:false,doubleJumpLimitY:null,hurtTime:0,landingTime:0};
      this.checkpoint=false;this.checkpointIndex=-1;this.activeCheckpoint=null;
      this.retries=0;this.elapsed=0;this.won=false;
      this.respawnTimer=0;this.events=[];this.jumpWasDown=false;this.interactWasDown=false;
      this.collected=0;this.secretFound=false;this.stampCollected=false;this.nearPortal=null;
      this.bonusCompleted=false;this.windActive=null;this.conveyorSpeed=0;this.iceActive=false;this.bossGateX=null;
      this.totalCoins=catalogue.get(stageId).totalCoins;this.returnSpawn=null;
      this.setScene(stageId,catalogue.get(stageId).spawn);
    }
    get width() {return this.level.width;}
    get finish() {return this.level.finish;}
    get solids() {return this.platforms.concat(this.breakables.filter(block=>!block.broken));}
    setScene(sceneId,spawn) {
      const level=catalogue.get(sceneId);
      if(!level) return;
      if(!this.scenes[sceneId]) {
        const movingPlatforms=(level.movingPlatforms||[]).map((b,index)=>({...b,
          id:b.id||`${sceneId}-moving-${index}`,moving:true,baseX:b.x,baseY:b.y,travel:0,dx:0,dy:0}));
        this.scenes[sceneId]={
        platforms:level.platforms.map(b=>({...b})).concat(movingPlatforms),movingPlatforms,
        enemies:level.enemies.map(e=>({...e,dir:1,alive:true})),
        coins:level.coins.map(c=>({...c,taken:false})),
        items:level.items.map(i=>({...i,taken:false,cooldown:0})),
        breakables:level.breakables.map(b=>({...b,broken:false})),
        portals:level.portals.map(p=>({...p,unlocked:!p.lockedBy})),
        stamps:level.stamps.map(s=>({...s,taken:false})),
        springs:(level.springs||[]).map(s=>({...s,cooldown:0,compression:0})),
        bonus:level.bonus?{remaining:level.bonus.duration,collected:0,target:level.bonus.target,
          completed:false,expired:false,started:false}:null,
        boss:level.boss?this.createBoss(level.boss):null,projectiles:[],playerProjectiles:[]
        };
      }
      for(const scene of Object.values(this.scenes))scene.playerProjectiles.length=0;
      this.sceneId=sceneId;this.level=level;
      Object.assign(this,this.scenes[sceneId]);
      Object.assign(this.player,{...spawn,vx:0,vy:0,grounded:true,gliding:false,glide:.8,coyote:.1,buffer:0,
        springBoost:false,fireCooldown:0,doubleJumpReady:false,doubleJumpLimitY:null,landingTime:0});
      this.nearPortal=null;this.windActive=null;this.conveyorSpeed=0;this.updateIceState();
      this.bossGateX=this.boss?this.boss.max+140:null;
      this.updatePortals();
      if(this.bonus&&!this.bonus.started) {
        this.bonus.started=true;this.emit('bonusStart',{remaining:this.bonus.remaining,target:this.bonus.target});
      }
    }
    emit(type,data={}) {this.events.push({type,...data});}
    refillArmor() {
      for(const scene of Object.values(this.scenes)) for(const item of scene.items) {
        if(item.type==='armor'&&item.taken) item.cooldown=BALANCE.itemRespawn;
      }
    }
    loseArmor() {
      if(!this.player.armored) return;
      this.player.armored=false;this.refillArmor();
      this.emit('armorLost',{x:this.player.x+17,y:this.player.y+23});
    }
    loseWeapon() {
      if(!this.player.weapon)return;
      this.player.weapon=null;this.player.fireCooldown=0;
      for(const scene of Object.values(this.scenes)) {
        scene.playerProjectiles.length=0;
        for(const item of scene.items)if(item.type==='fire'&&item.taken)item.cooldown=BALANCE.itemRespawn;
      }
      this.emit('weaponLost',{x:this.player.x+17,y:this.player.y+23});
    }
    die(reason) {
      if(this.respawnTimer||this.won) return;
      if(this.player.powerTime>0) {this.player.powerTime=0;this.emit('powerEnd');}
      this.loseWeapon();this.loseArmor();this.retries++;this.respawnTimer=.55;this.player.gliding=false;
      this.player.doubleJumpReady=false;this.player.doubleJumpLimitY=null;
      this.player.onIce=false;this.iceActive=false;
      if(this.boss)this.boss.icicleTargets=[];
      this.playerProjectiles.length=0;this.projectiles.length=0;
      this.emit('death',{reason});
    }
    respawn() {
      const spawn=this.sceneId===this.stageId&&this.checkpoint ?
        (this.activeCheckpoint||this.level.checkpoint||this.level.spawn):this.level.spawn;
      Object.assign(this.player,{x:spawn.x,y:spawn.y,vx:0,vy:0,grounded:true,gliding:false,
        glide:.8,coyote:.1,buffer:0,invulnerable:1.3,powerTime:0,springBoost:false,
        weapon:null,fireCooldown:0,doubleJumpReady:false,doubleJumpLimitY:null,hurtTime:0,landingTime:0});
      if(this.boss)Object.assign(this.boss,this.createBoss(this.level.boss));
      for(const spring of this.springs){spring.cooldown=0;spring.compression=0;}
      this.projectiles.length=0;this.playerProjectiles.length=0;this.windActive=null;this.conveyorSpeed=0;
      this.updateIceState();
      this.updatePortals();this.emit('respawn');
    }
    damage(sourceX,reason='enemy') {
      const p=this.player;
      if(this.respawnTimer||p.invulnerable||p.powerTime>0)return false;
      this.loseWeapon();
      if(p.armored) {
        this.loseArmor();p.invulnerable=BALANCE.hurtInvulnerability;p.hurtTime=.3;
        p.vx=p.x<sourceX?-165:165;p.vy=-190;p.grounded=false;
      } else this.die(reason);
      return true;
    }
    shoot() {
      const p=this.player;
      if(p.weapon!=='fire'||p.fireCooldown>0||this.playerProjectiles.length>=BALANCE.maxPlayerProjectiles||this.respawnTimer)return;
      const shot={kind:'fire',x:p.facing>0?p.x+p.w+1:p.x-13,y:p.y+p.h*.55,
        w:12,h:10,vx:p.facing*BALANCE.projectileSpeed,life:BALANCE.projectileLife};
      this.playerProjectiles.push(shot);p.fireCooldown=BALANCE.fireCooldown;
      this.emit('shoot',{x:shot.x+shot.w/2,y:shot.y+shot.h/2,dir:p.facing});
    }
    updatePlayerProjectiles(dt) {
      for(const shot of this.playerProjectiles) {
        const oldX=shot.x;
        shot.x+=shot.vx*Math.min(dt,Math.max(0,shot.life));shot.life-=dt;
        const swept={x:Math.min(oldX,shot.x),y:shot.y,w:shot.w+Math.abs(shot.x-oldX),h:shot.h};
        const targets=this.solids.map(actor=>({actor,type:'wall'}))
          .concat(this.enemies.filter(enemy=>enemy.alive).map(actor=>({actor,type:'enemy'})));
        if(this.boss&&!this.boss.defeated)targets.push({actor:this.boss,type:'boss'});
        const hits=targets.filter(target=>overlap(swept,target.actor));
        const distance=actor=>shot.vx>0?Math.max(0,actor.x-oldX-shot.w):Math.max(0,oldX-actor.x-actor.w);
        hits.sort((a,b)=>distance(a.actor)-distance(b.actor));
        if(hits.length) {
          const {actor,type}=hits[0];
          const point={x:shot.vx>0?actor.x:actor.x+actor.w,y:shot.y+shot.h/2};
          let target=type;
          if(type==='enemy')actor.alive=false;
          else if(type==='boss'&&!(actor.active&&actor.phase==='recovery'&&this.hitBoss())) {
            target='guard';this.emit('bossGuard',{...point,source:'shot'});
          }
          shot.life=0;this.emit('shotHit',{...point,target});
        }
      }
      for(let index=this.playerProjectiles.length-1;index>=0;index--) {
        const shot=this.playerProjectiles[index];
        if(shot.life<=0||shot.x+shot.w<0||shot.x>this.width)this.playerProjectiles.splice(index,1);
      }
    }
    updateMovingPlatforms(dt) {
      const p=this.player;
      for(const block of this.movingPlatforms) {
        const oldX=block.x,oldY=block.y;
        const riding=p.grounded&&Math.abs(p.y+p.h-oldY)<1.1&&p.x+p.w>oldX&&p.x<oldX+block.w;
        const range=Math.max(0,block.range||0);
        block.travel+=Math.max(0,block.speed||0)*dt;
        const phase=range?block.travel%(range*2):0;
        const offset=phase<=range?phase:range*2-phase;
        block.x=block.baseX+(block.axis==='x'?offset:0);
        block.y=block.baseY+(block.axis==='y'?offset:0);
        block.dx=block.x-oldX;block.dy=block.y-oldY;
        if(riding){p.x+=block.dx;p.y+=block.dy;}
      }
    }
    updateIceState() {
      const p=this.player;
      p.onIce=!this.respawnTimer&&p.grounded&&this.platforms.some(block=>block.ice&&
        Math.abs(p.y+p.h-block.y)<1.1&&p.x+p.w>block.x&&p.x<block.x+block.w);
      this.iceActive=p.onIce;
    }
    bounceOnSpring(prevBottom,wasGrounded,landingSpeed) {
      const p=this.player;
      if(wasGrounded||landingSpeed<0)return;
      for(const spring of this.springs) {
        if(spring.cooldown>0||p.x+p.w<=spring.x||p.x>=spring.x+spring.w||
          prevBottom>spring.y+2||p.y+p.h<spring.y-1)continue;
        const power=Math.max(650,Math.min(1100,Number.isFinite(spring.power)?spring.power:900));
        p.y=spring.y-p.h;p.vy=-power;p.grounded=false;p.gliding=false;p.glide=.8;
        p.coyote=0;p.buffer=0;p.springBoost=true;p.landingTime=.16;
        p.doubleJumpReady=false;p.doubleJumpLimitY=null;
        spring.cooldown=.3;spring.compression=1;
        this.emit('spring',{x:spring.x+spring.w/2,y:spring.y,power});
        break;
      }
    }
    createBoss(spec) {
      return {...spec,hp:spec.hp,maxHp:spec.hp,phase:'idle',timer:0,active:false,
        defeated:false,dir:-1,flash:0,hitCooldown:0,powerGuardCooldown:0,attacks:0,
        volleyHeight:spec.kind==='fox'?'low':null,attackType:spec.kind==='bear'?'wave':null,icicleTargets:[]};
    }
    prepareBearAttack() {
      const boss=this.boss;
      boss.attackType=boss.attacks%2===0?'wave':'icicle';
      const center=this.player.x+this.player.w/2;
      boss.icicleTargets=boss.attackType==='icicle'?[-100,0,100].map(offset=>
        Math.max(30,Math.min(this.width-30,center+offset))):[];
    }
    hitBoss() {
      const boss=this.boss;
      if(!boss||boss.defeated||boss.hitCooldown>0)return false;
      boss.hp=Math.max(0,boss.hp-1);boss.flash=.65;boss.hitCooldown=1.1;
      this.emit('bossHit',{x:boss.x+boss.w/2,y:boss.y+18,hp:boss.hp});
      // A successful counterattack cannot erase hazards that are already flying.
      if(!boss.hp) {
        this.projectiles.length=0;boss.icicleTargets=[];
        boss.defeated=true;boss.phase='defeated';boss.timer=0;
        this.emit('bossDefeated',{x:boss.x+boss.w/2,y:boss.y+boss.h/2});
      } else {boss.phase='hurt';boss.timer=.7;}
      return true;
    }
    updateBoss(dt) {
      const boss=this.boss,p=this.player;
      if(!boss)return;
      boss.flash=Math.max(0,boss.flash-dt);boss.hitCooldown=Math.max(0,boss.hitCooldown-dt);
      boss.powerGuardCooldown=Math.max(0,boss.powerGuardCooldown-dt);
      if(boss.defeated)return;
      if(!boss.active) {
        if(p.x<boss.triggerX)return;
        boss.active=true;boss.phase='windup';boss.timer=BALANCE.initialBossWindup;
        boss.dir=p.x+p.w/2<boss.x+boss.w/2?-1:1;
        if(boss.kind==='bear')this.prepareBearAttack();
        this.emit('bossStart',{x:boss.x+boss.w/2,y:boss.y});
      }
      boss.timer-=dt;
      if(boss.phase==='dash') {
        boss.x+=boss.dir*(330+(boss.maxHp-boss.hp)*55)*BALANCE.bossDashMultiplier*dt;
        if(boss.x<=boss.min||boss.x>=boss.max) {
          boss.x=Math.max(boss.min,Math.min(boss.max,boss.x));boss.timer=0;
        }
      }
      if(boss.timer<=0) {
        if(boss.phase==='windup') {
          boss.attacks++;
          const attack={x:boss.x+boss.w/2,y:boss.y+30,dir:boss.dir,kind:boss.kind||'owl'};
          if(boss.kind==='bear') {
            attack.attackType=boss.attackType;
            const lost=boss.maxHp-boss.hp;
            if(boss.attackType==='wave') {
              boss.phase='slam';boss.timer=.32;
              const speed=280+lost*10;
              if(this.projectiles.length<=4)for(const dir of [-1,1]) {
                this.projectiles.push({kind:'frostwave',x:dir<0?boss.x-30:boss.x+boss.w,
                  y:boss.y+boss.h-24,w:30,h:24,vx:dir*speed,vy:0,life:4});
              }
              this.emit('bossFrost',{x:attack.x,y:boss.y+boss.h,strength:lost+1});
            } else {
              boss.phase='hail';boss.timer=.65;
              const speed=360+lost*18;
              if(this.projectiles.length<=3)for(const center of boss.icicleTargets) {
                this.projectiles.push({kind:'icicle',x:center-13,y:210,w:26,h:42,
                  vx:0,vy:speed,life:3,groundY:boss.y+boss.h});
              }
              this.emit('bossHail',{x:attack.x,y:210,targets:[...boss.icicleTargets],speed});
            }
          } else if(boss.kind==='turtle') {
            boss.phase='slam';boss.timer=.32;
            const speed=(210+(boss.maxHp-boss.hp)*25)*BALANCE.bossProjectileMultiplier;
            if(this.projectiles.length<=4)for(const dir of [-1,1]) {
              this.projectiles.push({kind:'wave',x:dir<0?boss.x-30:boss.x+boss.w,
                y:boss.y+boss.h-24,w:30,h:24,vx:dir*speed,life:4});
            }
            this.emit('bossSlam',{x:attack.x,y:boss.y+boss.h,strength:boss.maxHp-boss.hp+1});
          } else if(boss.kind==='fox') {
            boss.phase='volley';boss.timer=.45;
            const speed=(220+(boss.maxHp-boss.hp)*15)*BALANCE.bossProjectileMultiplier;
            const y=boss.volleyHeight==='low'?boss.y+boss.h-24:boss.y-18;
            if(this.projectiles.length<=4)for(const dir of [-1,1]) {
              this.projectiles.push({kind:'gear',height:boss.volleyHeight,
                x:dir<0?boss.x-28:boss.x+boss.w,y,w:28,h:24,vx:dir*speed,life:4});
            }
            attack.height=boss.volleyHeight;
            this.emit('bossVolley',{x:attack.x,y:y+12,height:boss.volleyHeight});
          } else {
            boss.phase='dash';boss.timer=.7;
            if(boss.hp<boss.maxHp&&this.projectiles.length<3) {
              this.projectiles.push({kind:'feather',x:attack.x,y:attack.y,w:26,h:12,
                vx:boss.dir*(210+(boss.maxHp-boss.hp)*25)*BALANCE.bossProjectileMultiplier,life:3});
            }
          }
          this.emit('bossAttack',attack);
        } else if(boss.phase==='dash'||boss.phase==='slam'||boss.phase==='volley'||boss.phase==='hail') {
          boss.phase='recovery';boss.timer=BALANCE.bossRecovery[boss.kind||'owl'];
          if(boss.kind==='bear')boss.icicleTargets=[];
        } else {
          boss.phase='windup';boss.timer=BALANCE.bossWindup[boss.kind||'owl'];
          if(boss.kind==='fox')boss.volleyHeight=boss.attacks%2===0?'low':'high';
          if(boss.kind==='bear')this.prepareBearAttack();
          boss.dir=p.x+p.w/2<boss.x+boss.w/2?-1:1;
        }
      }
      for(const feather of this.projectiles) {
        const oldY=feather.y;
        feather.x+=feather.vx*dt;feather.life-=dt;
        feather.y+=(feather.vy||0)*dt;
        const collision=feather.kind==='icicle'?{x:feather.x,y:Math.min(oldY,feather.y),
          w:feather.w,h:feather.h+Math.abs(feather.y-oldY)}:feather;
        if(overlap(p,collision)) {
          if(p.powerTime>0)this.emit('powerHit',{x:feather.x,y:feather.y});
          else this.damage(feather.x,'boss');
          feather.life=0;
        }
        if(feather.kind==='icicle'&&feather.y+feather.h>=feather.groundY)feather.life=0;
      }
      for(let index=this.projectiles.length-1;index>=0;index--) {
        const feather=this.projectiles[index];
        if(feather.life<=0||feather.x<0||feather.x>this.width)this.projectiles.splice(index,1);
      }
    }
    updateBonus(dt) {
      const bonus=this.bonus;
      if(!bonus||bonus.completed||bonus.expired)return false;
      if(bonus.collected>=bonus.target) {
        bonus.completed=true;this.bonusCompleted=true;
        this.emit('bonusComplete',{collected:bonus.collected,target:bonus.target,
          x:this.player.x+17,y:this.player.y+23});
      } else {
        bonus.remaining=Math.max(0,bonus.remaining-dt);
        if(!bonus.remaining) {
          bonus.expired=true;
          const collected=bonus.collected;
          this.setScene(this.stageId,this.returnSpawn||catalogue.get(this.stageId).spawn);
          this.player.invulnerable=Math.max(this.player.invulnerable,.6);
          this.emit('secretExit',{x:this.player.x,y:this.player.y});
          this.emit('bonusTimeout',{collected});
          return true;
        }
      }
      return false;
    }
    updatePortals() {
      this.nearPortal=null;
      for(const portal of this.portals) {
        portal.unlocked=!portal.lockedBy||this.breakables.some(b=>b.id===portal.lockedBy&&b.broken);
        const zone={x:portal.x-28,y:portal.y-16,w:portal.w+56,h:portal.h+24};
        if(portal.unlocked&&overlap(this.player,zone))this.nearPortal=portal;
      }
    }
    enterPortal(portal) {
      if(!portal||!portal.unlocked)return;
      if(portal.target!==this.stageId) {
        const prior=this.scenes[portal.target];
        if(prior&&prior.bonus&&prior.bonus.expired) {
          this.emit('bonusClosed',{collected:prior.bonus.collected});return;
        }
        this.returnSpawn=portal.returnSpawn||this.level.spawn;this.secretFound=true;
        this.setScene(portal.target,catalogue.get(portal.target).spawn);
        this.emit('secretEnter',{x:this.player.x,y:this.player.y});
      } else {
        this.setScene(this.stageId,this.returnSpawn||catalogue.get(this.stageId).spawn);
        this.emit('secretExit',{x:this.player.x,y:this.player.y});
      }
      this.player.invulnerable=Math.max(this.player.invulnerable,.6);
    }
    step(dt,input={}) {
      if(this.won)return;
      dt=Math.max(0,Math.min(.04,dt));this.elapsed+=dt;
      const p=this.player,jump=!!input.jump,interact=!!input.interact;
      for(const scene of Object.values(this.scenes))for(const item of scene.items) {
        if(item.cooldown>0) {item.cooldown=Math.max(0,item.cooldown-dt);if(!item.cooldown)item.taken=false;}
      }
      if(this.respawnTimer>0) {
        this.respawnTimer=Math.max(0,this.respawnTimer-dt);
        if(!this.respawnTimer)this.respawn();
        this.jumpWasDown=jump;this.interactWasDown=interact;return;
      }
      p.invulnerable=Math.max(0,p.invulnerable-dt);
      if(p.powerTime>0) {
        p.powerTime=Math.max(0,p.powerTime-dt);
        if(!p.powerTime)this.emit('powerEnd',{x:p.x+17,y:p.y+23});
      }
      p.hurtTime=Math.max(0,p.hurtTime-dt);p.landingTime=Math.max(0,p.landingTime-dt);
      p.fireCooldown=Math.max(0,p.fireCooldown-dt);
      for(const spring of this.springs) {
        spring.cooldown=Math.max(0,spring.cooldown-dt);
        spring.compression=Math.max(0,spring.compression-dt*4);
      }
      const beforeMovementX=p.x;
      this.updateMovingPlatforms(dt);
      this.updateIceState();
      this.updateBoss(dt);
      if(this.respawnTimer){this.jumpWasDown=jump;this.interactWasDown=interact;return;}
      const freshJump=jump&&!this.jumpWasDown;
      p.buffer=freshJump ? .13 : Math.max(0,p.buffer-dt);
      if(p.grounded)p.coyote=.11;else p.coyote=Math.max(0,p.coyote-dt);
      const wasGrounded=p.grounded;
      const direction=(input.right?1:0)-(input.left?1:0);
      const launching=p.buffer>0&&p.coyote>0;
      const target=direction*275,acceleration=(p.onIce&&!direction&&!launching?
        BALANCE.iceCoastDeceleration:p.grounded?1850:1100)*dt;
      p.vx+=Math.max(-acceleration,Math.min(acceleration,target-p.vx));
      if(direction)p.facing=direction;
      if(p.buffer>0&&p.coyote>0) {
        p.vy=-635;p.grounded=false;p.coyote=0;p.buffer=0;
        p.doubleJumpReady=true;p.doubleJumpLimitY=null;this.emit('jump');
      } else if(freshJump&&!p.grounded&&p.doubleJumpReady&&p.y>45) {
        const rise=Math.min(90,p.y-45);
        p.vy=-Math.min(560,Math.sqrt(2*1750*rise));p.buffer=0;p.coyote=0;
        p.gliding=false;p.springBoost=false;p.doubleJumpReady=false;p.doubleJumpLimitY=Math.max(45,p.y-90);
        this.emit('doubleJump',{x:p.x+p.w/2,y:p.y+p.h});
      }
      if(!jump&&this.jumpWasDown&&!p.springBoost&&p.vy < -245)p.vy=-245;
      p.gliding=jump&&!p.grounded&&p.vy>=0&&p.glide>0;
      if(p.gliding) {p.glide=Math.max(0,p.glide-dt);p.vy=Math.min(86,p.vy+380*dt);}
      else p.vy=Math.min(1000,p.vy+1750*dt);
      if(p.vy>=0)p.springBoost=false;
      this.windActive=!p.grounded?(this.level.winds||[]).find(wind=>overlap(p,wind))||null:null;
      if(this.windActive) {
        p.vy=Math.max(-460,p.vy+this.windActive.force*dt);
        p.vx+=this.windActive.drift*dt;
      }
      const belt=p.grounded?this.platforms.find(block=>Number.isFinite(block.belt)&&
        Math.abs(p.y+p.h-block.y)<1.1&&p.x+p.w>block.x&&p.x<block.x+block.w):null;
      this.conveyorSpeed=belt?belt.belt:0;
      const previousX=beforeMovementX,horizontalSpeed=p.vx+this.conveyorSpeed;
      p.x+=horizontalSpeed*dt;
      const horizontalMovement=p.x-previousX;
      for(const block of this.solids) {
        const beltCrossing=this.conveyorSpeed&&p.y<block.y+block.h&&p.y+p.h>block.y&&
          (horizontalMovement>0&&previousX+p.w<=block.x&&p.x+p.w>=block.x||
           horizontalMovement<0&&previousX>=block.x+block.w&&p.x<=block.x+block.w);
        if(!overlap(p,block)&&!beltCrossing)continue;
        if(this.breakables.includes(block)&&p.armored&&Math.abs(p.vx)>=170) {
          block.broken=true;this.emit('break',{x:block.x+block.w/2,y:block.y+block.h/2});continue;
        }
        if(horizontalMovement>0)p.x=block.x-p.w;else if(horizontalMovement<0)p.x=block.x+block.w;
        p.vx=0;
      }
      p.x=Math.max(0,Math.min(this.width-p.w,p.x));
      if(this.boss&&this.boss.active&&!this.boss.defeated)p.x=Math.min(p.x,this.bossGateX-p.w);
      const prevBottom=p.y+p.h,landingSpeed=p.vy;
      p.y+=p.vy*dt;p.grounded=false;
      if(p.doubleJumpLimitY!==null&&p.y<p.doubleJumpLimitY) {
        p.y=p.doubleJumpLimitY;p.vy=Math.max(0,p.vy);
      }
      if(p.vy>=0)p.doubleJumpLimitY=null;
      for(const block of this.solids)if(overlap(p,block)) {
        if(p.vy>=0) {p.y=block.y-p.h;p.vy=0;p.grounded=true;p.glide=.8;p.gliding=false;
          p.doubleJumpReady=false;p.doubleJumpLimitY=null;}
        else {p.y=block.y+block.h;p.vy=0;}
      }
      if(p.grounded&&!wasGrounded&&landingSpeed>100) {
        p.landingTime=.16;this.emit('land',{x:p.x+p.w/2,y:p.y+p.h});
      }
      this.bounceOnSpring(prevBottom,wasGrounded,landingSpeed);
      if(p.grounded&&p.buffer>0) {p.vy=-635;p.grounded=false;p.coyote=0;p.buffer=0;
        p.doubleJumpReady=true;p.doubleJumpLimitY=null;this.emit('jump');}
      for(const coin of this.coins)if(!coin.taken&&Math.hypot(p.x+p.w/2-coin.x,p.y+p.h/2-coin.y)<30) {
        coin.taken=true;this.collected++;this.emit('coin',{x:coin.x,y:coin.y});
        if(this.bonus&&!this.bonus.expired)this.bonus.collected++;
      }
      for(const item of this.items)if(!item.taken&&Math.hypot(p.x+17-item.x,p.y+23-item.y)<34) {
        if(item.type==='armor'&&!p.armored) {
          item.taken=true;p.armored=true;this.emit('transform',{x:item.x,y:item.y});
        } else if(item.type==='invincible') {
          item.taken=true;p.powerTime=BALANCE.powerDuration;
          this.emit('powerStart',{x:item.x,y:item.y,duration:BALANCE.powerDuration});
        } else if(item.type==='fire'&&p.weapon!=='fire') {
          item.taken=true;p.weapon='fire';p.fireCooldown=0;this.emit('weaponPickup',{x:item.x,y:item.y});
        }
      }
      for(const stamp of this.stamps)if(!stamp.taken&&Math.hypot(p.x+17-stamp.x,p.y+23-stamp.y)<34) {
        stamp.taken=true;this.stampCollected=true;this.emit('stamp',{x:stamp.x,y:stamp.y,id:stamp.id});
      }
      if(input.attack)this.shoot();
      this.updatePlayerProjectiles(dt);
      for(const enemy of this.enemies) {
        if(!enemy.alive)continue;
        enemy.x+=enemy.speed*enemy.dir*dt;
        if(enemy.x>enemy.max){enemy.x=enemy.max;enemy.dir=-1;}else if(enemy.x<enemy.min){enemy.x=enemy.min;enemy.dir=1;}
        if(overlap(p,enemy)) {
          if(p.powerTime>0) {
            enemy.alive=false;this.emit('powerHit',{x:enemy.x+enemy.w/2,y:enemy.y+enemy.h/2});
          } else if(p.vy>0&&prevBottom<=enemy.y+10) {
            enemy.alive=false;p.vy=-400;p.grounded=false;this.emit('stomp',{x:enemy.x,y:enemy.y});
          } else this.damage(enemy.x);
        }
      }
      const boss=this.boss;
      if(boss&&boss.active&&!boss.defeated&&!this.respawnTimer&&overlap(p,boss)) {
        if(p.powerTime>0) {
          if(boss.phase==='recovery') {
            if(this.hitBoss()){p.vy=-360;p.grounded=false;}
          } else if(!boss.powerGuardCooldown) {
            boss.powerGuardCooldown=.45;
            this.emit('bossGuard',{x:boss.x+boss.w/2,y:boss.y,source:'power'});
          }
        } else if(p.vy>0&&prevBottom<=boss.y+14) {
          p.y=boss.y-p.h;p.vy=-420;p.grounded=false;p.coyote=0;
          if(boss.phase==='recovery')this.hitBoss();
          else this.emit('bossGuard',{x:boss.x+boss.w/2,y:boss.y});
        } else this.damage(boss.x,'boss');
      }
      this.updateIceState();
      if(this.sceneId===this.stageId&&!this.respawnTimer) {
        const points=this.level.checkpoints||(this.level.checkpoint?[this.level.checkpoint]:[]);
        for(let index=this.checkpointIndex+1;index<points.length;index++) {
          const point=points[index];
          if(p.x>=point.triggerX&&p.x<(point.maxX??Infinity)&&p.y<point.y+81) {
            this.checkpoint=true;this.checkpointIndex=index;this.activeCheckpoint={...point};
            this.emit('checkpoint',{point:{...point},index,x:point.flagX??point.x,y:point.y+46});
          }
        }
      }
      if(p.y>850)this.die('fall');
      if(this.updateBonus(dt)){this.jumpWasDown=jump;this.interactWasDown=interact;return;}
      if(this.finish!==null&&p.x>=this.finish&&p.grounded&&!this.respawnTimer&&(!boss||boss.defeated)) {this.won=true;this.emit('win');}
      this.updatePortals();
      if(interact&&!this.interactWasDown&&!this.respawnTimer&&!this.won)this.enterPortal(this.nearPortal);
      this.jumpWasDown=jump;this.interactWasDown=interact;
    }
  }
  const first=catalogue.get('1-1');
  const api={World,BALANCE,platforms:first.platforms,width:first.width,finish:first.finish,totalCoins:first.totalCoins,overlap,getLevel:catalogue.get};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.ForestCore=api;
})(typeof window!=='undefined'?window:null);
