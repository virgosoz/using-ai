/* The lake journey uses the same lightweight Canvas renderer as the forest. */
(function(){
  'use strict';
  const base=window.ForestArt,TAU=Math.PI*2;
  const palettes={lakeside:['#b9dad6','#f5e7c7','#7fa9a0'],waterworks:['#c5d7cc','#efe2bc','#839c88'],mushrooms:['#b7cabb','#eee4d1','#92ae9b'],crystal:['#273f5d','#6b93a4','#4f7094'],ruins:['#c8d2b6','#e3d9bd','#7d9b80'],mist:['#344e5b','#a2bbb4','#536f74'],aqueduct:['#a5cdd2','#e7e7c9','#85a79d'],sanctuary:['#23494f','#8cabaa','#4d8480']};
  function oval(c,x,y,rx,ry,color){c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.fillStyle=color;c.fill();}
  function box(c,x,y,w,h,r,color){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=color;c.fill();}
  function gem(c,x,y,r,color){c.beginPath();c.moveTo(x,y-r);c.lineTo(x+r*.55,y-r*.1);c.lineTo(x+r*.4,y+r);c.lineTo(x-r*.4,y+r);c.lineTo(x-r*.55,y-r*.1);c.closePath();c.fillStyle=color;c.fill();c.strokeStyle='#d4faf07a';c.lineWidth=1;c.stroke();c.beginPath();c.moveTo(x,y-r);c.lineTo(x,y+r);c.stroke();}
  function mushroom(c,x,y,s,color){c.save();c.translate(x,y);c.scale(s,s);box(c,-8,-65,16,65,7,'#ded8ba');c.beginPath();c.moveTo(-46,-58);c.bezierCurveTo(-38,-116,34,-116,46,-58);c.quadraticCurveTo(0,-44,-46,-58);c.fillStyle=color;c.fill();oval(c,-17,-76,7,4,'#f4e9c6');oval(c,13,-86,8,5,'#f4e9c6');oval(c,28,-65,4,3,'#f4e9c6');c.restore();}
  function arch(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(x,y+w*.5,w*.2,h-w*.5);c.fillRect(x+w*.8,y+w*.5,w*.2,h-w*.5);c.strokeStyle=color;c.lineWidth=w*.2;c.beginPath();c.arc(x+w*.5,y+w*.5,w*.4,Math.PI,0);c.stroke();box(c,x-9,y+h-10,w+18,14,3,color);}
  function drawBackground(c,o){
    const {width:w,height:h,cameraX:cam=0,time:t=0,theme}=o,p=palettes[theme];if(!p){base.drawBackground(c,o);return;}
    c.save();const bg=c.createLinearGradient(0,0,0,h);bg.addColorStop(0,p[0]);bg.addColorStop(1,p[1]);c.fillStyle=bg;c.fillRect(0,0,w,h);
    const dark=['crystal','mist','sanctuary'].includes(theme),sunX=w*.78-cam*.015%70;
    const glow=c.createRadialGradient(sunX,126,10,sunX,126,175);glow.addColorStop(0,dark?'#b8efe133':'#fff4d180');glow.addColorStop(1,'#fff4d100');c.fillStyle=glow;c.fillRect(sunX-175,-49,350,350);
    if(theme!=='crystal')oval(c,sunX,126,32,32,dark?'#e2ead080':'#fff3cf');
    for(let k=0;k<3;k++){
      c.globalAlpha=.18+k*.12;c.fillStyle=p[2];const span=450-k*60,off=cam*(.06+k*.07)%span;
      c.beginPath();c.moveTo(-span,h);
      for(let i=-1;i<w/span+2;i++){const x=i*span-off,y=h*(.64+k*.09);c.lineTo(x,y+50);c.bezierCurveTo(x+65,y-90,x+240,y-90,x+span,y+50);}
      c.lineTo(w+span,h);c.fill();
    }c.globalAlpha=1;
    const water=c.createLinearGradient(0,h*.71,0,h);water.addColorStop(0,dark?'#72b4b633':'#acd5c880');water.addColorStop(1,dark?'#1e5b7370':'#83b7b6');c.fillStyle=water;c.fillRect(0,h*.71,w,h*.29);
    c.strokeStyle=dark?'#c6f0dc30':'#faf7df70';c.lineWidth=2;
    for(let i=0;i<22;i++){const x=((i*117-cam*.25+t*6)%(w+100)+w+100)%(w+100)-50,y=h*.74+(i*29)%(h*.24);c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+23,y+3,x+55,y);c.stroke();}
    if(theme==='waterworks')for(let i=-1;i<w/580+2;i++){
      const x=i*580-cam*.17%580+180,y=365;c.save();c.globalAlpha=.35;c.translate(x,y);c.rotate(t*.15);c.strokeStyle='#8f7b59';c.lineWidth=12;c.beginPath();c.arc(0,0,99,0,TAU);c.stroke();
      for(let j=0;j<12;j++){c.rotate(TAU/12);c.fillStyle='#9b8866';c.fillRect(-5,-110,10,110);box(c,-19,-111,38,16,3,'#b29d75');}oval(c,0,0,18,18,'#6b806a');c.restore();
    }
    if(['ruins','aqueduct','sanctuary'].includes(theme))for(let i=-1;i<w/260+2;i++){
      const x=i*260-cam*.19%260,y=theme==='aqueduct'?265:310;c.save();c.globalAlpha=.35;arch(c,x,y,120,220,dark?'#a5c5b0':'#859880');box(c,x-10,y-10,140,15,3,'#adbc98');
      c.strokeStyle='#b7c89c';c.lineWidth=5;c.beginPath();c.moveTo(x+3,y);c.quadraticCurveTo(x+46,y+70,x+16,y+135);c.stroke();c.restore();
    }
    if(theme==='sanctuary'){
      const x=w*.5;c.strokeStyle='#d7e9b454';c.lineWidth=3;c.beginPath();c.arc(x,240,113,0,TAU);c.stroke();c.beginPath();c.arc(x,240,97,0,TAU);c.stroke();
      for(let i=0;i<8;i++){const a=i*TAU/8;gem(c,x+Math.cos(a)*107,240+Math.sin(a)*107,8,'#c4d3a887');}
    }
    if(theme==='crystal')for(let i=-1;i<w/140+2;i++){
      const x=i*140-cam*.14%140;c.save();c.globalAlpha=.35;gem(c,x,70+(i%3)*24,90,'#6a8fac');gem(c,x+46,420+(i%2)*21,80,['#81c5c0','#a8a5c9'][Math.abs(i)%2]);c.restore();
    }
    if(theme==='mushrooms')for(let i=-1;i<w/230+2;i++){const x=i*230-cam*.21%230;c.save();c.globalAlpha=.55;mushroom(c,x,480,1.3+(Math.abs(i)%2)*.7,i%2?'#a57f98':'#c1949d');c.restore();}
    if(['lakeside','mist'].includes(theme))for(let i=-1;i<w/250+2;i++){c.save();c.globalAlpha=theme==='mist'?.22:.3;base.drawTree(c,i*250-cam*.17%250,510,1.15);c.restore();}
    if(theme==='lakeside'||theme==='waterworks')for(let i=-1;i<w/180+2;i++){
      const x=i*180-cam*.28%180;c.strokeStyle='#668e7960';c.lineWidth=3;for(let j=0;j<4;j++){c.beginPath();c.moveTo(x+j*12,520);c.quadraticCurveTo(x+j*12+14,457,x+j*12+7,439+j*5);c.stroke();oval(c,x+j*12+7,440+j*5,4,11,'#b4a27680');}
    }
    for(let i=0;i<3;i++){
      const y=190+i*145,x=((i*403-cam*.06+t*5)%(w+600)+w+600)%(w+600)-300;
      c.globalAlpha=theme==='mist'?.19:.10;oval(c,x,y,310,28,'#f4f6df');oval(c,x+340,y+18,250,18,'#f4f6df');
    }c.globalAlpha=1;
    if(dark)for(let i=0;i<20;i++){const x=((i*127-cam*.11+t*3)%(w+50)+w+50)%(w+50),y=90+(i*67)%440;c.globalAlpha=.18+(1+Math.sin(t*.8+i))*.16;oval(c,x,y,2.2,2.2,'#d7e9b1');}
    c.restore();
  }
  function drawSpring(c,{x,y,w=64,h=16,compression=0,time:t=0}){
    const squash=Math.min(1,Math.max(0,compression)),capH=h*(1-.35*squash);
    c.save();c.translate(x+w/2,y);c.strokeStyle='#826178';c.lineWidth=3;
    c.beginPath();c.moveTo(-9,capH+3);for(let i=0;i<5;i++)c.lineTo(i%2?9:-9,capH+4+i*3);c.stroke();
    c.fillStyle='#d791ad';c.beginPath();c.ellipse(0,capH*.5,w/2,capH*.65,0,Math.PI,TAU);c.lineTo(w/2,capH*.8);c.quadraticCurveTo(0,capH*1.25,-w/2,capH*.8);c.closePath();c.fill();
    for(const dx of [-18,0,18])oval(c,dx,capH*.35,4,2.5,'#fff1cd');c.strokeStyle='#fff0c4';c.lineWidth=2;c.beginPath();c.moveTo(-5,-8);c.lineTo(0,-14);c.lineTo(5,-8);c.stroke();c.restore();
  }
  function drawMovingPlatform(c,p){
    if(!palettes[p.theme]){base.drawMovingPlatform(c,p);return;}
    const {x,y,w,h=24}=p;c.save();box(c,x,y,w,h,7,'#8c785a');box(c,x+2,y-3,w-4,8,3,'#d5c495');
    for(let i=12;i<w-3;i+=24){c.strokeStyle='#ccb986';c.lineWidth=2;c.beginPath();c.moveTo(x+i,y+3);c.lineTo(x+i,y+h-2);c.stroke();}
    c.strokeStyle='#7ea9a0';c.lineWidth=2;c.beginPath();c.moveTo(x+8,y+h+5);c.quadraticCurveTo(x+w/2,y+h+10,x+w-8,y+h+5);c.stroke();c.restore();
  }
  function drawEnemy(c,e){
    if(e.kind!=='crab'&&e.kind!=='beetle'){base.drawEnemy(c,e);return;}
    const {x,y,w=38,h=24,time:t=0}=e;c.save();c.translate(x+w/2,y+h);c.scale(w/38,h/24);
    const crab=e.kind==='crab';c.strokeStyle=crab?'#a9705c':'#526f64';c.lineWidth=2.5;c.lineCap='round';
    for(const side of [-1,1])for(let i=0;i<3;i++){const k=Math.sin(t*8+i)*2;c.beginPath();c.moveTo(side*9,-9+i*2);c.lineTo(side*(17+i),-6+i*2+k);c.lineTo(side*(18+i),-1+k);c.stroke();}
    oval(c,0,-11,15,10,crab?'#d9a087':'#83a899');oval(c,-5,-14,4,3,crab?'#e6b49b':'#b5cab0');
    if(crab){for(const side of [-1,1]){c.beginPath();c.moveTo(side*13,-13);c.lineTo(side*20,-24);c.stroke();oval(c,side*21,-24,5,6,'#d9a087');}}
    else{c.strokeStyle='#587c6e';c.beginPath();c.moveTo(0,-20);c.lineTo(0,-4);c.stroke();}
    for(const side of [-1,1]){oval(c,side*5,-19,3,4,'#f1e8c9');oval(c,side*5,-19,1.4,2,'#435a50');}c.restore();
  }
  function drawProjectile(c,p){
    if(p.kind!=='wave'){base.drawProjectile(c,p);return;}
    c.save();const x=p.x+p.w/2,y=p.y+p.h;
    c.strokeStyle='#b8ecdb';c.lineWidth=4;c.beginPath();c.ellipse(x,y,p.w*.55,p.h*.9,0,Math.PI,TAU);c.stroke();
    c.strokeStyle='#e9f7c8';c.lineWidth=2;c.beginPath();c.ellipse(x,y,p.w*.3,p.h*.65,0,Math.PI,TAU);c.stroke();c.restore();
  }
  function drawBoss(c,b){
    if(b.kind!=='turtle'){base.drawBoss(c,b);return;}
    const {x,y,w=112,h=76,phase='idle',time:t=0}=b,sleep=b.defeated||phase==='defeated',weak=phase==='recovery';
    c.save();c.translate(x+w/2,y+h);c.scale(w/112,h/76);
    oval(c,0,-1,62,8,'#1a41433d');
    const lift=phase==='windup'?-5-Math.sin(t*10)*2:phase==='slam'?3:0;c.translate(0,lift);
    for(const side of [-1,1]){box(c,side*34-10,-17,24,18,8,'#95b298');box(c,side*13-9,-13,21,15,7,'#799d86');}
    oval(c,0,-30,49,28,'#789685');oval(c,0,-38,49,36,b.flash>0?'#f3e9b9':sleep?'#91b2a0':'#5e8b78');
    c.strokeStyle='#b6c8a1';c.lineWidth=2;
    c.beginPath();for(let i=0;i<6;i++){const a=i*TAU/6;c[i?'lineTo':'moveTo'](Math.cos(a)*22,-39+Math.sin(a)*19);}c.closePath();c.stroke();
    for(let i=0;i<6;i++){const a=i*TAU/6;c.beginPath();c.moveTo(Math.cos(a)*22,-39+Math.sin(a)*19);c.lineTo(Math.cos(a)*45,-39+Math.sin(a)*31);c.stroke();}
    oval(c,-18,-66,18,7,'#a6bd80');oval(c,12,-71,17,6,'#b8c993');box(c,-12,-86,19,18,3,'#c2c2a4');box(c,-17,-88,29,5,2,'#ded8b0');
    // The little shrine and moss make this guardian distinct from the storm owl.
    const dir=b.dir===1?1:-1;c.save();c.scale(dir,1);oval(c,51,-24,20,18,'#adc4a2');oval(c,57,-18,13,8,'#c9d5b2');
    if(sleep||weak){c.strokeStyle='#57786a';c.lineWidth=2;c.beginPath();c.arc(53,-28,5,0,Math.PI);c.stroke();}
    else{oval(c,53,-29,5,6,'#f7ecc4');oval(c,54,-29,2,3,'#466554');}
    c.strokeStyle='#66896e';c.lineWidth=1.5;c.beginPath();c.moveTo(59,-16);c.lineTo(65,-17);c.stroke();c.restore();
    if(phase==='windup'){c.strokeStyle='#eed6a4';c.lineWidth=2;c.setLineDash([6,6]);c.beginPath();c.ellipse(0,0,79,12,0,0,TAU);c.stroke();c.setLineDash([]);c.fillStyle='#f9df9c';c.font='bold 22px sans-serif';c.textAlign='center';c.fillText('!',0,-103);}
    if(phase==='slam'){c.strokeStyle='#cae9d5';c.lineWidth=3;c.beginPath();c.ellipse(0,0,90,16,0,Math.PI,TAU);c.stroke();}
    if(weak){c.strokeStyle='#ffe79e';c.lineWidth=3;c.beginPath();c.ellipse(0,-93,34,9,0,0,TAU);c.stroke();gem(c,-40,-93,5,'#ffe79e');gem(c,40,-93,5,'#ffe79e');}
    if(sleep){c.fillStyle='#eff1ce';c.font='bold 16px sans-serif';c.fillText('z Z',28,-83);}
    c.restore();
  }
  window.ForestArt=Object.freeze({...base,drawBackground,drawSpring,drawMovingPlatform,drawEnemy,drawProjectile,drawBoss});
}());
