/* Small, bounded canvas effects. Presentation only: never writes to the game world. */
(function (root) {
  'use strict';
  const TAU = Math.PI * 2;
  const PALETTE = ['#f1c774', '#a7d6b1', '#eb9d87', '#fff2c9', '#a8cbd4'];
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const easeOut = value => 1 - Math.pow(1 - value, 3);
  const finite = (value, fallback = 0) => Number.isFinite(value) ? value : fallback;

  function star(ctx, x, y, radius, fill, rotation = 0) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(rotation);
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const angle = i * Math.PI / 4 - Math.PI / 2;
      const size = i % 2 ? radius * .27 : radius;
      if (i === 0) ctx.moveTo(Math.cos(angle) * size, Math.sin(angle) * size);
      else ctx.lineTo(Math.cos(angle) * size, Math.sin(angle) * size);
    }
    ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); ctx.restore();
  }

  function roundRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath(); ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r); ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }

  class Effects {
    constructor({ reducedMotion = false, random = Math.random } = {}) {
      this.reducedMotion = !!reducedMotion;
      this.random = typeof random === 'function' ? random : Math.random;
      this.reset();
    }

    reset() {
      this.particles = []; this.rings = []; this.labels = []; this.moments = [];
      this.hitStopRemaining = 0; this.pose = null; this.shake = null; this.flash = null;
      this.finish = null; this.time = 0;
    }

    get finishProgress() { return this.finish ? clamp(this.finish.age / 2, 0, 1) : 0; }
    get finishActive() { return !!this.finish && this.finish.age < 2; }
    rand(min, max) { return min + clamp(finite(this.random(), .5), 0, 1) * (max - min); }

    addParticle(particle) {
      // Keep the important burst when coins arrive during a transformation.
      if (this.particles.length >= 220) {
        const index = this.particles.findIndex(p => (p.priority || 0) <= (particle.priority || 0));
        if (index < 0) return;
        this.particles.splice(index, 1);
      }
      this.particles.push({ age: 0, vx: 0, vy: 0, gravity: 0, rotation: 0, spin: 0,
        size: 4, life: .6, color: '#fff2c9', kind: 'spark', space: 'world', ...particle });
    }

    burst(x, y, count, { speed = 140, life = .65, colors = PALETTE, kind = 'spark',
      gravity = 150, size = 5, priority = 0, upward = false } = {}) {
      const total = this.reducedMotion ? Math.min(count, 5) : count;
      for (let i = 0; i < total; i++) {
        const angle = TAU * i / total + this.rand(-.22, .22);
        const velocity = this.rand(speed * .45, speed);
        this.addParticle({ x: x + Math.cos(angle) * 8, y: y + Math.sin(angle) * 8,
          vx: this.reducedMotion ? 0 : Math.cos(angle) * velocity,
          vy: this.reducedMotion ? 0 : Math.sin(angle) * velocity - (upward ? speed * .5 : 25),
          gravity: this.reducedMotion ? 0 : gravity, life: this.rand(life * .75, life * 1.15),
          size: this.rand(size * .5, size), color: colors[i % colors.length], kind,
          rotation: this.rand(0, TAU), spin: this.reducedMotion ? 0 : this.rand(-7, 7), priority });
      }
    }

    ring(x, y, color, radius, life, { flat = false, priority = 0, delay = 0 } = {}) {
      if (this.rings.length >= 12) {
        const index = this.rings.findIndex(r => r.priority <= priority);
        if (index < 0) return;
        this.rings.splice(index, 1);
      }
      this.rings.push({ x, y, color, radius, life, flat, age: -delay, priority });
    }

    label(x, y, text, color, life = .95) {
      if (this.labels.length >= 8) this.labels.shift();
      this.labels.push({ x, y, text, color, life, age: 0 });
    }

    impact(duration, intensity, shakeDuration, color, priority) {
      if (this.reducedMotion) return;
      this.hitStopRemaining = Math.max(this.hitStopRemaining, duration);
      if (!this.shake || priority >= this.shake.priority) {
        this.shake = { age: 0, life: shakeDuration, intensity, priority };
      }
      if (color && (!this.flash || priority >= this.flash.priority)) {
        this.flash = { age: 0, life: .26, color, priority };
      }
    }

    emit(type, data = {}) {
      const x = finite(data.x), y = finite(data.y);
      switch (type) {
        case 'bossFrost':
          this.impact(.055,4,.25,null,3);
          this.ring(x,y,'#b9eced',120,.5,{flat:true,priority:3});
          this.burst(x,y,22,{speed:190,life:.55,colors:['#cae9f0','#f3f6e8','#95c8dd'],kind:'shard',size:8,priority:3});
          this.label(x,y-40,'얼음 파동!','#557d9b',.75);
          break;
        case 'bossHail':
          this.ring(x,y,'#bdcbe8',70,.4,{priority:2});
          this.burst(x,y,16,{speed:130,life:.6,colors:['#c9edf0','#dfd4ef','#f6f9ed'],kind:'shard',size:7,gravity:120,priority:2});
          this.label(x,y-40,'고드름 낙하!','#5c7d9c',.8);
          break;
        case 'bossVolley':
          this.ring(x,y,'#e8c186',58,.35,{priority:2});
          this.burst(x,y,12,{speed:120,life:.5,colors:['#e2ba78','#f4e3b7','#b6a3a4'],kind:'shard',size:6,priority:2});
          this.label(x,y-32,data.height==='high'?'높은 톱니!':'낮은 톱니!','#9c785b',.7);
          break;
        case 'weaponPickup':
          this.impact(.075,2,.18,'#ffe0a4',3);
          this.ring(x,y,'#edb26c',78,.55,{priority:3});
          this.burst(x,y,24,{speed:170,life:.7,colors:['#eea265','#ffdca3','#fff5d0'],priority:3,upward:true});
          this.label(x,y-44,'불꽃 장착!','#a75d3e',1);
          break;
        case 'shoot':
          this.burst(x,y,5,{speed:65,life:.2,colors:['#ffc172','#fff4ca'],size:4,gravity:0});
          break;
        case 'shotHit':
          if(data.target==='enemy')this.impact(.035,1.6,.12,null,1);
          this.ring(x,y,'#ffd48e',32,.25);
          this.burst(x,y,10,{speed:120,life:.35,colors:['#e79b60','#ffe7a3','#fff8db'],size:5});
          break;
        case 'weaponLost':
          this.burst(x,y,10,{speed:85,life:.5,colors:['#c6a081','#e4ccac'],kind:'dust',size:6});
          break;
        case 'doubleJump':
          this.ring(x,y+17,'#b5d9bf',44,.35,{flat:true});
          this.burst(x,y+18,12,{speed:90,life:.4,colors:['#d2e5be','#fbefbe'],kind:'dust',size:6});
          this.label(x,y+7,'한 번 더!','#6d8c6e',.55);
          break;
        case 'spring':
          this.ring(x,y,'#edbdd0',62,.4,{flat:true,priority:2});
          this.burst(x,y,14,{speed:140,life:.5,colors:['#f4d9b0','#e6b5c9','#c5e4c7'],gravity:90,size:6,upward:true});
          this.label(x,y-28,'폴짝!','#956b83',.6);
          break;
        case 'bossSlam':
          this.impact(.07,5,.3,null,3);
          this.ring(x,y,'#add9cb',130,.55,{flat:true,priority:3});
          this.burst(x,y,20,{speed:190,life:.5,colors:['#bdd6c0','#e3dec0','#92b8ab'],kind:'dust',size:10,priority:3});
          break;
        case 'powerStart':
          this.impact(.09, 2, .2, '#fff0bd', 3);
          this.ring(x, y, '#f4d98b', 100, .7, { priority: 3 });
          this.burst(x, y, 32, { speed: 170, life: .85, colors: PALETTE, priority: 3 });
          this.label(x, y-45, '별빛 무적!', '#607d72', 1);
          break;
        case 'powerHit':
          this.ring(x, y, '#f4d98b', 48, .3, { priority: 2 });
          this.burst(x, y, 15, { speed: 160, life: .45, priority: 2 });
          break;
        case 'bossHit':
          this.impact(.12, 7, .35, '#ffe6b2', 5);
          this.ring(x, y, '#f5d293', 110, .5, { priority: 5 });
          this.burst(x, y, 28, { speed: 240, life: .8, colors: ['#f0dcad','#a5a9c4','#cddfc9'], kind: 'shard', size: 9, priority: 5 });
          this.label(x, y-40, '명중!', '#6b627d', .85);
          break;
        case 'bossGuard':
          this.ring(x, y, '#d4dce4', 36, .3, { priority: 1 });
          break;
        case 'bossDefeated':
          this.impact(.12, 4, .3, '#ffe6b2', 5);
          this.ring(x, y, '#f5d293', 160, 1.3, { priority: 5 });
          this.burst(x, y, 60, { speed: 230, life: 1.5, colors: PALETTE, size: 9, priority: 5, upward: true });
          this.label(x, y-65, data.message||'폭풍이 잠잠해졌어요!', '#5f7859', 2);
          break;
        case 'bonusComplete':
          this.ring(x, y, '#f5d293', 105, .8, { priority: 4 });
          this.burst(x, y, 38, { speed: 160, life: 1.1, size: 8, priority: 4, upward: true });
          this.label(x, y-50, '보너스 성공!', '#5f7859', 1.4);
          break;
        case 'transform':
          this.pose = { type, age: 0, life: .7 };
          this.moments.push({ type, x, y, age: 0, life: .88 });
          this.impact(.14, 3.5, .25, '#fff0bd', 4);
          this.ring(x, y, '#f4ce79', 104, .56, { priority: 4 });
          this.ring(x, y, '#bde0bd', 78, .68, { priority: 4, delay: .09 });
          this.burst(x, y, 36, { speed: 200, life: .85, gravity: 100, size: 8, priority: 4 });
          this.label(x, y - 49, '갑옷 변신!', '#5f7859', 1.05);
          break;
        case 'armorLost':
          this.pose = { type, age: 0, life: .58 };
          this.moments.push({ type, x, y, age: 0, life: .5 });
          this.impact(.1, 5.5, .3, '#f2b099', 4);
          this.ring(x, y, '#dc8e79', 75, .42, { priority: 4 });
          this.burst(x, y, 18, { speed: 175, life: .65, gravity: 480,
            colors: ['#976849', '#bc9261', '#e7c685', '#fff0c5'], kind: 'shard', size: 9, priority: 4 });
          this.burst(x, y, 10, { speed: 110, life: .4, colors: ['#fff5d8', '#edba98'], priority: 4 });
          this.label(x, y - 45, '갑옷 해제', '#9a5947', .8);
          break;
        case 'break':
          this.impact(.075, 6, .25, '#e4c99b', 3);
          this.ring(x, y, '#f2d19b', 69, .38, { priority: 3 });
          this.burst(x, y, 28, { speed: 220, life: .68, gravity: 590,
            colors: ['#8c6346', '#bc9167', '#e2ba83', '#f3d9a5'], kind: 'wood', size: 12, priority: 3 });
          this.burst(x, y, 12, { speed: 120, life: .4, colors: ['#efe1bf'], kind: 'dust', size: 10, priority: 3 });
          this.label(x, y - 28, '쿵!', '#866244', .57);
          break;
        case 'stomp':
          this.impact(.05, 3, .19, null, 2);
          this.ring(x, y, '#e6b56b', 47, .27, { flat: true, priority: 2 });
          this.burst(x, y, 14, { speed: 160, life: .42, colors: ['#f8d079', '#fff2c6'], size: 7, priority: 2, upward: true });
          this.label(x, y - 22, '톡!', '#8c6b43', .48);
          break;
        case 'land':
          this.ring(x, y + 1, '#ddd8b9', 29, .28, { flat: true });
          this.burst(x, y, 7, { speed: 51, life: .28, colors: ['#e2dfc4', '#f5ebd0'], kind: 'dust', gravity: 25, size: 5 });
          break;
        case 'coin':
          this.burst(x, y, 6, { speed: 75, life: .38, colors: ['#edc069', '#fff3c9'], gravity: 30, size: 5 });
          break;
        case 'stamp':
        case 'checkpoint':
          this.ring(x, y, type === 'stamp' ? '#e4b775' : '#99c7a6', 72, .65, { priority: 2 });
          this.burst(x, y, 22, { speed: 118, life: .8, gravity: 70, size: 7, priority: 2 });
          this.label(x, y - 46, type === 'stamp' ? '기념 우표 발견!' : '여기서 다시 출발!', '#64856b', 1.05);
          break;
        case 'death':
          this.impact(.08, 4, .3, null, 4);
          this.moments.push({ type, x, y, age: 0, life: .5 });
          this.burst(x, y, 12, { speed: 95, life: .42, colors: ['#e7ad94', '#f4d8bb'], kind: 'dust', size: 8, priority: 3 });
          break;
        case 'win':
          this.finish = { age: 0, x, y, confettiSent: false };
          this.impact(.09, 2.2, .18, '#ffebaf', 5);
          this.ring(x, y, '#ecc674', 122, .8, { priority: 5 });
          this.ring(x, y, '#badcb8', 87, 1, { priority: 5, delay: .15 });
          this.burst(x, y, 42, { speed: 180, life: 1.4, gravity: 120, size: 8, priority: 5, upward: true });
          break;
        default: break;
      }
      if (this.moments.length > 12) this.moments.splice(0, this.moments.length - 12);
    }

    update(delta) {
      const dt = clamp(finite(delta), 0, .1);
      this.time += dt;
      this.hitStopRemaining = Math.max(0, this.hitStopRemaining - dt);
      for (const p of this.particles) {
        p.age += dt; p.vy += p.gravity * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rotation += p.spin * dt;
      }
      this.particles = this.particles.filter(p => p.age < p.life);
      for (const collection of [this.rings, this.labels, this.moments]) {
        for (const effect of collection) effect.age += dt;
      }
      this.rings = this.rings.filter(r => r.age < r.life);
      this.labels = this.labels.filter(label => label.age < label.life);
      this.moments = this.moments.filter(moment => moment.age < moment.life);
      for (const key of ['pose', 'shake', 'flash']) {
        if (this[key]) { this[key].age += dt; if (this[key].age >= this[key].life) this[key] = null; }
      }
      if (this.finish) {
        this.finish.age = Math.min(2, this.finish.age + dt);
        if (this.finish.age >= .48 && !this.finish.confettiSent) {
          this.finish.confettiSent = true;
          if (!this.reducedMotion) {
            for (let i = 0; i < 60; i++) {
              // Screen particles use normalized coordinates and remain responsive.
              this.addParticle({ space: 'screen', x: this.rand(.16, .84), y: this.rand(.08, .23),
                vx: this.rand(-.17, .17), vy: this.rand(-.24, .025), gravity: .32,
                life: this.rand(1.1, 1.6), kind: i % 4 ? 'confetti' : 'spark',
                size: this.rand(3, 7), color: PALETTE[i % PALETTE.length], spin: this.rand(-7, 7), priority: 5 });
            }
          }
        }
      }
    }

    cameraOffset() {
      if (this.reducedMotion || !this.shake) return { x: 0, y: 0 };
      const s = this.shake, strength = s.intensity * Math.pow(1 - s.age / s.life, 2);
      return { x: Math.sin(s.age * 157) * strength, y: Math.cos(s.age * 193) * strength * .65 };
    }

    actorPose(player = {}) {
      const baseScale = player.armored ? 1.15 : 1;
      const result = { scaleX: baseScale, scaleY: baseScale, offsetY: 0, rotation: 0, armored: !!player.armored };
      if (this.reducedMotion) return result;
      if (this.finishActive && this.finish.age < 1.15) {
        // Feet stay anchored by the renderer; only the celebratory hop lifts them.
        const t = clamp((this.finish.age - .15) / .85, 0, 1);
        result.offsetY = -Math.abs(Math.sin(t * Math.PI * 2)) * 17 * (1 - t * .35);
        result.scaleX *= 1 - Math.sin(t * Math.PI * 4) * .045;
        result.scaleY *= 1 + Math.sin(t * Math.PI * 4) * .065;
      }
      if (!this.pose) return result;
      const t = this.pose.age / this.pose.life;
      if (this.pose.type === 'transform') {
        result.armored = t >= .19 ? !!player.armored : false;
        if (t < .19) { const q = Math.sin(t / .19 * Math.PI / 2); result.scaleX = 1 + .25 * q; result.scaleY = 1 - .24 * q; }
        else {
          const q = (t - .19) / .81;
          const growing = 1 + (baseScale - 1) * easeOut(clamp(q * 2.5, 0, 1));
          result.scaleX = growing + Math.sin(q * Math.PI * 3) * .19 * (1 - q);
          result.scaleY = growing + Math.sin(q * Math.PI * 3 + .3) * .31 * (1 - q);
          result.offsetY = -Math.sin(q * Math.PI) * 9;
        }
      } else {
        result.armored = t < .16;
        const pulse = Math.sin(t * Math.PI * 3) * (1 - t);
        const shrinking = 1 + .15 * (1 - easeOut(clamp(t * 2, 0, 1)));
        result.scaleX = shrinking - pulse * .18; result.scaleY = shrinking + pulse * .2;
        result.rotation = Math.sin(t * Math.PI * 6) * .08 * (1 - t);
        result.offsetY = -Math.sin(t * Math.PI) * 4;
      }
      return result;
    }

    drawParticle(ctx, p, x = p.x, y = p.y) {
      const t = clamp(p.age / p.life, 0, 1);
      ctx.save(); ctx.globalAlpha = Math.min(1, (1 - t) * 3) * (p.kind === 'dust' ? .4 : 1);
      ctx.translate(x, y); ctx.rotate(p.rotation); ctx.fillStyle = p.color;
      if (p.kind === 'spark') star(ctx, 0, 0, p.size * (.55 + (1 - t) * .45), p.color);
      else if (p.kind === 'dust') {
        ctx.beginPath(); ctx.ellipse(0, 0, p.size * (1 + t), p.size * (.55 + t * .45), 0, 0, TAU); ctx.fill();
      } else if (p.kind === 'shard') {
        ctx.beginPath(); ctx.moveTo(-p.size, -p.size * .5); ctx.lineTo(p.size * .3, -p.size * .8);
        ctx.lineTo(p.size, p.size * .35); ctx.lineTo(-p.size * .4, p.size * .7); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#e7ca8e'; ctx.lineWidth = 1; ctx.stroke();
      } else {
        ctx.scale(1, p.kind === 'confetti' ? .3 + Math.abs(Math.cos(p.age * 9)) * .7 : 1);
        ctx.fillRect(-p.size * .7, -p.size * .3, p.size * 1.4, p.size * .6);
        if (p.kind === 'wood') { ctx.fillStyle = '#f1d6a2'; ctx.fillRect(-p.size * .5, -p.size * .22, p.size, 1); }
      }
      ctx.restore();
    }

    drawWorld(ctx, { player } = {}) {
      ctx.save();
      for (const r of this.rings) {
        if (r.age < 0) continue;
        const t = r.age / r.life;
        const radius = this.reducedMotion ? Math.min(r.radius, 40) : 9 + easeOut(t) * r.radius;
        ctx.globalAlpha = (1 - t) * .72; ctx.strokeStyle = r.color; ctx.lineWidth = (1 - t) * 4 + 1;
        ctx.beginPath(); ctx.ellipse(r.x, r.y, radius, r.flat ? radius * .22 : radius, 0, 0, TAU); ctx.stroke();
      }
      ctx.globalAlpha = 1;
      for (const m of this.moments) if (m.type === 'transform') {
        const t = m.age / m.life;
        const cx = player ? player.x + player.w / 2 : m.x;
        const cy = player ? player.y + player.h / 2 : m.y;
        const glow = ctx.createRadialGradient(cx, cy, 6, cx, cy, 78);
        glow.addColorStop(0, 'rgba(255,229,158,.45)'); glow.addColorStop(1, 'rgba(255,229,158,0)');
        ctx.globalAlpha = Math.sin(Math.min(1, t * 2) * Math.PI / 2) * (1 - t);
        ctx.fillStyle = glow; ctx.fillRect(cx - 78, cy - 78, 156, 156);
        if (!this.reducedMotion) {
          ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * .5);
          ctx.globalAlpha = Math.sin(t * Math.PI) * .32; ctx.fillStyle = '#ffe8a6';
          for (let i = 0; i < 10; i++) {
            ctx.rotate(TAU / 10); ctx.beginPath(); ctx.moveTo(24, -2); ctx.lineTo(84 + t * 20, -8);
            ctx.lineTo(84 + t * 20, 8); ctx.lineTo(24, 2); ctx.closePath(); ctx.fill();
          }
          ctx.restore();
          ctx.globalAlpha = Math.sin(t * Math.PI);
          for (let i = 0; i < 4; i++) {
            const angle = t * 6 + i * Math.PI / 2;
            star(ctx, cx + Math.cos(angle) * 42, cy + Math.sin(angle) * 34, 6, i % 2 ? '#fff5d2' : '#b7d9ab', angle);
          }
        }
      }
      ctx.globalAlpha = 1;
      for (const p of this.particles) if (p.space === 'world') this.drawParticle(ctx, p);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
      for (const label of this.labels) {
        const t = label.age / label.life;
        const rise = this.reducedMotion ? 0 : easeOut(t) * 24;
        ctx.globalAlpha = Math.min(1, (1 - t) * 4);
        ctx.font = '800 21px "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif';
        ctx.strokeStyle = '#fff8e7'; ctx.lineWidth = 5; ctx.strokeText(label.text, label.x, label.y - rise);
        ctx.fillStyle = label.color; ctx.fillText(label.text, label.x, label.y - rise);
      }
      ctx.restore();
    }

    drawScreen(ctx, { width, height, playerScreenX, playerScreenY, mailboxScreenX, mailboxScreenY } = {}) {
      if (!(width > 0 && height > 0)) return;
      ctx.save();
      if (this.flash && !this.reducedMotion) {
        ctx.globalAlpha = (1 - this.flash.age / this.flash.life) * .13;
        ctx.fillStyle = this.flash.color; ctx.fillRect(0, 0, width, height); ctx.globalAlpha = 1;
      }
      for (const moment of this.moments) if (moment.type === 'death') {
        const strength = Math.sin(moment.age / moment.life * Math.PI) * .24;
        if (!this.reducedMotion) {
          const gradient = ctx.createRadialGradient(width / 2, height / 2, height * .2, width / 2, height / 2, width * .65);
          gradient.addColorStop(0, 'rgba(191,105,89,0)'); gradient.addColorStop(1, `rgba(191,105,89,${strength})`);
          ctx.fillStyle = gradient; ctx.fillRect(0, 0, width, height);
        }
      }
      if (this.finishActive) {
        const age = this.finish.age;
        // The letter floats away before the delivery stamp lands.
        if (age < .9 && !this.reducedMotion) {
          const t = clamp(age / .85, 0, 1), q = easeOut(t);
          const startX = finite(playerScreenX, width * .5), startY = finite(playerScreenY, height * .64) - 25;
          const targetX = finite(mailboxScreenX, width * .5), targetY = finite(mailboxScreenY, height * .28);
          const ex = startX + (targetX - startX) * q;
          const ey = startY + (targetY - startY) * q - Math.sin(t * Math.PI) * 72;
          ctx.save(); ctx.translate(ex, ey); ctx.rotate(Math.sin(t * Math.PI) * -.2);
          ctx.globalAlpha = Math.min(1, (1 - t) * 4);
          ctx.shadowColor = 'rgba(104,83,49,.18)'; ctx.shadowBlur = 12; ctx.shadowOffsetY = 5;
          roundRect(ctx, -19, -13, 38, 26, 4); ctx.fillStyle = '#fff4d6'; ctx.fill(); ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
          ctx.strokeStyle = '#ae8454'; ctx.lineWidth = 1.6; ctx.stroke();
          ctx.beginPath(); ctx.moveTo(-17, -10); ctx.lineTo(0, 2); ctx.lineTo(17, -10); ctx.stroke();
          ctx.fillStyle = '#bc7f65'; ctx.beginPath(); ctx.arc(0, 2, 3, 0, TAU); ctx.fill(); ctx.restore();
        }
        if (age >= .4) {
          const entry = clamp((age - .4) / .3, 0, 1);
          const exit = age > 1.82 ? clamp((2 - age) / .18, 0, 1) : 1;
          const bannerWidth = Math.min(400, width - 40), bannerHeight = 112;
          const centerY = height * .29;
          ctx.save(); ctx.translate(width / 2, centerY);
          ctx.globalAlpha = this.reducedMotion ? 1 : Math.min(1, entry * 3) * exit;
          const scale = this.reducedMotion ? 1 : .88 + easeOut(entry) * .12;
          ctx.scale(scale, scale);
          ctx.fillStyle = '#97b99c';
          for (const side of [-1, 1]) {
            ctx.beginPath(); ctx.moveTo(side * (bannerWidth / 2 - 5), -23);
            ctx.lineTo(side * (bannerWidth / 2 + 18), -18); ctx.lineTo(side * (bannerWidth / 2 + 10), 5);
            ctx.lineTo(side * (bannerWidth / 2 + 18), 26); ctx.lineTo(side * (bannerWidth / 2 - 5), 24); ctx.fill();
          }
          ctx.shadowColor = 'rgba(74,83,58,.14)'; ctx.shadowBlur = 20; ctx.shadowOffsetY = 8;
          roundRect(ctx, -bannerWidth / 2, -bannerHeight / 2, bannerWidth, bannerHeight, 19);
          ctx.fillStyle = '#fff4d6'; ctx.fill(); ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
          ctx.lineWidth = 1.5; ctx.strokeStyle = '#d6b67a'; ctx.stroke();
          roundRect(ctx, -bannerWidth / 2 + 7, -bannerHeight / 2 + 7, bannerWidth - 14, bannerHeight - 14, 14);
          ctx.strokeStyle = '#e7d6ac'; ctx.lineWidth = 1; ctx.stroke();
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#8a805b';
          ctx.font = '700 11px system-ui, sans-serif'; ctx.fillText('CLOUD FOREST POST', 0, -30);
          ctx.font = `800 ${Math.min(35, bannerWidth / 9)}px "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif`;
          ctx.fillStyle = '#4d7259'; ctx.fillText('배달 완료!', 0, 1);
          ctx.font = '600 13px "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif';
          ctx.fillStyle = '#8f7a54'; ctx.fillText('편지가 무사히 도착했어요', 0, 32);
          star(ctx, -bannerWidth / 2 + 31, 0, 10, '#dcb56a'); star(ctx, bannerWidth / 2 - 31, 0, 10, '#dcb56a');
          ctx.restore();
        }
      }
      for (const p of this.particles) if (p.space === 'screen') this.drawParticle(ctx, p, p.x * width, p.y * height);
      ctx.restore();
    }
  }

  const api = { Effects };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ForestEffects = api;
})(typeof window !== 'undefined' ? window : null);
