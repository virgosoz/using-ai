/* Fire flowers for the courier: all art stays local and resolution independent. */
(function(){
  'use strict';
  const base=window.ForestArt,TAU=Math.PI*2;
  function flame(c,x,y,size,time=0){
    c.save();c.translate(x,y);c.scale(size/20,size/20);
    c.beginPath();c.moveTo(0,-22);c.bezierCurveTo(9,-10,18,-4,13,8);c.bezierCurveTo(6,22,-15,16,-13,3);c.quadraticCurveTo(-12,-5,-5,-12);c.quadraticCurveTo(-6,0,0,-22);
    c.fillStyle='#e88044';c.fill();c.strokeStyle='#ac5e40';c.lineWidth=1.6;c.stroke();
    c.beginPath();c.moveTo(1,-8);c.bezierCurveTo(12,3,7,14,-1,13);c.bezierCurveTo(-9,12,-7,3,1,-8);c.fillStyle='#ffdc82';c.fill();
    c.beginPath();c.ellipse(0,7,3,5,0,0,TAU);c.fillStyle='#fff6ce';c.fill();c.restore();
  }
  function drawFireItem(c,{x,y,time=0}){
    y+=Math.sin(time*2.5+x)*4;c.save();
    const g=c.createRadialGradient(x,y,3,x,y,36);g.addColorStop(0,'#ffc97466');g.addColorStop(1,'#ffc97400');c.fillStyle=g;c.fillRect(x-36,y-36,72,72);
    c.strokeStyle='#d7a565';c.lineWidth=1;c.setLineDash([2,5]);c.beginPath();c.arc(x,y,27,0,TAU);c.stroke();c.setLineDash([]);
    flame(c,x,y-4,18,time);c.fillStyle='#8e6846';c.beginPath();c.ellipse(x,y+12,11,6,0,0,TAU);c.fill();
    c.strokeStyle='#e4bc73';c.lineWidth=1.5;for(let i=-6;i<=6;i+=6){c.beginPath();c.moveTo(x+i-2,y+9);c.lineTo(x+i+2,y+15);c.stroke();}
    c.restore();
  }
  function drawFireProjectile(c,{x,y,w=18,h=16,vx=600,time=0}){
    const dir=vx<0?-1:1;c.save();c.translate(x+w/2,y+h/2);c.scale(dir,1);
    for(let i=3;i>0;i--){c.globalAlpha=.12+(3-i)*.08;c.fillStyle='#eeaa63';c.beginPath();c.ellipse(-i*9,Math.sin(time*22+i)*2,10,3+i*.8,0,0,TAU);c.fill();}
    c.globalAlpha=1;c.fillStyle='#ed8b48';c.beginPath();c.ellipse(0,0,11,8,0,0,TAU);c.fill();
    c.fillStyle='#fff2ab';c.beginPath();c.ellipse(3,-1,6,4,0,0,TAU);c.fill();c.restore();
  }
  function drawPlayer(c,p){
    base.drawPlayer(c,p);
    if(p.weapon==='fire'){
      c.save();c.translate(p.x+p.w/2,p.y+p.h*.5);c.scale(p.facing<0?-1:1,1);
      c.fillStyle='#c86841';c.beginPath();c.roundRect(3,5,14,6,3);c.fill();
      flame(c,18,3,7,p.time);c.restore();
    }
  }
  window.ForestArt=Object.freeze({...base,drawFireItem,drawFireProjectile,drawPlayer});
})();
