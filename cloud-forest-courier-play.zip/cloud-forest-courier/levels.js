(function (root) {
  'use strict';
  const blocks = rows => rows.map(([x,y,w,h]) => ({x,y,w,h}));
  const acorns = (prefix, rows) => {
    const result=[];
    for(const [x,y,n,gap=46] of rows) for(let i=0;i<n;i++) {
      result.push({id:`${prefix}-acorn-${result.length+1}`,x:x+i*gap,y});
    }
    return result;
  };
  const snail = (x,y,min,max,speed=38) => ({x,y,w:38,h:24,min,max,speed});
  const levels = {
    '1-1': {
      id:'1-1', name:'바람이 머무는 숲', subtitle:'익숙한 길에서, 새로운 여행을 시작해요',
      theme:'forest', width:8450, finish:8105, spawn:{x:100,y:469},
      checkpoint:{x:2550,y:469,triggerX:2490,maxX:2940,flagX:2520},
      platforms:blocks([
        [0,515,1300,180],[610,475,120,40],[860,435,115,80],
        [1430,515,1510,180],[1950,470,130,45],[2160,425,140,90],
        [2920,610,420,90],[3190,563,110,47],[3220,515,640,180],
        [4140,485,570,210],[4710,545,1740,150],
        [4800,440,190,24],[5100,350,180,24],[5520,330,170,24],[5870,390,180,24],
        [6450,515,640,180],[7280,515,1170,180]
      ]),
      coins:acorns('1-1',[
        [340,467,4],[637,432,2],[875,392,2],[1260,408,5,44],
        [1690,467,3],[1990,425,2],[2185,383,2],[2730,467,3],[2970,383,5,45],
        [3480,467,4],[3860,386,6,48],[4330,436,4],[4840,396,3],[5125,305,3],
        [5340,238,4,44],[5550,285,3],[5900,346,3],[5040,497,4],[6260,497,3],
        [6690,467,4],[7050,405,5,48],[7520,467,3],[7930,467,3]
      ]),
      enemies:[snail(1760,491,1640,1880),snail(3540,491,3430,3740,43),
        snail(4490,461,4250,4610,35),snail(5630,521,5440,5840,40),snail(7730,491,7670,7890,42),
        snail(5160,326,5120,5220,31),snail(5930,366,5890,5980,33),snail(6040,521,6000,6100,40)],
      items:[{id:'forest-fire',type:'fire',x:240,y:475},
        {id:'forest-spare-fire',type:'fire',x:4910,y:505}],breakables:[],portals:[],stamps:[],
      trees:[{x:160,y:515,s:1.15},{x:1100,y:515,s:.85},{x:1540,y:515,s:1.1},
        {x:2370,y:515,s:1},{x:3750,y:515,s:1.1},{x:4580,y:485,s:.9},
        {x:5280,y:545,s:.8},{x:6390,y:545,s:1.1},{x:6970,y:515,s:.9},{x:7980,y:515,s:1.2}],
      signs:[[420,504,'도토리를 따라가요 →'],[1120,504,'Space · 점프'],
        [2850,504,'떨어질 때 Space 꾹'],[3450,504,'착지하면 잎사귀 충전'],
        [4910,533,'위는 도전, 아래는 산책'],[7440,503,'우편함이 보여요 →']],
      areas:[{x:0,name:'바람이 머무는 숲'},{x:1430,name:'도토리 오솔길'},
        {x:2490,name:'잎사귀 바람길'},{x:4710,name:'구름 위 갈림길'},{x:7280,name:'편지가 닿는 곳'}]
    },
    '1-2': {
      id:'1-2',name:'껍질나무 길',subtitle:'도토리 갑옷을 입고, 나무 속 비밀을 찾아요',
      theme:'amber',width:4200,finish:3910,spawn:{x:100,y:469},
      checkpoint:{x:1970,y:469,triggerX:1900,maxX:2090,flagX:1940},
      platforms:blocks([
        [0,515,2100,180],[2240,515,980,180],[3400,515,800,180],
        [700,455,155,60],[1600,455,170,60],
        [2480,455,170,60],[2750,395,165,24],[3020,350,125,24],
        [3580,455,155,60]
      ]),
      coins:acorns('1-2',[
        [235,472,3],[560,472,3],[728,409,3,42],[915,472,3],[1090,472,3,38],
        [1280,365,3,44],[1470,472,2],[1630,410,3],[1850,472,3],
        [2085,410,5,43],[2370,472,2],[2510,411,3],[2775,351,3,43],
        [3045,306,2],[3210,409,5,43],[3470,472,2],[3610,411,3],[3800,472,3]
      ]),
      enemies:[snail(1710,431,1620,1725,30),snail(2345,491,2280,2420,34),
        snail(2870,491,2700,2960,38),snail(3800,491,3750,3860,30),
        snail(2790,371,2760,2850,32),snail(3050,326,3030,3080,29),snail(1100,491,1080,1120,34)],
      items:[{id:'first-armor',type:'armor',x:410,y:475},{id:'spare-armor',type:'armor',x:1010,y:475},
        {id:'hollow-fire',type:'fire',x:175,y:475},{id:'hollow-spare-fire',type:'fire',x:3060,y:475}],
      breakables:[{id:'hollow-wall',x:1240,y:421,w:56,h:94}],
      portals:[{id:'hollow-entrance',x:1340,y:431,w:64,h:84,label:'나무 속 비밀방',
        target:'1-2-secret',lockedBy:'hollow-wall',returnSpawn:{x:1450,y:469}}],
      stamps:[],
      trees:[{x:145,y:515,s:1.02},{x:595,y:515,s:.8},{x:1110,y:515,s:1.2},
        {x:1450,y:515,s:1.2},{x:1870,y:515,s:.9},{x:2390,y:515,s:1.1},
        {x:2840,y:515,s:1.0},{x:3510,y:515,s:1.1},{x:4000,y:515,s:1.15}],
      signs:[[255,504,'빛나는 껍질 도토리를 먹어봐요 →'],[580,504,'갑옷을 입으면 금 간 벽을 부술 수 있어요'],
        [1115,504,'속도를 내서 벽으로 달려요 →'],[1510,504,'기본 모습도 점프로 지나갈 수 있어요'],
        [2030,504,'공중에서 Space 꾹 · 활공'],[2680,504,'높은 곳에도 도토리가 있어요'],
        [3820,504,'두 번째 편지가 도착해요 →']],
      areas:[{x:0,name:'껍질나무 오솔길'},{x:900,name:'속삭이는 나무'},
        {x:1800,name:'황금빛 우체국'},{x:2240,name:'도토리 가지길'},{x:3400,name:'햇살 배달길'}]
    },
    '1-3': {
      id:'1-3',name:'오래된 나무 속',subtitle:'나무의 나이테를 따라, 잊힌 우표를 찾아요',
      theme:'cave',width:4200,finish:3930,spawn:{x:100,y:469},
      hint:'아래는 배달길, 위는 우표를 찾는 나이테 길이에요.',
      checkpoint:{x:2290,y:494,triggerX:2220,maxX:2470,flagX:2260},
      platforms:blocks([
        [0,515,930,180],[1060,485,940,210],[2150,540,770,155],[3080,515,1120,180],
        [390,450,180,65],[650,385,180,24],[930,325,190,24],[1240,295,210,24],
        [1640,360,180,24],[2420,470,160,70],[2700,405,160,24],[3330,450,160,65]
      ]),
      coins:acorns('1-3',[
        [225,472,3,42],[415,407,3,42],[675,342,3,42],[960,282,3,42],
        [1280,252,3,42],[1710,442,4,42],[1970,390,5,42],[2240,497,3,42],
        [2450,427,3,42],[2725,362,3,42],[2880,435,5,43],[3160,472,3,42],
        [3360,407,3,42],[3710,472,4,42]
      ]),
      enemies:[snail(1550,461,1490,1620,32),snail(2660,516,2620,2780,38),
        snail(3700,491,3630,3820,40),snail(1700,336,1660,1760,33),snail(1340,461,1315,1365,37)],
      items:[{id:'root-armor',type:'armor',x:300,y:475},
        {id:'root-fire',type:'fire',x:170,y:475},{id:'root-spare-fire',type:'fire',x:2390,y:500}],breakables:[],portals:[],
      stamps:[{id:'old-tree-postage',x:1350,y:230}],
      trees:[{x:150,y:515,s:.82},{x:1150,y:485,s:1.15},{x:1840,y:485,s:.86},
        {x:2320,y:540,s:1.08},{x:3190,y:515,s:1.15},{x:4050,y:515,s:.93}],
      signs:[[200,504,'나이테를 따라 위로 올라갈 수도 있어요'],[810,504,'틈 앞에서 점프 · Space 꾹'],
        [1160,474,'오래된 우표는 높은 가지에 있어요'],[2250,529,'중간 우체통에서 잠깐 쉬어요'],
        [3130,504,'빛이 보이는 쪽으로 →']],
      areas:[{x:0,name:'나무뿌리 입구'},{x:1060,name:'오래된 나이테'},
        {x:2150,name:'뿌리 아래 산책길'},{x:3080,name:'나무 사이 햇빛'}]
    },
    '1-4': {
      id:'1-4',name:'흔들리는 구름다리',subtitle:'움직이는 구름을 타고, 잠깐 보너스 배달을 해요',
      theme:'clouds',width:4000,finish:3740,spawn:{x:100,y:469},
      hint:'움직이는 구름 발판에 올라타면 함께 이동해요. 별 문은 보너스 방이에요.',
      checkpoint:{x:2060,y:434,triggerX:1990,maxX:2240,flagX:2030},
      platforms:blocks([
        [0,515,820,180],[970,515,800,180],[1930,480,850,215],[2940,515,1060,180],
        [400,450,170,65],[690,385,150,24],[1290,390,170,24],[1790,330,170,24],
        [2210,415,180,65],[2530,350,150,24],[3220,450,180,65]
      ]),
      movingPlatforms:[
        {id:'first-drifting-cloud',x:800,y:430,w:145,h:24,axis:'x',range:155,speed:46},
        {id:'rising-cloud',x:1560,y:320,w:135,h:24,axis:'y',range:110,speed:35},
        {id:'last-drifting-cloud',x:2760,y:400,w:140,h:24,axis:'x',range:140,speed:54}
      ],
      coins:acorns('1-4',[
        [220,472,3,42],[428,407,3,42],[710,342,3,42],[815,353,4,44],
        [1050,472,3,42],[1320,347,3,42],[1795,287,4,44],[1990,437,3,42],
        [2240,372,3,42],[2550,307,3,42],[2760,340,4,46],[3030,472,3,42],
        [3250,407,3,42],[3550,472,4,42]
      ]),
      enemies:[snail(1630,491,1580,1700,35),snail(2460,456,2410,2540,32),
        snail(3580,491,3500,3660,39),snail(1840,306,1810,1890,31),snail(1420,491,1390,1450,36)],
      items:[{id:'cloud-armor',type:'armor',x:290,y:475},
        {id:'cloud-fire',type:'fire',x:175,y:475},{id:'cloud-spare-fire',type:'fire',x:2140,y:440}],breakables:[],
      portals:[{id:'cloud-bonus-entrance',x:1130,y:431,w:64,h:84,label:'25초 도토리 보너스',
        target:'1-4-bonus',returnSpawn:{x:1280,y:469}}],stamps:[],
      trees:[{x:145,y:515,s:.8},{x:1010,y:515,s:.75},{x:2080,y:480,s:.9},
        {x:3120,y:515,s:.8},{x:3840,y:515,s:1}],
      signs:[[195,504,'움직이는 구름 위에 올라타 봐요'],[1030,504,'별 문 앞에서 E / ↓ · 보너스 게임'],
        [1960,469,'아래 길로도 끝까지 갈 수 있어요'],[2990,504,'구름을 따라 마지막 다리로 →']],
      areas:[{x:0,name:'구름다리 초입'},{x:970,name:'별빛 보너스 정류장'},
        {x:1930,name:'흔들리는 하늘길'},{x:2940,name:'구름 너머 우편함'}]
    },
    '1-4-bonus': {
      id:'1-4-bonus',name:'별빛 도토리 배달',subtitle:'25초 안에 도토리 12개! 기념 우표에 도전해요',
      theme:'bonus',width:1460,finish:null,spawn:{x:160,y:469},checkpoint:null,
      hint:'25초 안에 도토리 12개를 모아요. 양쪽 별 문으로 언제든 돌아갈 수 있어요.',
      bonus:{duration:25,target:12},
      platforms:blocks([[0,515,1460,180],[340,450,180,65],[600,390,200,24],
        [900,450,200,65],[1180,450,150,65]]),
      coins:acorns('1-4-bonus',[[220,472,3,42],[365,407,3,42],[555,342,4,44],
        [665,347,3,42],[923,407,4,42],[1205,407,2,42]]),
      enemies:[],items:[],breakables:[],
      portals:[{id:'bonus-exit-left',x:65,y:431,w:64,h:84,label:'구름다리로 돌아가기',target:'1-4'},
        {id:'bonus-exit-right',x:1350,y:431,w:64,h:84,label:'구름다리로 돌아가기',target:'1-4'}],
      stamps:[{id:'cloud-bonus-postage',x:1035,y:340}],trees:[],
      signs:[[185,504,'25초 · 도토리 12개를 모아요!'],[605,504,'위쪽 도토리도 놓치지 마세요'],
        [1140,504,'별 문에서 E / ↓ · 돌아가기']],
      areas:[{x:0,name:'별빛 도토리 배달'}]
    },
    '1-5': {
      id:'1-5',name:'반딧불 숲',subtitle:'별 도토리의 빛으로 어둠 속 길을 밝혀요',
      theme:'night',width:4500,finish:4230,spawn:{x:100,y:469},
      hint:'별 도토리를 먹으면 6초 동안 무적! 반짝임이 끝나기 전에 달려보세요.',
      checkpoint:{x:2130,y:469,triggerX:2060,maxX:2320,flagX:2100},
      platforms:blocks([
        [0,515,1450,180],[1600,515,820,180],[2560,480,860,215],[3570,515,930,180],
        [260,450,170,65],[530,385,170,24],[810,325,190,24],
        [1780,450,180,65],[2760,415,170,65],[3020,350,180,24],[3790,450,180,65]
      ]),
      coins:acorns('1-5',[
        [190,472,2,42],[285,407,3,42],[555,342,3,42],[840,282,3,42],
        [630,472,5,48],[1130,472,4,44],[1420,411,5,43],[1690,472,2,42],
        [1810,407,3,42],[2110,472,4,42],[2400,397,5,42],[2790,372,3,42],
        [3050,307,3,42],[3380,390,5,42],[3650,472,3,42],[3820,407,3,42],
        [4100,472,3,42]
      ]),
      enemies:[snail(655,491,620,720,38),snail(840,491,800,910,40),
        snail(1080,491,1040,1150,38),snail(1270,491,1210,1330,41),
        snail(2210,491,2130,2330,43),snail(3260,456,3190,3320,44),
        snail(4140,491,4050,4200,42),snail(970,491,950,995,33),
        snail(1850,426,1800,1880,32),snail(3090,326,3040,3140,35),snail(3030,456,2995,3065,42)],
      items:[{id:'firefly-star',type:'invincible',x:500,y:475},
        {id:'night-armor',type:'armor',x:2000,y:475},
        {id:'late-firefly-star',type:'invincible',x:3190,y:440},
        {id:'firefly-fire',type:'fire',x:570,y:475},{id:'firefly-spare-fire',type:'fire',x:2660,y:440}],
      breakables:[],portals:[],stamps:[{id:'firefly-postage',x:905,y:258}],
      trees:[{x:145,y:515,s:.95},{x:460,y:515,s:1.25},{x:1120,y:515,s:1.1},
        {x:1660,y:515,s:.95},{x:2320,y:515,s:1.15},{x:2680,y:480,s:1.1},
        {x:3680,y:515,s:1.25},{x:4350,y:515,s:.95}],
      signs:[[160,504,'별 도토리를 먹으면 6초 동안 무적!'],[1010,504,'반짝이는 동안에는 달팽이도 무섭지 않아요'],
        [2050,504,'빛이 꺼지면 다시 점프해요'],[3590,504,'반딧불이 편지를 안내해요 →']],
      areas:[{x:0,name:'별빛이 깨어나는 숲'},{x:1000,name:'반딧불 행진'},
        {x:1600,name:'달빛 쉼터'},{x:2560,name:'밤하늘 가지길'},{x:3570,name:'잠들지 않는 우편함'}]
    },
    '1-6': {
      id:'1-6',name:'바람 협곡',subtitle:'상승 기류를 타고, 협곡 위로 편지를 날려요',
      theme:'canyon',width:4300,finish:4030,spawn:{x:100,y:469},
      hint:'바람 기둥으로 점프하면 위로 올라가요. Space를 누르며 날아보세요.',
      checkpoint:{x:2200,y:469,triggerX:2140,maxX:2390,flagX:2170},
      platforms:blocks([
        [0,515,930,180],[1100,515,810,180],[2090,515,850,180],[3120,515,1180,180],
        [350,450,170,65],[670,320,210,24],[985,265,210,24],[1400,365,180,24],
        [2390,360,190,24],[2680,300,190,24],[3410,450,190,65],[3680,385,180,24]
      ]),
      winds:[{x:510,y:150,w:190,h:305,force:-2400,drift:400},
        {x:2200,y:150,w:200,h:305,force:-2400,drift:380},
        {x:3210,y:245,w:150,h:210,force:-2250,drift:350}],
      coins:acorns('1-6',[
        [225,472,3,42],[375,407,3,42],[555,345,3,36],[700,277,3,44],
        [1020,222,3,44],[905,409,5,43],[1240,472,4,44],[1440,322,3,42],
        [1880,409,5,44],[2160,472,3,42],[2420,317,3,44],[2710,257,3,44],
        [2910,409,5,44],[3200,472,3,42],[3440,407,3,42],[3710,342,3,42],
        [3910,472,3,42]
      ]),
      enemies:[snail(1520,491,1430,1600,40),snail(2810,491,2730,2870,42),
        snail(3930,491,3850,3990,44),snail(1460,341,1420,1510,35),snail(750,491,720,780,40)],
      items:[{id:'canyon-armor',type:'armor',x:280,y:475},
        {id:'canyon-fire',type:'fire',x:170,y:475},{id:'canyon-spare-fire',type:'fire',x:2560,y:475}],breakables:[],portals:[],
      stamps:[{id:'canyon-postage',x:1110,y:204}],
      trees:[{x:145,y:515,s:.82},{x:1210,y:515,s:.7},{x:1840,y:515,s:.92},
        {x:2140,y:515,s:.7},{x:3190,y:515,s:.85},{x:4160,y:515,s:1.02}],
      signs:[[200,504,'바람 기둥으로 점프해 봐요'],[740,504,'Space 꾹 · 바람 위에서 활공'],
        [1180,504,'높은 바위 위에 협곡 우표!'],[2110,504,'아래 길도 안전한 배달길이에요'],
        [3170,504,'마지막 바람을 타고 →']],
      areas:[{x:0,name:'바람이 시작되는 절벽'},{x:1100,name:'협곡의 메아리'},
        {x:2090,name:'솟아오르는 기류'},{x:3120,name:'바람 너머 배달길'}]
    },
    '1-7': {
      id:'1-7',name:'폭풍 우체국',subtitle:'배운 힘을 모두 모아, 구름탑으로 향해요',
      theme:'storm',width:4550,finish:4270,spawn:{x:100,y:469},
      hint:'갑옷, 구름 발판, 별 도토리, 바람! 마지막 편지 앞에 모두 모였어요.',
      checkpoint:{x:2340,y:469,triggerX:2270,maxX:2480,flagX:2310},
      platforms:blocks([
        [0,515,1040,180],[1200,485,870,210],[2230,515,930,180],[3330,515,1220,180],
        [420,450,180,65],[710,385,160,24],[1450,420,180,65],[1720,355,180,24],
        [2520,400,150,24],[2790,335,180,24],[3560,450,180,65],[3860,385,170,24]
      ]),
      movingPlatforms:[{id:'storm-bridge',x:1010,y:410,w:135,h:24,axis:'x',range:140,speed:62},
        {id:'storm-lift',x:1960,y:330,w:145,h:24,axis:'y',range:90,speed:39}],
      winds:[{x:2330,y:155,w:190,h:300,force:-2350,drift:420}],
      coins:acorns('1-7',[
        [195,472,3,42],[450,407,3,42],[735,342,3,42],[960,379,5,43],
        [1280,442,3,42],[1480,377,3,42],[1750,312,3,42],[2040,371,5,43],
        [2280,472,3,42],[2545,357,3,42],[2820,292,3,42],[3130,409,5,43],
        [3420,472,3,42],[3590,407,3,42],[3890,342,3,42],[4140,472,3,42]
      ]),
      enemies:[snail(1320,461,1270,1380,42),snail(1840,461,1780,1920,42),
        snail(2730,491,2680,2800,44),snail(2980,491,2910,3060,46),
        snail(4100,491,4030,4200,45),snail(765,361,725,810,33),
        snail(3910,361,3880,3965,35),snail(770,491,740,800,42)],
      items:[{id:'storm-armor',type:'armor',x:315,y:475},
        {id:'storm-star',type:'invincible',x:2460,y:475},
        {id:'tower-spare-armor',type:'armor',x:3430,y:475},
        {id:'storm-fire',type:'fire',x:360,y:475},{id:'storm-spare-fire',type:'fire',x:2540,y:475}],
      breakables:[{id:'storm-crate',x:905,y:421,w:56,h:94}],portals:[],
      stamps:[{id:'storm-postage',x:2880,y:267}],
      trees:[{x:145,y:515,s:.9},{x:665,y:515,s:1.1},{x:1220,y:485,s:.8},
        {x:2240,y:515,s:1.05},{x:3020,y:515,s:.9},{x:3370,y:515,s:1.1},{x:4410,y:515,s:.95}],
      signs:[[185,504,'지금까지 배운 힘을 모아봐요'],[805,504,'갑옷으로 상자를 뚫고 달려요 →'],
        [2260,504,'다음은 구름탑 · 마지막 중간 우체통'],[3350,504,'폭풍 너머에 마지막 편지가 있어요']],
      areas:[{x:0,name:'폭풍 우체국 입구'},{x:1200,name:'비구름 분류실'},
        {x:2230,name:'마지막 바람 회랑'},{x:3330,name:'구름탑으로 가는 길'}]
    },
    '1-8': {
      id:'1-8',name:'구름탑',subtitle:'폭풍 부엉이를 진정시키고, 마지막 편지를 전해요',
      theme:'tower',width:2800,finish:2550,spawn:{x:100,y:469},
      hint:'돌진을 마치고 쉴 때, 금빛 머리를 밟으세요. 네 번 맞히면 길이 열려요.',
      checkpoint:{x:1470,y:469,triggerX:1420,maxX:1550,flagX:1440},
      platforms:blocks([[0,515,980,180],[1130,515,1670,180],[430,450,170,65],
        [730,385,170,24]]),
      coins:acorns('1-8',[[225,472,3,42],[460,407,3,42],[760,342,3,42],
        [950,409,5,43],[1240,472,3,42],[2440,472,3,42]]),
      enemies:[snail(735,491,660,830,35)],
      items:[{id:'tower-entry-armor',type:'armor',x:320,y:475},
        {id:'boss-renewable-armor',type:'armor',x:1450,y:475,renewable:true},
        {id:'owl-renewable-fire',type:'fire',x:1380,y:475,renewable:true}],
      breakables:[],portals:[],stamps:[],
      boss:{x:1950,y:439,w:92,h:76,min:1630,max:2320,hp:4,triggerX:1550},
      trees:[{x:150,y:515,s:.86},{x:1230,y:515,s:.72},{x:2720,y:515,s:.85}],
      signs:[[195,504,'마지막 편지가 구름탑에 도착했어요'],[1150,504,'갑옷을 입고 부엉이를 만나러 가요'],
        [1490,504,'부엉이가 쉬면 머리 위로 점프!'],[2500,504,'숲의 모두에게 편지가 도착해요']],
      areas:[{x:0,name:'구름탑 계단'},{x:1130,name:'탑 꼭대기 우체통'},
        {x:1550,name:'폭풍 부엉이의 둥지'},{x:2460,name:'세상 끝 우편함'}]
    },
    '1-2-secret': {
      id:'1-2-secret',name:'나무 속 비밀방',subtitle:'잊힌 편지와 작은 기념 우표',
      theme:'secret',width:1120,finish:null,spawn:{x:150,y:469},checkpoint:null,
      platforms:blocks([[0,515,1120,180],[300,450,150,65],[540,385,180,24],[810,450,140,65]]),
      coins:acorns('1-2-secret',[[215,470,2],[323,405,3,42],[475,344,3,40],[575,340,3,40],[834,405,3,42],[980,470,2,40]]),
      enemies:[],items:[],breakables:[],
      portals:[{id:'hollow-exit',x:70,y:431,w:64,h:84,label:'숲으로 돌아가기',target:'1-2'}],
      stamps:[{id:'hollow-postage',x:635,y:303}],
      trees:[],signs:[[170,504,'E / ↓ · 숲으로 돌아가기'],[480,504,'위쪽에 반짝이는 기념 우표!']],
      areas:[{x:0,name:'나무 속 비밀방'}]
    }
  };
  for(const level of Object.values(levels)) {
    level.movingPlatforms=level.movingPlatforms||[];
    level.winds=level.winds||[];
    for(const enemy of level.enemies) {
      if(level.id==='1-1'&&enemy===level.enemies[0])continue;
      const ledge=level.platforms.find(block=>block.y===enemy.y+enemy.h&&
        enemy.min>=block.x&&enemy.max+enemy.w<=block.x+block.w);
      const smallLedge=ledge&&ledge.h<=80&&ledge.w<=240;
      enemy.speed=Math.round(enemy.speed*(smallLedge?1.15:1.25));
    }
    level.totalCoins=level.coins.length;
  }
  levels['1-2'].totalCoins+=levels['1-2-secret'].coins.length;
  levels['1-4'].totalCoins+=levels['1-4-bonus'].coins.length;
  const stages=[
    {id:'1-1',name:'바람이 머무는 숲',description:'첫 번째 편지와 잎사귀 활공',tags:['점프','활공'],available:true,theme:'forest'},
    {id:'1-2',name:'껍질나무 길',description:'도토리 갑옷으로 여는 나무 속 비밀',tags:['갑옷 변신','비밀방'],available:true,theme:'amber'},
    {id:'1-3',name:'오래된 나무 속',description:'나이테 위의 오래된 기념 우표',tags:['갈림길','숨은 우표'],available:true,theme:'cave'},
    {id:'1-4',name:'흔들리는 구름다리',description:'움직이는 구름과 25초 보너스 배달',tags:['움직이는 발판','보너스'],available:true,theme:'clouds'},
    {id:'1-5',name:'반딧불 숲',description:'별 도토리가 밝히는 밤의 배달길',tags:['6초 무적','밤의 숲'],available:true,theme:'night'},
    {id:'1-6',name:'바람 협곡',description:'상승 기류를 타고 찾는 협곡 우표',tags:['상승 기류','활공'],available:true,theme:'canyon'},
    {id:'1-7',name:'폭풍 우체국',description:'배운 힘을 모아 구름탑으로',tags:['종합 도전','폭풍'],available:true,theme:'storm'},
    {id:'1-8',name:'구름탑',description:'폭풍 부엉이와 마지막 편지',tags:['보스','월드 1 완주'],available:true,theme:'tower',boss:true}
  ];
  const expansion=typeof module!=='undefined'&&module.exports?require('./levels-world2.js'):root.ForestWorld2;
  Object.assign(levels,expansion.levels);stages.push(...expansion.stages);
  const mountain=typeof module!=='undefined'&&module.exports?require('./levels-world3.js'):root.ForestWorld3;
  Object.assign(levels,mountain.levels);stages.push(...mountain.stages);
  const winter=typeof module!=='undefined'&&module.exports?require('./levels-world4.js'):root.ForestWorld4;
  Object.assign(levels,winter.levels);stages.push(...winter.stages);
  const longCourse=typeof module!=='undefined'&&module.exports?require('./long-course.js'):root.ForestLongCourse;
  const longBoss=typeof module!=='undefined'&&module.exports?require('./long-boss.js'):root.ForestLongBoss;
  longCourse.apply(levels,stages);
  longBoss.apply(levels,stages);
  const worlds=[
    {id:'1',name:'구름숲',title:'구름숲 배달 지도',english:'THE CLOUD FOREST',subtitle:'바람에 실린 여덟 통의 편지',
      description:'1-4에는 보너스 우체국, 1-8에는 폭풍 부엉이가 기다려요.',ending:'여덟 통의 편지, 모두 도착! 구름숲에 다시 햇살이 돌아왔어요.'},
    {id:'2',name:'물안개 호수',title:'물안개 호수 배달 지도',english:'THE MISTY LAKE',subtitle:'물길을 따라 전하는 여덟 통의 편지',
      description:'탄력 버섯을 타고 높이! 2-4의 수정 보너스방과 2-8의 이끼 왕거북을 만나보세요.',ending:'호수의 여덟 통도 모두 도착! 오래된 물길에 다시 생기가 돌아왔어요.'},
    {id:'3',name:'노을 태엽산',title:'노을 태엽산 배달 지도',english:'THE CLOCKWORK HIGHLANDS',subtitle:'노을을 넘어 새벽으로, 여덟 통의 편지',
      description:'움직이는 벨트를 따라 시계탑으로! 3-4의 별빛 보너스와 3-8의 태엽 여우가 기다려요.',ending:'태엽산의 여덟 통도 모두 도착! 멈췄던 시계가 돌아가고 새벽이 밝아왔어요.'},
    {id:'4',name:'오로라 설원',title:'오로라 설원 배달 지도',english:'THE AURORA SNOWFIELDS',subtitle:'북극성을 따라, 눈 위에 남긴 여덟 통의 편지',
      description:'빙판을 건너 북극성 궁전으로! 4-4의 눈꽃 보너스와 4-8의 서리 왕곰을 만나보세요.',ending:'설원의 여덟 통도 모두 도착! 따뜻한 편지 위로 오로라가 펼쳐져요.'}
  ];
  const api={levels,stages,worlds,get:id=>levels[id]||null};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.ForestLevels=api;
})(typeof window!=='undefined'?window:null);
