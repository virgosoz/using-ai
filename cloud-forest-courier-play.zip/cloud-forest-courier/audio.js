(function (root) {
  'use strict';

  // Small, self-contained Web Audio cues. Nothing is created until sound is
  // explicitly enabled by the player; the game has no downloaded audio assets.
  class Sound {
    constructor() {
      this.enabled = false;
      this.context = null;
      this.master = null;
      this.limiter = null;
      this.noiseBuffer = null;
      this.activeNodes = new Set();
      this.lastCoinTime = -Infinity;
    }

    setEnabled(value) {
      if (!value) {
        this.enabled = false;
        this.stop();
        return false;
      }
      this.enabled = true;
      return this._prepare();
    }

    resume() {
      return this.enabled && this._prepare();
    }

    _prepare() {
      if (!this.enabled) return false;
      try {
        if (!this.context) {
          const AudioContext = root.AudioContext || root.webkitAudioContext;
          if (!AudioContext) return this._fail();
          this.context = new AudioContext();
          this.master = this.context.createGain();
          this.master.gain.value = 0.65;
          this.limiter = this.context.createDynamicsCompressor();
          this.limiter.threshold.value = -14;
          this.limiter.knee.value = 12;
          this.limiter.ratio.value = 8;
          this.limiter.attack.value = 0.003;
          this.limiter.release.value = 0.12;
          this.master.connect(this.limiter);
          this.limiter.connect(this.context.destination);
          this.noiseBuffer = this.context.createBuffer(1, Math.ceil(this.context.sampleRate * 0.5), this.context.sampleRate);
          const channel = this.noiseBuffer.getChannelData(0);
          for (let i = 0; i < channel.length; i++) channel[i] = Math.random() * 2 - 1;
        }
        if (this.context.state === 'closed') return this._fail();
        if (this.context.state === 'suspended' || this.context.state === 'interrupted') {
          // Callers invoke enable/resume from a click or key gesture. Rejections
          // stay local, including browsers which decline an audio resume.
          const pending = this.context.resume();
          if (pending && pending.catch) pending.catch(() => this._fail());
        }
        this.master.gain.setValueAtTime(0.65, this.context.currentTime);
        return true;
      } catch (_) {
        return this._fail();
      }
    }

    _fail() {
      this.enabled = false;
      this.stop();
      return false;
    }

    stop() {
      if (this.context && this.master) {
        try {
          this.master.gain.cancelScheduledValues(this.context.currentTime);
          this.master.gain.setValueAtTime(0, this.context.currentTime);
        } catch (_) {}
      }
      for (const voice of this.activeNodes) {
        try { voice.source.stop(); } catch (_) {}
        this._release(voice);
      }
      this.lastCoinTime = -Infinity;
    }

    _release(voice) {
      voice.source.onended = null;
      for (const node of voice.nodes) {
        try { node.disconnect(); } catch (_) {}
      }
      this.activeNodes.delete(voice);
    }

    _voice(source, nodes, start, duration) {
      const voice = { source, nodes: [source, ...nodes] };
      this.activeNodes.add(voice);
      source.onended = () => this._release(voice);
      source.start(start);
      source.stop(start + duration + 0.015);
    }

    _envelope(start, duration, volume, attack = 0.006) {
      const gain = this.context.createGain();
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(volume, start + Math.min(attack, duration * 0.3));
      gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
      gain.connect(this.master);
      return gain;
    }

    _note(time, frequency, duration = 0.16, volume = 0.075, type = 'sine', endFrequency = frequency) {
      const oscillator = this.context.createOscillator();
      const gain = this._envelope(time, duration, volume);
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(frequency, time);
      if (frequency !== endFrequency) oscillator.frequency.exponentialRampToValueAtTime(endFrequency, time + duration);
      oscillator.connect(gain);
      this._voice(oscillator, [gain], time, duration);
    }

    _noise(time, duration, volume, frequency, type = 'bandpass', endFrequency = frequency) {
      const source = this.context.createBufferSource();
      const filter = this.context.createBiquadFilter();
      const gain = this._envelope(time, duration, volume, 0.002);
      source.buffer = this.noiseBuffer;
      filter.type = type;
      filter.Q.value = 0.7;
      filter.frequency.setValueAtTime(frequency, time);
      if (frequency !== endFrequency) filter.frequency.exponentialRampToValueAtTime(endFrequency, time + duration);
      source.connect(filter);
      filter.connect(gain);
      this._voice(source, [filter, gain], time, duration);
    }

    _chord(time, frequencies, duration, volume = 0.035, type = 'triangle') {
      for (const frequency of frequencies) this._note(time, frequency, duration, volume, type);
    }

    play(type) {
      if (!this.enabled || !this._prepare()) return false;
      try {
        const t = this.context.currentTime + 0.006;
        if (type === 'coin') {
          if (t - this.lastCoinTime < 0.05) return false;
          this.lastCoinTime = t;
        }
        switch (type) {
          case 'bossFrost':
            this._noise(t,.2,.085,1500,'lowpass',320);
            this._note(t,145,.23,.075,'sine',65);
            this._note(t+.07,620,.18,.025,'triangle',280);
            break;
          case 'bossHail':
            [880,740,620].forEach((f,i)=>this._note(t+i*.045,f,.22,.04,'triangle',f*.55));
            this._noise(t,.16,.04,2800,'bandpass',1200);
            break;
          case 'bossVolley':
            this._noise(t,.12,.065,1800,'bandpass',750);
            this._note(t,220,.17,.065,'triangle',165);
            this._note(t+.07,330,.13,.04,'triangle',220);
            break;
          case 'weaponPickup':
            [392,523.25,659.25,1046.5].forEach((f,i)=>this._note(t+i*.06,f,.2,.05,'triangle'));
            break;
          case 'shoot':
            this._note(t,410,.1,.035,'triangle',120);
            this._noise(t,.065,.035,2100,'bandpass',700);
            break;
          case 'shotHit':
            this._note(t,170,.09,.055,'sine',70);
            this._noise(t,.075,.055,1200,'lowpass');
            break;
          case 'weaponLost':
            this._note(t,460,.2,.035,'triangle',140);
            break;
          case 'doubleJump':
            this._note(t,480,.13,.05,'sine',960);
            this._note(t+.035,720,.12,.02,'triangle',1280);
            break;
          case 'spring':
            this._note(t,160,.24,.1,'sine',850);
            this._note(t+.05,380,.18,.04,'triangle',1046.5);
            break;
          case 'start':
            this._note(t, 523.25, 0.13, 0.065, 'triangle');
            this._chord(t + 0.09, [659.25, 783.99], 0.25, 0.04);
            break;
          case 'jump':
            this._note(t, 270, 0.11, 0.05, 'sine', 590);
            this._note(t + 0.015, 540, 0.065, 0.013, 'triangle', 820);
            break;
          case 'coin':
            this._note(t, 1046.5, 0.09, 0.052);
            this._note(t + 0.037, 1567.98, 0.15, 0.044);
            break;
          case 'land':
            this._note(t, 115, 0.085, 0.075, 'sine', 60);
            this._noise(t, 0.052, 0.07, 620, 'lowpass');
            break;
          case 'transform': {
            this._note(t, 82.41, 0.26, 0.13, 'sine', 164.81);
            this._noise(t, 0.17, 0.05, 1800, 'highpass', 4800);
            const steps = [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98];
            steps.forEach((frequency, i) => this._note(t + 0.035 + i * 0.05, frequency, 0.2, 0.057, 'triangle'));
            this._chord(t + 0.34, [1046.5, 1318.51, 1567.98], 0.46, 0.036, 'sine');
            break;
          }
          case 'armorLost':
            this._note(t, 620, 0.28, 0.075, 'triangle', 145);
            this._note(t, 140, 0.12, 0.12, 'sine', 54);
            this._noise(t, 0.14, 0.18, 2400, 'bandpass', 550);
            this._noise(t + 0.065, 0.1, 0.085, 3300);
            this._noise(t + 0.135, 0.08, 0.05, 1650);
            break;
          case 'break':
            this._note(t, 135, 0.16, 0.15, 'sine', 43);
            this._noise(t, 0.15, 0.26, 1250, 'lowpass', 270);
            this._note(t + 0.008, 820, 0.046, 0.04, 'square', 230);
            this._noise(t + 0.057, 0.085, 0.1, 1950);
            break;
          case 'stomp':
            this._note(t, 170, 0.14, 0.15, 'sine', 60);
            this._note(t + 0.025, 230, 0.15, 0.055, 'triangle', 470);
            this._noise(t, 0.045, 0.09, 850, 'lowpass');
            break;
          case 'death':
            this._note(t, 330, 0.16, 0.08, 'triangle', 260);
            this._note(t + 0.14, 220, 0.16, 0.065, 'triangle', 165);
            this._note(t + 0.28, 147, 0.27, 0.065, 'sine', 74);
            this._noise(t, 0.11, 0.065, 800, 'lowpass');
            break;
          case 'checkpoint':
            [523.25, 659.25, 783.99].forEach((frequency, i) => this._note(t + i * 0.095, frequency, 0.25, 0.065));
            this._chord(t + 0.28, [523.25, 783.99, 1046.5], 0.35, 0.025);
            break;
          case 'secretEnter':
            this._note(t, 170, 0.32, 0.07, 'sine', 680);
            this._noise(t, 0.22, 0.055, 600, 'bandpass', 3200);
            [659.25, 783.99, 987.77, 1318.51].forEach((frequency, i) => this._note(t + 0.06 + i * 0.075, frequency, 0.26, 0.042));
            break;
          case 'secretExit':
            this._note(t, 680, 0.28, 0.055, 'sine', 220);
            [987.77, 783.99, 659.25].forEach((frequency, i) => this._note(t + i * 0.075, frequency, 0.2, 0.045));
            break;
          case 'stamp':
            this._note(t, 210, 0.085, 0.065, 'sine', 100);
            [783.99, 1046.5, 1318.51, 1567.98].forEach((frequency, i) => this._note(t + i * 0.075, frequency, 0.22, 0.058, 'triangle'));
            this._chord(t + 0.33, [1046.5, 1318.51, 1567.98], 0.35, 0.028);
            break;
          case 'win': {
            // A compact cadence, ending in a warm major chord (about 1.4 s).
            const phrase = [[0, 523.25, 0.17], [0.15, 659.25, 0.17], [0.3, 783.99, 0.24], [0.55, 1046.5, 0.22], [0.79, 987.77, 0.13], [0.94, 1046.5, 0.44]];
            phrase.forEach(([offset, frequency, duration]) => this._note(t + offset, frequency, duration, 0.08, 'triangle'));
            this._note(t, 130.81, 0.24, 0.09, 'sine');
            this._note(t + 0.55, 196, 0.26, 0.07, 'sine');
            this._chord(t + 0.94, [261.63, 329.63, 392, 523.25], 0.46, 0.046);
            this._noise(t + 0.94, 0.18, 0.04, 5200, 'highpass');
            break;
          }
          default:
            return false;
        }
        return true;
      } catch (_) {
        return this._fail();
      }
    }
  }

  const api = { Sound };
  root.ForestAudio = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
