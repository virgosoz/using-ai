/* World 1 scenery and actors. Canvas art; no network assets. */
(function () {
  'use strict';
  const base=window.ForestArt,TAU=Math.PI*2;
  const oval=(c,x,y,rx,ry,color)=>{c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.fillStyle=color;c.fill();};
  const box=(c,x,y,w,h,r,color)=>{c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=color;c.fill();};
  function star(c,x,y,r,color){c.beginPath();for(let i=0;i<10;i++){const a=i*Math.PI/5-Math.PI/2,s=i%2?r*.46:r;c[i?'lineTo':'moveTo'](x+Math.cos(a)*s,y+Math.sin(a)*s);}c.closePath();c.fillStyle=color;c.fill();}
  const palettes={clouds:['#a9d9df','#f8f2d9','#d0dfc9'],night:['#283c58','#728e91','#314f62'],canyon:['#9ac6cf','#edd5ae','#bda088'],storm:['#455569','#a4b8b8','#596879'],tower:['#414d68','#b5b7c5','#7b859b']};
  function drawBackground(c,o){
    const {width:w,height:h,cameraX:cam=0,time:t=0,theme}=o;
    if(theme==='cave'){
      base.drawBackground(c,{...o,theme:'secret'});c.save();
      for(let i=-1;i<w/260+2;i++){
        const x=i*260-(cam*.19%260);
        c.strokeStyle='#463c3448';c.lineWidth=40;c.beginPath();c.moveTo(x,-30);c.bezierCurveTo(x+90,85,x-45,165,x+14,220);c.stroke();
        for(let j=0;j<3;j++){const y=470+j*21;oval(c,x+48*j,y,18,8,['#87b5a0','#bfa885','#a5c4a9'][j]);box(c,x+48*j-3,y,6,24,2,'#cdd8b9');}
      }
      c.restore();return;
    }
    const pal=palettes[theme];if(!pal){base.drawBackground(c,o);return;}
    c.save();const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,pal[0]);g.addColorStop(1,pal[1]);c.fillStyle=g;c.fillRect(0,0,w,h);
    const night=theme==='night',storm=theme==='storm'||theme==='tower';
    const sunX=w*.77-cam*.025%90;
    const glow=c.createRadialGradient(sunX,115,8,sunX,115,140);glow.addColorStop(0,night?'#fff4bc40':'#fff8dd48');glow.addColorStop(1,'#fff4bc00');c.fillStyle=glow;c.fillRect(sunX-140,-25,280,280);
    oval(c,sunX,115,night?30:42,night?30:42,night?'#fff0ba':storm?'#d0d7cf':'#fff5d3');
    if(night){oval(c,sunX+12,107,25,25,pal[0]);for(let i=0;i<55;i++){const x=((i*113-cam*.04)%(w+30)+w+30)%(w+30);c.globalAlpha=.3+(Math.sin(t*.8+i)+1)*.2;star(c,x,28+(i*71)%290,i%3?1.5:3,'#f9edc0');}c.globalAlpha=1;}
    for(let layer=0;layer<3;layer++){
      const span=layer?340:510,off=(cam*(.08+layer*.065))%span;
      c.fillStyle=pal[2];c.globalAlpha=.18+layer*.13;
      c.beginPath();c.moveTo(-span,h);
      for(let i=-1;i<w/span+2;i++){
        const x=i*span-off,y=h*(.63+layer*.1)+Math.sin(i*2.7)*35;
        if(theme==='canyon'){c.lineTo(x,y+100);c.lineTo(x+38,y);c.lineTo(x+154,y-12);c.lineTo(x+210,y+90);}
        else{c.lineTo(x,y+70);c.bezierCurveTo(x+60,y-100,x+230,y-90,x+span,y+70);}
      }c.lineTo(w+span,h);c.closePath();c.fill();
    }c.globalAlpha=1;
    if(theme==='night')for(let i=-1;i<w/225+2;i++){c.save();c.globalAlpha=.38;base.drawTree(c,i*225-cam*.22%225,h*.93,.95);c.restore();}
    if(theme==='tower'){
      for(let i=-1;i<w/280+2;i++){
        const x=i*280-cam*.23%280;c.fillStyle='#343e5b30';c.fillRect(x,210,95,h);
        box(c,x+19,251,56,90,28,'#d2cbb04d');c.fillStyle='#56637b';c.fillRect(x+45,251,4,92);
        for(let j=0;j<3;j++)box(c,x-8+j*38,192,29,30,3,'#65708888');
      }
      c.strokeStyle='#d9c69070';c.lineWidth=2;c.beginPath();c.moveTo(0,190);c.lineTo(w,190);c.stroke();
    }
    if(!night)for(let i=-1;i<w/360+2;i++){
      const x=i*360-(cam*.12+t*(storm?14:4))%360,y=75+(i%3)*58;c.globalAlpha=storm?.23:.65;
      const color=storm?'#d2dce0':'#fffcf0';oval(c,x,y,95,21,color);oval(c,x-27,y-19,43,30,color);oval(c,x+31,y-13,40,26,color);
    }
    c.globalAlpha=1;
    if(storm){c.strokeStyle='#e4ebed36';c.lineWidth=1;for(let i=0;i<38;i++){const x=((i*103-t*48-cam*.16)%(w+50)+w+50)%(w+50),y=((i*71+t*135)%h);c.beginPath();c.moveTo(x,y);c.lineTo(x-9,y+20);c.stroke();}}
    if(night)for(let i=0;i<26;i++){
      const x=((i*137+t*5-cam*.3)%(w+50)+w+50)%(w+50),y=230+(i*57)%320+Math.sin(t+i)*13;
      c.globalAlpha=.5+Math.sin(t*1.2+i)*.22;oval(c,x,y,3,3,'#ffeb96');c.globalAlpha=.1;oval(c,x,y,12,12,'#ffeea3');
    }
    c.restore();
  }
  function drawWind(c,{x,y,w,h,time:t=0,drift=0}){
    c.save();const g=c.createLinearGradient(x,y,x+w,y);g.addColorStop(0,'#d3f1db00');g.addColorStop(.5,'#d3f1db40');g.addColorStop(1,'#d3f1db00');c.fillStyle=g;c.fillRect(x,y,w,h);
    c.strokeStyle='#ecf8df90';c.lineWidth=2;c.lineCap='round';
    for(let i=0;i<9;i++){const px=x+18+(i*61)%Math.max(30,w-30),py=y+((i*59-t*70)%h+h)%h;c.beginPath();c.moveTo(px+(drift>0?-12:12),py+26);c.quadraticCurveTo(px-8,py+12,px,py);c.lineTo(px-5,py+7);c.moveTo(px,py);c.lineTo(px+5,py+7);c.stroke();}c.restore();
  }
  function drawMovingPlatform(c,{x,y,w,h=20,time:t=0}){
    c.save();c.strokeStyle='#a8beae66';c.lineWidth=1.5;c.setLineDash([4,6]);c.beginPath();c.moveTo(x+w/2,y-32);c.lineTo(x+w/2,y+35);c.stroke();c.setLineDash([]);
    oval(c,x+w/2,y+h*.6,w*.5,h*.8,'#e6ecdf');box(c,x,y,w,h,8,'#9aab9e');box(c,x+2,y-3,w-4,9,5,'#f2f1d7');
    c.fillStyle='#657f74';for(let i=15;i<w-5;i+=25)c.fillRect(x+i,y+6,1,Math.max(2,h-8));star(c,x+w/2,y+8,4,'#fff0a9');c.restore();
  }
  function drawPowerItem(c,{x,y,time:t=0}){
    c.save();c.translate(x,y+Math.sin(t*2.4)*4);const g=c.createRadialGradient(0,0,3,0,0,39);g.addColorStop(0,'#fff0a080');g.addColorStop(1,'#fff0a000');c.fillStyle=g;c.fillRect(-39,-39,78,78);
    star(c,0,0,17,'#ae8254');star(c,0,-1,14,'#ffe69c');oval(c,-4,-2,1.6,2.2,'#6c6b4a');oval(c,4,-2,1.6,2.2,'#6c6b4a');
    for(let i=0;i<3;i++){const a=t+i*TAU/3;star(c,Math.cos(a)*26,Math.sin(a)*23,3,['#caead4','#ffd7b8','#d8deff'][i]);}c.restore();
  }
  function drawPlayer(c,p){
    if(p.powerTime>0){c.save();c.globalAlpha*=.28;const x=p.x+p.w/2,y=p.y+p.h/2;
      ['#f7c783','#a9ddbd','#b9d6e4'].forEach((color,i)=>{c.strokeStyle=color;c.lineWidth=3;c.beginPath();c.ellipse(x,y,27+i*5,32+i*5,0,0,TAU);c.stroke();});c.restore();}
    base.drawPlayer(c,p);
  }
  function drawProjectile(c,{x,y,w=22,h=12,time:t=0}){
    c.save();c.translate(x+w/2,y+h/2);c.rotate(-.35+Math.sin(t*9)*.08);oval(c,0,0,w*.65,h*.45,'#e7d7b0');c.strokeStyle='#856f85';c.lineWidth=2;c.beginPath();c.moveTo(-w*.6,0);c.lineTo(w*.6,0);c.stroke();c.restore();
  }
  function drawBoss(c,b){
    const {x,y,w=92,h=76,phase='idle',time:t=0}=b,sleep=b.defeated||phase==='defeated',weak=phase==='recovery';
    c.save();c.translate(x+w/2,y+h);c.scale(w/92,h/76);
    oval(c,0,-1,48,7,'#27334530');
    if(phase==='windup'){
      c.save();c.strokeStyle='#f6c888';c.lineWidth=2;c.setLineDash([7,7]);c.beginPath();c.ellipse(0,-35,63,51,0,0,TAU);c.stroke();c.setLineDash([]);c.fillStyle='#ffebaf';c.font='bold 21px sans-serif';c.textAlign='center';c.fillText('!',0,-101);c.restore();
    }
    const wing=phase==='dash'?-.55:phase==='windup'?-.9:Math.sin(t*3)*.05;
    for(const side of [-1,1]){c.save();c.translate(side*34,-42);c.rotate(side*wing);oval(c,side*13,5,23,36,sleep?'#8c97a4':'#647087');c.strokeStyle='#bec4c8';c.lineWidth=2;for(let i=0;i<3;i++){c.beginPath();c.moveTo(side*(7+i*6),0);c.lineTo(side*(9+i*5),28-i*3);c.stroke();}c.restore();}
    oval(c,0,-37,43,39,b.flash>0?'#f8e6c5':sleep?'#9aa3a7':'#7e859e');oval(c,0,-25,27,25,'#c9c4b5');
    c.fillStyle='#657087';c.beginPath();c.moveTo(-37,-57);c.lineTo(-38,-87);c.lineTo(-15,-70);c.lineTo(16,-70);c.lineTo(38,-87);c.lineTo(37,-56);c.fill();
    oval(c,-17,-51,20,21,'#ece4c9');oval(c,17,-51,20,21,'#ece4c9');
    for(const side of [-1,1]){
      if(sleep||weak){c.strokeStyle='#536079';c.lineWidth=3;c.beginPath();c.arc(side*17,-48,7,Math.PI,0);c.stroke();}
      else {oval(c,side*17,-51,8,11,'#e0ac65');oval(c,side*17+(b.dir||-1)*2,-51,4,7,'#39495c');oval(c,side*17-1,-54,2,2,'#fff6d3');}
    }
    c.fillStyle='#c88c59';c.beginPath();c.moveTo(-6,-42);c.lineTo(6,-42);c.lineTo(0,-32);c.fill();
    for(let i=0;i<3;i++){c.strokeStyle='#9b9382';c.lineWidth=2;c.beginPath();c.moveTo(-10+i*10,-22);c.lineTo(-6+i*10,-17);c.lineTo(-2+i*10,-22);c.stroke();}
    for(const side of [-1,1])box(c,side*15-8,-4,17,7,3,'#caa369');
    if(weak&&!sleep){c.strokeStyle='#ffe7a5';c.lineWidth=3;c.beginPath();c.ellipse(0,-87,25,8,0,0,TAU);c.stroke();star(c,-30,-88,5,'#ffe7a5');star(c,32,-90,5,'#ffe7a5');}
    if(sleep){c.fillStyle='#e9eddd';c.font='bold 15px sans-serif';c.fillText('z Z',25,-88);}
    c.restore();
  }
  window.ForestArt=Object.freeze({...base,drawBackground,drawPlayer,drawWind,drawMovingPlatform,drawPowerItem,drawProjectile,drawBoss});
}());
