/* Hand-drawn canvas scenery for Cloud Forest Courier. No external assets. */
(function () {
  'use strict';

  const C = {
    ink: '#374c43', sage: '#92b196', moss: '#6d9178', dark: '#587960',
    light: '#c4d2aa', cream: '#fff4d9', peach: '#dfa276', rust: '#b77551',
    brown: '#845c45', gold: '#dfb567', sky: '#f3f1e7'
  };

  function ellipse(ctx, x, y, rx, ry, fill, rotation) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rotation || 0, 0, Math.PI * 2);
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function path(ctx, fill, points) {
    ctx.beginPath();
    points(ctx);
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function outlinedEllipse(ctx, x, y, rx, ry, fill, rotation = 0, stroke = '#674e3d', lineWidth = 1.6) {
    ellipse(ctx, x, y, rx, ry, fill, rotation);
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }

  function outlinedPath(ctx, fill, points, stroke = '#674e3d', lineWidth = 1.6) {
    path(ctx, fill, points);
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lineWidth;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  function sparkle(ctx, x, y, size, color) {
    path(ctx, color, p => {
      p.moveTo(x, y - size);
      p.quadraticCurveTo(x + size * 0.18, y - size * 0.18, x + size, y);
      p.quadraticCurveTo(x + size * 0.18, y + size * 0.18, x, y + size);
      p.quadraticCurveTo(x - size * 0.18, y + size * 0.18, x - size, y);
      p.quadraticCurveTo(x - size * 0.18, y - size * 0.18, x, y - size);
    });
  }

  function cloud(ctx, x, y, scale, opacity) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);
    ctx.globalAlpha = opacity;
    ctx.fillStyle = '#fffdf4';
    ctx.beginPath();
    ctx.moveTo(-76, 15);
    ctx.bezierCurveTo(-102, 10, -91, -17, -65, -13);
    ctx.bezierCurveTo(-66, -46, -21, -54, -7, -27);
    ctx.bezierCurveTo(13, -48, 48, -36, 49, -14);
    ctx.bezierCurveTo(91, -17, 98, 15, 67, 17);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function tinyLeaf(ctx, x, y, scale, rotation, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.scale(scale, scale);
    path(ctx, color, p => {
      p.moveTo(-7, 0);
      p.quadraticCurveTo(-1, -9, 10, -2);
      p.quadraticCurveTo(5, 8, -7, 0);
    });
    ctx.restore();
  }

  function drawTree(ctx, x, y, scale = 1) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    path(ctx, '#9c9b76', p => {
      p.moveTo(-12, 2);
      p.bezierCurveTo(-6, -38, -13, -94, -7, -152);
      p.lineTo(6, -152);
      p.bezierCurveTo(8, -90, 4, -39, 15, 2);
      p.closePath();
    });
    ctx.strokeStyle = '#9c9b76';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-2, -77);
    ctx.lineTo(-37, -115);
    ctx.moveTo(3, -101);
    ctx.lineTo(40, -140);
    ctx.stroke();

    ellipse(ctx, -37, -144, 44, 45, '#a7bf99', -0.12);
    ellipse(ctx, 31, -165, 48, 50, '#9eb98f', 0.25);
    ellipse(ctx, -12, -186, 49, 43, '#b0c69c', -0.18);
    ellipse(ctx, 53, -131, 39, 38, '#91ae88', 0.12);
    ellipse(ctx, -11, -135, 54, 41, '#a8c194', 0.05);
    ellipse(ctx, -22, -192, 30, 17, '#bed0a8', -0.18);
    ellipse(ctx, 17, -159, 19, 10, '#b9cda2', -0.4);

    for (let i = 0; i < 9; i += 1) {
      const lx = Math.sin(i * 2.39) * 56;
      const ly = -170 + Math.cos(i * 1.91) * 34;
      tinyLeaf(ctx, lx, ly, 0.56, i * 0.9, i % 2 ? '#8da980' : '#c4d6ad');
    }
    ctx.strokeStyle = '#bbb392';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-1, -15);
    ctx.quadraticCurveTo(-4, -45, -3, -64);
    ctx.stroke();
    ellipse(ctx, 1, 1, 27, 5, '#b2bf93');
    ctx.restore();
  }

  function hillLayer(ctx, width, height, cameraX, speed, baseline, amplitude, fill, step) {
    const offset = ((cameraX * speed) % step + step) % step;
    ctx.beginPath();
    ctx.moveTo(-step, height + 20);
    ctx.lineTo(-step, baseline);
    for (let x = -step; x < width + step * 2; x += step) {
      const left = x - offset;
      ctx.bezierCurveTo(left + step * 0.28, baseline - amplitude,
        left + step * 0.72, baseline - amplitude, left + step, baseline);
    }
    ctx.lineTo(width + step * 2, height + 20);
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function drawBackground(ctx, { width, height, cameraX = 0, time = 0, theme = 'forest' }) {
    ctx.save();
    if (theme === 'secret') {
      drawSecretBackground(ctx, { width, height, cameraX, time });
      ctx.restore();
      return;
    }
    const amber = theme === 'amber';
    const bg = ctx.createLinearGradient(0, 0, 0, height);
    bg.addColorStop(0, amber ? '#ecd1a4' : '#e7ede6');
    bg.addColorStop(0.55, amber ? '#faebc9' : '#f2f0e3');
    bg.addColorStop(1, amber ? '#e5d0a2' : '#e8e7d3');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // A pale morning sun, deliberately quiet behind the level's silhouettes.
    const sunX = width * 0.78 - cameraX * 0.025;
    const sunY = height * 0.23;
    const glow = ctx.createRadialGradient(sunX, sunY, 15, sunX, sunY, 150);
    glow.addColorStop(0, 'rgba(255,241,205,0.8)');
    glow.addColorStop(1, 'rgba(255,241,205,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(sunX - 150, sunY - 150, 300, 300);
    ellipse(ctx, sunX, sunY, 35, 35, amber ? '#fff5d1' : '#fbefd2');

    const cloudSpan = 1850;
    for (let i = -1; i < 6; i += 1) {
      const baseX = i * 360 + 140;
      const x = ((baseX - cameraX * 0.085 + time * 2.8) % cloudSpan + cloudSpan) % cloudSpan - 240;
      const y = height * 0.18 + Math.sin(i * 2.4) * 44;
      cloud(ctx, x, y, 0.65 + (i % 3 + 3) % 3 * 0.17, 0.75);
    }

    hillLayer(ctx, width, height, cameraX, 0.085, height * 0.76, height * 0.29, amber ? '#e3ceaa' : '#d8e0cf', 590);
    hillLayer(ctx, width, height, cameraX + 1300, 0.15, height * 0.92, height * 0.35, amber ? '#d9c394' : '#c9d7c3', 480);

    // Distant trees travel slower than the land the player stands on.
    const treeStep = 276;
    const treeOffset = ((cameraX * 0.22) % treeStep + treeStep) % treeStep;
    for (let i = -1; i < Math.ceil(width / treeStep) + 2; i += 1) {
      const tx = i * treeStep - treeOffset;
      const ty = height * 0.91 + Math.sin(i * 2) * 18;
      ctx.save();
      ctx.globalAlpha = 0.34;
      drawTree(ctx, tx, ty, 0.78 + (i % 2) * 0.13);
      if (amber) {
        // Ochre crowns give the second route its own autumn silhouette.
        ellipse(ctx, tx, ty - 143, 52, 49, '#d7aa58', -0.2);
        ellipse(ctx, tx + 35, ty - 111, 44, 41, '#cda154', 0.3);
        ellipse(ctx, tx - 21, ty - 155, 30, 22, '#ecc681', -0.3);
      }
      ctx.restore();
    }
    hillLayer(ctx, width, height, cameraX + 1400, 0.3, height * 1.055, height * 0.18, amber ? '#c3b584' : '#b7ccb5', 450);

    // Detached floating gardens establish the high-altitude forest setting.
    for (let i = 0; i < 4; i += 1) {
      const span = width + 540;
      const fx = ((i * 440 + 210 - cameraX * 0.12) % span + span) % span - 180;
      const fy = height * 0.50 + Math.sin(i * 2.8) * 46;
      const s = 0.5 + (i % 2) * 0.13;
      ctx.save();
      ctx.globalAlpha = 0.43;
      ctx.translate(fx, fy);
      ctx.scale(s, s);
      path(ctx, '#b8b99b', p => {
        p.moveTo(-68, 0); p.lineTo(66, 0); p.quadraticCurveTo(34, 32, 6, 58);
        p.quadraticCurveTo(-27, 25, -68, 0);
      });
      ellipse(ctx, 0, -2, 70, 10, '#a3bd98');
      drawTree(ctx, -3, -7, 0.53);
      ctx.strokeStyle = '#9cb28e';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(41, 6); ctx.quadraticCurveTo(57, 32, 42, 53);
      ctx.stroke();
      tinyLeaf(ctx, 46, 31, 0.9, -0.2, '#9cb28e');
      ctx.restore();
    }

    // A small, deterministic scatter of drifting leaves.
    for (let i = 0; i < 10; i += 1) {
      const span = width + 120;
      const x = ((i * 179 + time * (7 + i % 3) - cameraX * 0.18) % span + span) % span - 60;
      const y = height * (0.18 + (i % 5) * 0.14) + Math.sin(time * 0.6 + i) * 13;
      ctx.globalAlpha = 0.28;
      tinyLeaf(ctx, x, y, 0.5, Math.sin(time * 0.4 + i) * 0.8, amber ? '#b98442' : '#8aa381');
    }
    ctx.restore();
  }

  function drawSecretBackground(ctx, { width, height, cameraX, time }) {
    // A softly lit hollow trunk, with grain instead of distant hills.
    const bg = ctx.createLinearGradient(0, 0, 0, height);
    bg.addColorStop(0, '#5b443b');
    bg.addColorStop(0.6, '#99734f');
    bg.addColorStop(1, '#c3a16b');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);
    const grainOffset = ((cameraX * 0.16) % 150 + 150) % 150;
    ctx.lineCap = 'round';
    for (let i = -1; i < Math.ceil(width / 150) + 2; i += 1) {
      const x = i * 150 - grainOffset;
      ctx.strokeStyle = 'rgba(48,31,26,0.15)';
      ctx.lineWidth = 25;
      ctx.beginPath();
      ctx.moveTo(x, -30);
      ctx.bezierCurveTo(x + 90, height * 0.34, x - 60, height * 0.61, x + 45, height + 30);
      ctx.stroke();
      ctx.strokeStyle = 'rgba(253,218,151,0.12)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + 23, -30);
      ctx.bezierCurveTo(x + 113, height * 0.34, x - 37, height * 0.61, x + 68, height + 30);
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(x + 65, height * (0.38 + (i % 3) * 0.13), 17, 40, -0.15, 0, Math.PI * 2);
      ctx.stroke();
    }
    for (let i = 0; i < 3; i += 1) {
      const span = width + 400;
      const lx = ((i * 480 + 170 - cameraX * 0.12) % span + span) % span - 100;
      const ly = height * (0.22 + (i % 2) * 0.14);
      const glow = ctx.createRadialGradient(lx, ly, 2, lx, ly, 145);
      glow.addColorStop(0, 'rgba(255,218,116,0.26)');
      glow.addColorStop(1, 'rgba(255,218,116,0)');
      ctx.fillStyle = glow;
      ctx.fillRect(lx - 145, ly - 145, 290, 290);
      ctx.strokeStyle = 'rgba(58,38,26,0.42)';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(lx, 0); ctx.lineTo(lx, ly - 13); ctx.stroke();
      outlinedEllipse(ctx, lx, ly, 10, 14, '#ddbc70', 0, '#715339', 2);
      ellipse(ctx, lx, ly - 2, 5, 9, '#fbe4a5');
    }
    for (let i = 0; i < 22; i += 1) {
      const span = width + 60;
      const x = ((i * 137 + Math.sin(i * 2.1) * 50 + time * (2 + i % 3) - cameraX * 0.1) % span + span) % span - 30;
      const y = 65 + ((i * 83) % Math.max(80, height - 145)) + Math.sin(time * 0.8 + i) * 9;
      ctx.globalAlpha = 0.14 + (Math.sin(time * 1.4 + i * 3.1) + 1) * 0.16;
      sparkle(ctx, x, y, 2 + i % 3, '#ffeab1');
    }
    ctx.globalAlpha = 1;
    const shade = ctx.createLinearGradient(0, 0, 0, height);
    shade.addColorStop(0, 'rgba(42,30,28,0.25)');
    shade.addColorStop(0.42, 'rgba(42,30,28,0)');
    shade.addColorStop(1, 'rgba(42,30,28,0.08)');
    ctx.fillStyle = shade;
    ctx.fillRect(0, 0, width, height);
  }

  function drawPlayer(ctx, { x, y, w = 34, h = 46, facing = 1, grounded = false,
    gliding = false, vx = 0, time = 0, invulnerable = false, armored = false,
    landingTime = 0, hurtTime = 0 }) {
    ctx.save();
    ctx.globalAlpha *= invulnerable ? 0.7 + Math.sin(time * 9) * 0.15 : 1;
    ctx.translate(x + w / 2, y + h);
    const squash = grounded ? Math.min(Math.max(landingTime, 0) / 0.16, 1) : 0;
    ctx.scale((facing < 0 ? -1 : 1) * w / 34 * (1 + squash * 0.13), h / 46 * (1 - squash * 0.12));
    if (hurtTime > 0) ctx.rotate(-Math.sin(Math.min(hurtTime, 0.3) / 0.3 * Math.PI) * 0.12);
    const run = grounded ? Math.sin(time * 17) * Math.min(Math.abs(vx) / 180, 1) : 0;
    const bob = grounded ? Math.abs(run) * 1.7 : Math.sin(time * 4) * 0.6;
    ctx.translate(0, -bob);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // The curled tail and ink outline keep the silhouette legible over scenery.
    ctx.save();
    ctx.translate(-9, -19);
    ctx.rotate(Math.sin(time * 3.5) * 0.055 + (gliding ? -0.25 : 0) + run * 0.035);
    outlinedPath(ctx, C.rust, p => {
      p.moveTo(0, 12);
      p.bezierCurveTo(-21, 13, -31, -2, -28, -20);
      p.bezierCurveTo(-26, -34, -5, -37, 0, -24);
      p.bezierCurveTo(4, -13, -10, -7, -13, -16);
      p.bezierCurveTo(-17, -6, -4, -2, 3, 2); p.closePath();
    });
    path(ctx, '#edbc89', p => {
      p.moveTo(-11, 6);
      p.bezierCurveTo(-27, -1, -26, -22, -16, -26);
      p.bezierCurveTo(-9, -30, -3, -24, -6, -19);
      p.bezierCurveTo(-8, -28, -18, -23, -19, -15);
      p.bezierCurveTo(-20, -7, -16, 1, -11, 6);
    });
    ctx.restore();

    // Feet cycle in opposite directions and tuck up during a jump.
    const tuck = grounded ? 0 : gliding ? -1 : -3;
    outlinedEllipse(ctx, -7 + run * 4, -3 + Math.min(run, 0) * 2 + tuck, 6, 3.5, '#705343', run * 0.18, '#513f34', 1.3);
    outlinedEllipse(ctx, 7 - run * 4, -3 - Math.max(run, 0) * 2 + tuck, 6, 3.5, '#896449', -run * 0.18, '#513f34', 1.3);
    outlinedEllipse(ctx, 0, -15, 11, 14, '#e5a777', -run * 0.025);
    ellipse(ctx, 4, -15, 6.5, 10.5, C.cream, -0.12);

    ctx.strokeStyle = '#46624c'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(5, -29); ctx.lineTo(-9, -9); ctx.stroke();
    outlinedPath(ctx, '#68865d', p => {
      p.moveTo(-16, -17); p.lineTo(-5, -16); p.lineTo(-5, -5);
      p.quadraticCurveTo(-11, -2, -17, -6); p.closePath();
    }, '#42553a', 1.4);
    path(ctx, '#a9ba85', p => {
      p.moveTo(-17, -17); p.lineTo(-5, -16); p.lineTo(-6, -11);
      p.quadraticCurveTo(-11, -8, -16, -12); p.closePath();
    });
    ellipse(ctx, -11, -11, 1.3, 1.3, '#fbe1a3');

    if (armored) {
      // A rounded acorn shell breastplate: visibly different even at game scale.
      outlinedPath(ctx, '#a06b3b', p => {
        p.moveTo(-8, -25); p.quadraticCurveTo(1, -28, 9, -22);
        p.lineTo(10, -11); p.quadraticCurveTo(2, -5, -6, -10); p.closePath();
      }, '#634523', 1.8);
      path(ctx, '#dcaa59', p => {
        p.moveTo(-5, -23); p.quadraticCurveTo(2, -24, 7, -20);
        p.lineTo(7, -12); p.quadraticCurveTo(1, -9, -3, -12); p.closePath();
      });
      ctx.strokeStyle = '#a47337'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(1, -23); ctx.lineTo(2, -11); ctx.stroke();
      ellipse(ctx, -5, -20, 1, 1, '#ffe1a4');
      ellipse(ctx, 7, -17, 1, 1, '#ffe1a4');
    }

    outlinedEllipse(ctx, -7, -39, 5.1, 7.2, C.rust, -0.22, '#674e3d', 1.4);
    outlinedEllipse(ctx, 6, -40, 4.5, 6.5, C.peach, 0.13, '#674e3d', 1.3);
    ellipse(ctx, -7, -39, 2.2, 3.7, '#efc3a0', -0.22);
    ellipse(ctx, 6, -40, 2, 3.2, '#f5ccac', 0.13);
    outlinedEllipse(ctx, 1, -32, 13, 11.3, '#e8ac79', -0.08);
    ellipse(ctx, 9, -28, 7.7, 5.4, '#fff0d4', -0.18);
    ellipse(ctx, 15, -30, 2.1, 1.7, '#4b4034', 0.1);
    if (hurtTime > 0) {
      ctx.strokeStyle = '#443e31'; ctx.lineWidth = 1.7;
      ctx.beginPath(); ctx.moveTo(5, -37); ctx.lineTo(8.5, -35); ctx.lineTo(5, -33); ctx.stroke();
    } else {
      ellipse(ctx, 7, -35, 1.9, 2.8, '#354139', 0.07);
      ellipse(ctx, 7.4, -35.9, 0.65, 0.85, '#fffdf4');
    }
    ellipse(ctx, 3, -29, 2.5, 1.4, '#d88c6e', 0.1);
    ctx.strokeStyle = '#976847'; ctx.lineWidth = 0.9;
    ctx.beginPath(); ctx.moveTo(9, -25); ctx.quadraticCurveTo(11, -24, 13, -26); ctx.stroke();

    if (armored) {
      outlinedPath(ctx, '#936132', p => {
        p.moveTo(-12, -38); p.quadraticCurveTo(-13, -48, 0, -49);
        p.quadraticCurveTo(12, -48, 13, -38);
        p.quadraticCurveTo(1, -34, -12, -38); p.closePath();
      }, '#543e28', 1.7);
      path(ctx, '#be8c4b', p => {
        p.moveTo(-10, -41); p.quadraticCurveTo(-7, -48, 1, -47);
        p.quadraticCurveTo(8, -46, 10, -41); p.quadraticCurveTo(0, -39, -10, -41);
      });
      ctx.strokeStyle = '#805429'; ctx.lineWidth = 1;
      for (let i = -7; i <= 7; i += 5) {
        ctx.beginPath(); ctx.moveTo(i - 2, -44); ctx.lineTo(i + 2, -39); ctx.stroke();
      }
      ctx.strokeStyle = '#70502e'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, -49); ctx.quadraticCurveTo(0, -53, 4, -53); ctx.stroke();
      ellipse(ctx, 4, -53, 2, 1.1, '#cba269', -0.3);
      ctx.strokeStyle = '#e8bd71'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(-10, -37); ctx.quadraticCurveTo(2, -34, 12, -38); ctx.stroke();
    }

    outlinedPath(ctx, '#bf694e', p => {
      p.moveTo(-8, -25); p.quadraticCurveTo(0, -20, 9, -24);
      p.lineTo(8, -20); p.quadraticCurveTo(0, -17, -7, -21); p.closePath();
    }, '#8c4f3c', 0.9);
    path(ctx, '#cc7e58', p => {
      p.moveTo(-6, -22); p.lineTo(-14 - Math.abs(run) * 2, -19 + run);
      p.lineTo(-13, -26); p.closePath();
    });

    if (gliding) {
      ctx.strokeStyle = '#754f35'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(7, -21); ctx.lineTo(15, -32); ctx.stroke();
      ctx.strokeStyle = '#e5aa76'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(7, -21); ctx.lineTo(15, -32); ctx.stroke();
      ctx.strokeStyle = '#566f42'; ctx.lineWidth = 2.3;
      ctx.beginPath(); ctx.moveTo(15, -30); ctx.quadraticCurveTo(17, -47, 5, -59); ctx.stroke();
      outlinedEllipse(ctx, 15, -33, 3.1, 3.2, C.peach, 0, '#674e3d', 1);
      ctx.save(); ctx.translate(4, -60); ctx.rotate(Math.sin(time * 4) * 0.055);
      outlinedPath(ctx, '#789d62', p => {
        p.moveTo(-34, 0); p.bezierCurveTo(-21, -24, 13, -23, 36, -1);
        p.quadraticCurveTo(18, -3, 8, 4); p.quadraticCurveTo(-12, -5, -34, 0);
      }, '#46633c', 1.7);
      path(ctx, '#accb84', p => {
        p.moveTo(-31, -1); p.bezierCurveTo(-19, -21, 8, -21, 32, -3);
        p.quadraticCurveTo(5, -14, -31, -1);
      });
      ctx.strokeStyle = '#648c50'; ctx.lineWidth = 1.15;
      ctx.beginPath();
      ctx.moveTo(-31, -1); ctx.quadraticCurveTo(2, -13, 34, -2);
      ctx.moveTo(-14, -5); ctx.lineTo(-12, -14);
      ctx.moveTo(-1, -7); ctx.lineTo(2, -17);
      ctx.moveTo(13, -6); ctx.lineTo(17, -12); ctx.stroke();
      ctx.restore();
    } else {
      outlinedEllipse(ctx, 9, -16 + run * 2, 4, 6, C.peach, -0.2 + run * 0.23, '#825b3f', 1.1);
    }
    ctx.restore();
  }

  function drawEnemy(ctx, { x, y, w = 36, h = 24, time = 0 }) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(w / 36, h / 24);
    const wiggle = Math.sin(time * 4) * 0.7;
    ellipse(ctx, 18, 23, 18, 2, 'rgba(57,77,53,0.09)');
    outlinedPath(ctx, '#98ae77', p => {
      p.moveTo(1, 21); p.quadraticCurveTo(5, 17, 20, 18);
      p.quadraticCurveTo(25, 17, 27, 12); p.quadraticCurveTo(33, 10, 35, 17);
      p.quadraticCurveTo(35, 24, 25, 24); p.lineTo(8, 24); p.quadraticCurveTo(3, 24, 1, 21);
    }, '#526749', 1.6);
    outlinedEllipse(ctx, 15, 13 + wiggle, 12, 11, '#bc895e', -0.1, '#78563c', 1.7);
    ellipse(ctx, 13, 10 + wiggle, 8.7, 7.3, '#e0b98b', -0.25);
    ellipse(ctx, 10, 7 + wiggle, 3.6, 1.6, '#f0d3a8', -0.45);
    ctx.strokeStyle = '#95663f';
    ctx.lineWidth = 1.9;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(18, 17 + wiggle);
    ctx.bezierCurveTo(5, 19 + wiggle, 5, 6 + wiggle, 14, 6 + wiggle);
    ctx.bezierCurveTo(23, 6 + wiggle, 21, 15 + wiggle, 15, 14 + wiggle);
    ctx.bezierCurveTo(11, 14 + wiggle, 11, 10 + wiggle, 15, 10 + wiggle);
    ctx.stroke();
    ctx.strokeStyle = '#526749';
    ctx.lineWidth = 1.7;
    ctx.beginPath();
    ctx.moveTo(29, 14); ctx.lineTo(28, 8 + wiggle);
    ctx.moveTo(33, 15); ctx.lineTo(35, 8 - wiggle);
    ctx.stroke();
    ellipse(ctx, 28, 7.5 + wiggle, 1.6, 1.9, C.ink);
    ellipse(ctx, 35, 7.5 - wiggle, 1.6, 1.9, C.ink);
    ellipse(ctx, 32, 18, 1.7, 1.0, '#d6ad86');
    ctx.restore();
  }

  // Item coordinates are center points; geometry coordinates are top-left.
  function drawArmorItem(ctx, { x, y, time = 0 }) {
    ctx.save();
    ctx.translate(x, y + Math.sin(time * 3) * 2.5);
    const glow = ctx.createRadialGradient(0, 0, 5, 0, 0, 30);
    glow.addColorStop(0, 'rgba(255,225,131,0.38)');
    glow.addColorStop(1, 'rgba(255,225,131,0)');
    ctx.fillStyle = glow; ctx.fillRect(-30, -30, 60, 60);
    outlinedPath(ctx, '#cf9b4c', p => {
      p.moveTo(-12, -4); p.lineTo(12, -4);
      p.bezierCurveTo(13, 5, 7, 13, 0, 17);
      p.bezierCurveTo(-7, 13, -13, 5, -12, -4); p.closePath();
    }, '#654924', 2);
    path(ctx, '#efc574', p => {
      p.moveTo(-8, -2); p.lineTo(-1, -3); p.lineTo(-1, 12);
      p.quadraticCurveTo(-7, 8, -8, -2);
    });
    ctx.strokeStyle = '#ac7637'; ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(4, -2); ctx.quadraticCurveTo(7, 6, 0, 14); ctx.stroke();
    outlinedPath(ctx, '#997046', p => {
      p.moveTo(-15, -4); p.quadraticCurveTo(-13, -14, 0, -15);
      p.quadraticCurveTo(13, -14, 15, -4); p.quadraticCurveTo(0, 2, -15, -4); p.closePath();
    }, '#624525', 2);
    ctx.strokeStyle = '#c89a60'; ctx.lineWidth = 1.4;
    for (let i = -9; i <= 9; i += 6) {
      ctx.beginPath(); ctx.moveTo(i - 1, -10); ctx.lineTo(i + 3, -5); ctx.stroke();
    }
    ctx.strokeStyle = '#765332'; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(0, -14); ctx.quadraticCurveTo(0, -19, 5, -20); ctx.stroke();
    tinyLeaf(ctx, 9, -19, 0.65, -0.4, '#779052');
    sparkle(ctx, -22, -9, 3.5 + Math.sin(time * 3) * 0.8, '#fff2b4');
    sparkle(ctx, 21, 7, 2 + Math.cos(time * 3) * 0.6, '#fff2b4');
    ctx.restore();
  }

  function drawBreakable(ctx, { x, y, w = 48, h = 64, time = 0 }) {
    ctx.save(); ctx.translate(x, y);
    // The zigzag split and brass corners distinguish this from safe terrain.
    ctx.shadowColor = 'rgba(59,39,24,0.18)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 3;
    const wood = ctx.createLinearGradient(0, 0, w, h);
    wood.addColorStop(0, '#d4a66a'); wood.addColorStop(1, '#a97641');
    ctx.fillStyle = wood; ctx.fillRect(0, 0, w, h);
    ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
    ctx.strokeStyle = '#71502f'; ctx.lineWidth = 3; ctx.strokeRect(1.5, 1.5, w - 3, h - 3);
    ctx.strokeStyle = '#e4bf88'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(4, h - 5); ctx.lineTo(4, 4); ctx.lineTo(w - 5, 4); ctx.stroke();
    ctx.strokeStyle = 'rgba(104,66,31,0.24)'; ctx.lineWidth = 1.2;
    for (let i = 1; i < Math.ceil(w / 15); i += 1) {
      const gx = i * 15;
      ctx.beginPath(); ctx.moveTo(gx, 5); ctx.bezierCurveTo(gx - 5, h * 0.3, gx + 5, h * 0.6, gx - 2, h - 5); ctx.stroke();
    }
    ctx.strokeStyle = '#644a30'; ctx.lineWidth = 3.3; ctx.lineJoin = 'miter';
    ctx.beginPath();
    ctx.moveTo(w * 0.55, 1); ctx.lineTo(w * 0.43, h * 0.25);
    ctx.lineTo(w * 0.59, h * 0.35); ctx.lineTo(w * 0.33, h * 0.61);
    ctx.lineTo(w * 0.5, h * 0.69); ctx.lineTo(w * 0.41, h - 1);
    ctx.moveTo(w * 0.56, h * 0.37); ctx.lineTo(w * 0.8, h * 0.29);
    ctx.moveTo(w * 0.34, h * 0.61); ctx.lineTo(w * 0.18, h * 0.55);
    ctx.stroke();
    ctx.strokeStyle = '#f2d39d'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(w * 0.48, h * 0.25); ctx.lineTo(w * 0.64, h * 0.35); ctx.lineTo(w * 0.39, h * 0.61); ctx.stroke();
    for (const px of [7, w - 7]) {
      for (const py of [8, h - 8]) outlinedEllipse(ctx, px, py, 2, 2, '#e8c587', 0, '#876237', 0.8);
    }
    ctx.restore();
  }

  function drawPortal(ctx, { x, y, w = 68, h = 86, time = 0, label = '', active = true }) {
    ctx.save(); ctx.translate(x, y);
    const cx = w / 2;
    // An arched hollow framed by a thick bark rim.
    outlinedPath(ctx, '#966f4c', p => {
      p.moveTo(0, h); p.lineTo(0, h * 0.43);
      p.bezierCurveTo(0, -h * 0.12, w, -h * 0.12, w, h * 0.43);
      p.lineTo(w, h); p.closePath();
    }, '#60472f', 2.6);
    const inner = ctx.createLinearGradient(0, 10, 0, h);
    inner.addColorStop(0, active ? '#332d29' : '#62553d');
    inner.addColorStop(1, active ? '#846846' : '#8a7753');
    outlinedPath(ctx, inner, p => {
      p.moveTo(9, h - 3); p.lineTo(9, h * 0.43);
      p.bezierCurveTo(9, 7, w - 9, 7, w - 9, h * 0.43);
      p.lineTo(w - 9, h - 3); p.closePath();
    }, '#725236', 2);
    ctx.strokeStyle = '#c29b65'; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(5, h - 14); ctx.lineTo(5, h * 0.45);
    ctx.bezierCurveTo(5, 2, w - 5, 2, w - 5, h * 0.45); ctx.stroke();
    ctx.strokeStyle = '#715333'; ctx.lineWidth = 1;
    for (let i = 0; i < 4; i += 1) {
      ctx.beginPath(); ctx.moveTo(1, h * 0.52 + i * 12); ctx.lineTo(7, h * 0.49 + i * 12); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(w - 7, h * 0.58 + i * 9); ctx.lineTo(w - 1, h * 0.55 + i * 9); ctx.stroke();
    }
    if (active) {
      const glow = ctx.createRadialGradient(cx, h * 0.7, 1, cx, h * 0.7, w * 0.6);
      glow.addColorStop(0, 'rgba(242,212,138,0.3)'); glow.addColorStop(1, 'rgba(242,212,138,0)');
      ctx.fillStyle = glow; ctx.fillRect(9, h * 0.3, w - 18, h * 0.67);
      for (let i = 0; i < 4; i += 1) {
        ctx.globalAlpha = 0.3 + (1 + Math.sin(time * 2.1 + i * 2)) * 0.2;
        sparkle(ctx, cx + Math.sin(i * 3.4) * w * 0.24, h * (0.35 + i * 0.14) + Math.sin(time + i) * 3, 2.2, '#ffe6a6');
      }
      ctx.globalAlpha = 1;
    }
    outlinedPath(ctx, '#d4bd8a', p => {
      p.moveTo(-3, h - 3); p.lineTo(w + 3, h - 3); p.lineTo(w + 7, h + 4); p.lineTo(-7, h + 4); p.closePath();
    }, '#876d46', 1.5);
    tinyLeaf(ctx, 5, 22, 0.8, -0.6, '#80905c');
    tinyLeaf(ctx, w - 3, 32, 0.7, 1.4, '#91a166');
    if (label) {
      ctx.font = '600 11px system-ui, sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const labelWidth = Math.max(w - 6, ctx.measureText(label).width + 14);
      ctx.fillStyle = '#f3e2ba'; ctx.fillRect(cx - labelWidth / 2, -19, labelWidth, 19);
      ctx.strokeStyle = '#907044'; ctx.lineWidth = 1; ctx.strokeRect(cx - labelWidth / 2, -19, labelWidth, 19);
      ctx.fillStyle = '#674e33'; ctx.fillText(label, cx, -9);
    }
    ctx.restore();
  }

  function drawStamp(ctx, { x, y, time = 0 }) {
    ctx.save(); ctx.translate(x, y + Math.sin(time * 2.8) * 2);
    ctx.rotate(Math.sin(time * 1.5) * 0.06);
    ctx.shadowColor = 'rgba(77,49,26,0.23)'; ctx.shadowOffsetY = 2; ctx.shadowBlur = 3;
    ctx.fillStyle = '#fff3d3'; ctx.fillRect(-13, -16, 26, 32);
    ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
    ctx.strokeStyle = '#80603b'; ctx.lineWidth = 1.4;
    ctx.setLineDash([2, 2]); ctx.strokeRect(-13, -16, 26, 32); ctx.setLineDash([]);
    ctx.fillStyle = '#b9c795'; ctx.fillRect(-9, -12, 18, 23);
    ctx.strokeStyle = '#799064'; ctx.lineWidth = 0.9; ctx.strokeRect(-9, -12, 18, 23);
    ellipse(ctx, 4, -7, 2.4, 2.4, '#f9df8e');
    tinyLeaf(ctx, 0, -1, 0.9, -0.65, '#4f7150');
    ctx.strokeStyle = '#5f7954'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(-4, 7); ctx.lineTo(4, -6); ctx.stroke();
    ctx.fillStyle = '#af8054'; ctx.fillRect(-4, 13, 8, 1);
    sparkle(ctx, 19, -11, 3 + Math.sin(time * 3) * 0.8, '#fff1b1');
    ctx.restore();
  }

  window.ForestArt = Object.freeze({
    drawBackground, drawPlayer, drawEnemy, drawTree,
    drawArmorItem, drawBreakable, drawPortal, drawStamp
  });
}());
