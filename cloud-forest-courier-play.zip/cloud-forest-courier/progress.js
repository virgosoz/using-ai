(function (root) {
  'use strict';
  const KEY='cloud-forest-courier:progress:v1';
  const catalogue=typeof module!=='undefined'&&module.exports?require('./levels.js'):root.ForestLevels;
  const stageIds=catalogue.stages.filter(stage=>stage.available).map(stage=>stage.id);
  const COURSE_REVISION=2;
  const blank=()=>({completed:false,bestCoins:0,bestTime:null,legacyBestTime:null,courseRevision:COURSE_REVISION,secretFound:false,stampCollected:false,bonusCompleted:false});
  function empty(){return {version:1,lastStage:'1-1',stages:Object.fromEntries(stageIds.map(id=>[id,blank()]))};}
  const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
  function normalize(raw){
    const result=empty();
    if(!object(raw)||raw.version!==1)return result;
    if(stageIds.includes(raw.lastStage))result.lastStage=raw.lastStage;
    for(const id of stageIds){
      const source=object(raw.stages)&&raw.stages[id];
      if(!object(source))continue;
      const target=result.stages[id];
      target.completed=source.completed===true;
      target.bestCoins=Number.isFinite(source.bestCoins)?Math.max(0,Math.min(10000,Math.floor(source.bestCoins))):0;
      const validTime=value=>target.completed&&Number.isFinite(value)&&value>0?value:null;
      const time=validTime(source.bestTime);
      target.legacyBestTime=validTime(source.legacyBestTime);
      if(source.courseRevision===COURSE_REVISION)target.bestTime=time;
      else if(time!==null)target.legacyBestTime=target.legacyBestTime===null?time:Math.min(target.legacyBestTime,time);
      target.secretFound=source.secretFound===true;
      target.stampCollected=source.stampCollected===true;
      target.bonusCompleted=source.bonusCompleted===true;
    }
    return result;
  }
  function record(progress,run){
    const next=normalize(progress);
    if(!object(run)||!stageIds.includes(run.stageId))return next;
    const stage=next.stages[run.stageId];next.lastStage=run.stageId;
    stage.bestCoins=Math.max(stage.bestCoins,Number.isFinite(run.collected)?Math.max(0,Math.min(10000,Math.floor(run.collected))):0);
    stage.completed=stage.completed||run.won===true;
    stage.secretFound=stage.secretFound||run.secretFound===true;
    stage.stampCollected=stage.stampCollected||run.stampCollected===true;
    stage.bonusCompleted=stage.bonusCompleted||run.bonusCompleted===true;
    if(run.won===true&&Number.isFinite(run.elapsed)&&run.elapsed>0)stage.bestTime=stage.bestTime===null?run.elapsed:Math.min(stage.bestTime,run.elapsed);
    return next;
  }
  function load(storage){
    let value;
    try {value=storage.getItem(KEY);}catch(_){return {progress:empty(),available:false,reset:false};}
    if(!value)return {progress:empty(),available:true,reset:false};
    try {const raw=JSON.parse(value);return {progress:normalize(raw),available:true,reset:!object(raw)||raw.version!==1};}
    catch(_){return {progress:empty(),available:true,reset:true};}
  }
  function save(storage,progress){try{storage.setItem(KEY,JSON.stringify(normalize(progress)));return true;}catch(_){return false;}}
  const api={KEY,COURSE_REVISION,empty,normalize,record,load,save};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  if(root)root.ForestProgress=api;
})(typeof window!=='undefined'?window:null);
