/* Snow, glassy ice and aurora light, drawn locally with the existing Canvas art. */
(function(){
  'use strict';
  const base=window.ForestArt,TAU=Math.PI*2;
  const palettes={
    frostforest:['#b9d4df','#f2e7d4','#95b6c4'],frozenlake:['#aed3df','#e3eeec','#78aab9'],
    icecave:['#29495f','#719daa','#547c98'],snowpost:['#cfdae0','#f8e8cc','#9aabb5'],
    glacier:['#acc7d9','#e5e7eb','#7fa6bd'],aurora:['#253955','#70979e','#4e718d'],
    blizzard:['#617c98','#c4d7df','#7893aa'],polarpalace:['#293955','#b5c7d5','#718aab']
  };
  const oval=(c,x,y,rx,ry,color)=>{c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.fill();};
  const box=(c,x,y,w,h,r,color)=>{c.fillStyle=color;c.beginPath();c.roundRect(x,y,w,h,r);c.fill();};
  function polygon(c,points,color,stroke){c.fillStyle=color;c.beginPath();points.forEach(([x,y],i)=>c[i?'lineTo':'moveTo'](x,y));c.closePath();c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
  function sparkle(c,x,y,r,color='#fffbed'){
    c.strokeStyle=color;c.lineWidth=1.3;c.beginPath();c.moveTo(x-r,y);c.lineTo(x+r,y);c.moveTo(x,y-r);c.lineTo(x,y+r);c.stroke();
  }
  function crystal(c,x,y,w,h,color){
    polygon(c,[[x-w/2,y],[x-w*.36,y-h*.75],[x,y-h],[x+w*.4,y-h*.75],[x+w/2,y]],color,'#e3f5f480');
    polygon(c,[[x,y],[x,y-h],[x+w*.4,y-h*.75],[x+w/2,y]],'#effaff35');
    c.strokeStyle='#e8ffff8c';c.lineWidth=1.5;c.beginPath();c.moveTo(x,y-h+7);c.lineTo(x,y-8);c.stroke();
  }
  function drawSnowTree(c,x,y,s=1){
    c.save();c.translate(x,y);c.scale(s,s);box(c,-7,-85,14,85,4,'#859797');
    const rows=[[-190,43],[-146,64],[-93,83]];
    for(const [top,half] of rows){
      polygon(c,[[-half,top+82],[0,top],[half,top+82],[half*.33,top+75],[0,top+90],[-half*.37,top+77]],'#6e9695');
      polygon(c,[[-half*.88,top+70],[0,top-3],[half*.89,top+70],[half*.45,top+60],[half*.23,top+69],[0,top+61],[-half*.31,top+72],[-half*.55,top+62]],'#eaf3ef');
      polygon(c,[[0,top+5],[half*.85,top+67],[half*.46,top+58],[half*.25,top+65],[0,top+58]],'#cddfe1');
    }
    oval(c,0,-1,45,6,'#e9f4ee');c.restore();
  }
  function aurora(c,w,t,cam,intensity=1){
    for(let band=0;band<3;band++){
      const off=-cam*.025+band*90,top=75+band*33;
      c.save();c.globalAlpha=.2*intensity;
      const glow=c.createLinearGradient(0,top,0,top+135);glow.addColorStop(0,band===1?'#c2a4e3':'#92ead1');glow.addColorStop(1,'#a4e6d000');c.fillStyle=glow;
      c.beginPath();c.moveTo(-100,top+35);c.bezierCurveTo(w*.23+off,top+95,w*.32+off,top-80,w*.63,top+12+Math.sin(t*.4)*12);c.bezierCurveTo(w*.8,top+90,w*.91,top-26,w+100,top+25);c.lineTo(w+100,top+140);c.bezierCurveTo(w*.74,top+73,w*.67,top+150,w*.48,top+88);c.bezierCurveTo(w*.3,top+38,w*.13,top+157,-100,top+112);c.closePath();c.fill();
      c.strokeStyle=band===1?'#d4baf0':'#b4f5d5';c.lineWidth=2;c.globalAlpha=.29*intensity;
      c.beginPath();c.moveTo(-100,top+35);c.bezierCurveTo(w*.23+off,top+95,w*.32+off,top-80,w*.63,top+12+Math.sin(t*.4)*12);c.bezierCurveTo(w*.8,top+90,w*.91,top-26,w+100,top+25);c.stroke();c.restore();
    }
  }
  function palace(c,x,y,s=1){
    c.save();c.translate(x,y);c.scale(s,s);
    for(const [dx,top,width] of [[-118,-160,54],[118,-160,54],[-68,-112,53],[68,-112,53],[0,-220,76]]){
      box(c,dx-width/2,top,width,-top,4,'#aac4d6');
      polygon(c,[[dx-width*.7,top],[dx,top-62],[dx+width*.7,top]],'#d8e8e6');
      polygon(c,[[dx,top-62],[dx+width*.7,top],[dx,top]],'#a9cbd2');
      box(c,dx-8,top+29,16,37,8,'#e8eacf');
      c.strokeStyle='#e0eff380';c.lineWidth=3;c.beginPath();c.moveTo(dx-width*.29,top+4);c.lineTo(dx-width*.29,-5);c.stroke();
    }
    box(c,-29,-78,58,78,27,'#739bb2');box(c,-20,-64,40,64,19,'#a8c8d0');
    c.strokeStyle='#e9efcf';c.lineWidth=2;c.beginPath();c.moveTo(0,-60);c.lineTo(0,0);c.stroke();
    oval(c,0,-111,20,20,'#91c2c4');sparkle(c,0,-111,12,'#e0ffe3');
    box(c,-154,-4,308,11,5,'#e4efef');c.restore();
  }
  function drawBackground(c,o){
    const {width:w,height:h,cameraX:cam=0,time:t=0,theme}=o,p=palettes[theme];
    if(!p){base.drawBackground(c,o);return;}
    const dark=['icecave','aurora','polarpalace'].includes(theme);
    c.save();const sky=c.createLinearGradient(0,0,0,h);sky.addColorStop(0,p[0]);sky.addColorStop(1,p[1]);c.fillStyle=sky;c.fillRect(0,0,w,h);
    const moonX=w*.77-cam*.02%90;
    if(theme!=='icecave'&&theme!=='blizzard'){
      const light=c.createRadialGradient(moonX,129,15,moonX,129,135);light.addColorStop(0,dark?'#daf9df35':'#fff3d85e');light.addColorStop(1,'#efffff00');c.fillStyle=light;c.fillRect(moonX-135,-6,270,270);
      oval(c,moonX,129,dark?27:31,dark?27:31,dark?'#e4eddb':'#f7ecd4');
    }
    if(theme==='aurora'||theme==='polarpalace')aurora(c,w,t,cam,theme==='aurora'?1.25:.8);
    if(dark)for(let i=0;i<34;i++){const x=((i*137-cam*.035)%(w+70)+w+70)%(w+70);c.globalAlpha=.22+(i%4)*.09;oval(c,x,28+(i*71)%220,i%6===0?1.7:1,1,'#e3f4ed');}c.globalAlpha=1;
    for(let k=0;k<3;k++){
      const span=470-k*75,off=cam*(.055+k*.065)%span,y=310+k*82;
      c.globalAlpha=.22+k*.15;c.fillStyle=p[2];c.beginPath();c.moveTo(-span,h);
      for(let i=-1;i<w/span+2;i++){const x=i*span-off;c.lineTo(x,y+72);c.lineTo(x+span*.4,y-87);c.lineTo(x+span*.61,y-39);c.lineTo(x+span,y+72);}
      c.lineTo(w+span,h);c.closePath();c.fill();
      for(let i=-1;i<w/span+2;i++){const x=i*span-off;polygon(c,[[x+span*.29,y-43],[x+span*.4,y-87],[x+span*.57,y-48],[x+span*.47,y-57],[x+span*.41,y-40],[x+span*.37,y-58]],'#e3eeeb');}
    }c.globalAlpha=1;
    if(['frostforest','snowpost','aurora','blizzard'].includes(theme))for(let i=-1;i<w/270+2;i++){
      c.save();c.globalAlpha=theme==='blizzard'?.25:.38;drawSnowTree(c,i*270-cam*.18%270+85,528,.95+(Math.abs(i)%3)*.12);c.restore();
    }
    if(theme==='frozenlake'){
      const lake=c.createLinearGradient(0,415,0,h);lake.addColorStop(0,'#a5d1d5');lake.addColorStop(1,'#c9e5df');c.fillStyle=lake;c.fillRect(0,415,w,h-415);
      c.strokeStyle='#eaf9f19c';c.lineWidth=2;
      for(let i=-1;i<w/235+2;i++){const x=i*235-cam*.21%235;c.beginPath();c.moveTo(x,472);c.lineTo(x+67,450);c.lineTo(x+98,469);c.lineTo(x+174,449);c.moveTo(x+98,469);c.lineTo(x+74,492);c.stroke();}
      for(let i=0;i<7;i++)sparkle(c,((i*183-cam*.2)%(w+50)+w+50)%(w+50),436+(i*23)%55,4,'#f4ffef');
      c.save();c.globalAlpha=.65;drawSnowTree(c,100-cam*.13%250,439,.65);c.restore();
    }
    if(theme==='icecave')for(let i=-1;i<w/180+2;i++){
      const x=i*180-cam*.16%180,drop=110+(Math.abs(i)%3)*42;
      polygon(c,[[x-65,0],[x+79,0],[x+24,drop],[x-8,drop+48]],'#517c91');
      polygon(c,[[x+10,0],[x+79,0],[x+24,drop],[x-8,drop+48]],'#88b8c485');
      c.save();c.globalAlpha=.55;crystal(c,x+75,545,81,127+(Math.abs(i)%2)*55,'#82b4c2');c.restore();
    }
    if(theme==='snowpost')for(let i=-1;i<w/500+2;i++){
      const x=i*500-cam*.2%500+180;c.save();c.globalAlpha=.55;box(c,x-53,389,106,115,7,'#ad9690');polygon(c,[[x-68,392],[x,338],[x+68,392]],'#b7897c');polygon(c,[[x-69,389],[x,334],[x+69,389],[x+23,374],[x,356],[x-29,379]],'#f2f4e8');
      box(c,x-13,450,26,54,12,'#788f94');for(const side of [-1,1])box(c,x+side*34-10,411,20,26,4,'#f4dba6');box(c,x+85,462,5,43,2,'#9d8d7b');box(c,x+74,449,27,21,6,'#ac807a');box(c,x+72,446,31,6,3,'#e8f4ec');c.restore();
    }
    if(theme==='glacier')for(let i=-1;i<w/330+2;i++){
      const x=i*330-cam*.2%330+60;c.save();c.globalAlpha=.57;crystal(c,x,551,174,232+(Math.abs(i)%3)*50,'#9bc2d1');crystal(c,x+118,568,92,145,'#bdd4e0');c.restore();
    }
    if(theme==='polarpalace'){c.save();c.globalAlpha=.62;palace(c,w*.59-cam*.045%130,520,1.32);c.restore();}
    if(theme==='blizzard'){
      c.strokeStyle='#e1eef074';c.lineWidth=2;
      for(let i=0;i<7;i++){const y=120+i*58;c.beginPath();c.moveTo(-90,y);c.bezierCurveTo(w*.33,y-55,w*.67,y+60,w+80,y-20);c.stroke();}
    }
    const flakes=theme==='blizzard'?78:37;
    for(let i=0;i<flakes;i++){
      const drift=theme==='blizzard'?t*75:t*12,x=((i*113-cam*.12+drift)%(w+100)+w+100)%(w+100)-50;
      const y=((i*79+t*(theme==='blizzard'?35:15))%(h+40)+h+40)%(h+40)-20;
      c.globalAlpha=theme==='blizzard'?.26+(i%3)*.1:.22+(i%4)*.1;
      if(theme==='blizzard'){c.strokeStyle='#eef9f5';c.lineWidth=i%3?1:2;c.beginPath();c.moveTo(x,y);c.lineTo(x+8,y+3);c.stroke();}
      else oval(c,x,y,i%5===0?2.6:1.3,i%5===0?2.1:1.3,'#f7fffa');
    }c.restore();
  }
  function drawSnowPlatform(c,p){
    const {x,y,w,h=24,ice=false,time:t=0}=p;
    c.save();box(c,x,y,w,h,Math.min(7,h/3),ice?'#91becb':'#b6ccd4');
    if(h>25){box(c,x+3,y+12,Math.max(0,w-6),h-14,3,ice?'#add3da':'#c9dce0');
      c.strokeStyle=ice?'#e9faf79c':'#b3c9d0';c.lineWidth=1.5;
      for(let i=35;i<w-12;i+=67){c.beginPath();c.moveTo(x+i,y+16);c.lineTo(x+i-11,y+Math.min(h-4,45));c.lineTo(x+i+6,y+Math.min(h-4,61));c.stroke();}}
    if(ice){
      box(c,x-1,y-3,w+2,13,5,'#8ccbd2');box(c,x+3,y-3,Math.max(0,w-6),4,2,'#e4fff7');
      c.strokeStyle='#dcfffc';c.lineWidth=2;
      for(let i=22;i<w-8;i+=45){c.beginPath();c.moveTo(x+i-9,y+7);c.lineTo(x+i+9,y);c.stroke();}
      for(let i=35;i<w-10;i+=137){c.globalAlpha=.5+.3*Math.sin(t*1.8+i);sparkle(c,x+i,y+3,4,'#fffdeb');}
    }else{
      box(c,x-2,y-4,w+4,12,6,'#f0f7ed');box(c,x+5,y+5,Math.max(0,w-10),4,2,'#daeae8');
      for(let i=25;i<w-10;i+=93)oval(c,x+i,y+6,10,3,'#f0f7ed');
    }
    if(h<35){c.globalAlpha=.7;for(let i=19;i<w-12;i+=42)polygon(c,[[x+i-5,y+h-2],[x+i+5,y+h-2],[x+i+1,y+h+10+(i%3)*3]],'#acd3dc');}
    if(p.moving){
      c.globalAlpha=1;box(c,x+5,y+h-8,Math.max(0,w-10),6,3,'#6f9fad');
      for(const dx of [14,w-14])oval(c,x+dx,y+h-5,2,2,'#e2f7e9');
      const mid=x+w/2;c.strokeStyle='#e5f9e7';c.lineWidth=1.5;c.beginPath();
      if(p.axis==='y'){c.moveTo(mid-5,y+h+14);c.lineTo(mid,y+h+9);c.lineTo(mid+5,y+h+14);}
      else{c.moveTo(mid-6,y+h+10);c.lineTo(mid-10,y+h+14);c.lineTo(mid-6,y+h+18);c.moveTo(mid+6,y+h+10);c.lineTo(mid+10,y+h+14);c.lineTo(mid+6,y+h+18);}
      c.stroke();
    }
    c.restore();
  }
  function drawMovingPlatform(c,p){if(!palettes[p.theme]&&!p.ice){base.drawMovingPlatform(c,p);return;}drawSnowPlatform(c,{...p,moving:true});}
  function drawEnemy(c,e){
    if(!['snowbug','frostcrab'].includes(e.kind)){base.drawEnemy(c,e);return;}
    const {x,y,w=38,h=24,time:t=0}=e,crab=e.kind==='frostcrab';
    c.save();c.translate(x+w/2,y+h);c.scale(w/38,h/24);c.strokeStyle='#6c949e';c.lineWidth=2;c.lineCap='round';
    for(const side of [-1,1])for(let i=0;i<3;i++){const wiggle=Math.sin(t*8+i)*2;c.beginPath();c.moveTo(side*10,-10+i*2);c.lineTo(side*(18+i),-5+i+wiggle);c.lineTo(side*(19+i),1+wiggle);c.stroke();}
    oval(c,0,-12,16,11,crab?'#dce9e8':'#8ebac5');oval(c,-5,-16,9,5,'#edf7ef');
    if(crab){
      for(const side of [-1,1]){c.beginPath();c.moveTo(side*12,-13);c.lineTo(side*22,-23);c.stroke();oval(c,side*22,-24,6,7,'#b3cdd8');polygon(c,[[side*18,-29],[side*19,-35],[side*23,-30],[side*27,-34],[side*27,-28]],'#e5f2ef');}
      for(let i=-12;i<=12;i+=6)polygon(c,[[i-4,-18],[i,-25],[i+5,-18]],'#edf5ee');
    }else{
      c.strokeStyle='#638d9a';c.beginPath();c.moveTo(0,-20);c.lineTo(0,-3);c.stroke();
      for(const side of [-1,1]){c.beginPath();c.moveTo(side*8,-18);c.lineTo(side*12,-29);c.stroke();crystal(c,side*12,-26,5,7,'#c1bedc');}
      sparkle(c,-6,-14,3,'#f4fff5');
    }
    for(const side of [-1,1]){oval(c,side*5,-20,3.7,4.5,'#f4f8e9');oval(c,side*5+(e.dir||1),-20,1.5,2,'#507482');}c.restore();
  }
  function drawProjectile(c,p){
    if(!['frostwave','icicle'].includes(p.kind)){base.drawProjectile(c,p);return;}
    const {x,y,w,h}=p;c.save();
    if(p.kind==='icicle'){
      polygon(c,[[x+w*.18,y],[x+w*.78,y],[x+w,y+h*.24],[x+w*.5,y+h],[x,y+h*.24]],'#9acbdc','#defbff');
      polygon(c,[[x+w*.5,y],[x+w*.78,y],[x+w,y+h*.24],[x+w*.5,y+h]],'#d5f1ec');
      c.strokeStyle='#eefdf8';c.lineWidth=1.5;c.beginPath();c.moveTo(x+w*.42,y+5);c.lineTo(x+w*.5,y+h*.79);c.stroke();
      c.globalAlpha=.4;c.strokeStyle='#c9e5f1';c.beginPath();c.moveTo(x+w*.25,y-15);c.lineTo(x+w*.25,y-4);c.moveTo(x+w*.75,y-25);c.lineTo(x+w*.75,y-8);c.stroke();
    }else{
      const dir=p.vx<0?-1:1;c.translate(x+w/2,y+h);c.scale(dir,1);
      c.fillStyle='#a2d6de';c.beginPath();c.moveTo(-w/2,0);c.quadraticCurveTo(-w*.45,-h*.66,w*.1,-h);c.quadraticCurveTo(w*.58,-h*.98,w*.42,-h*.47);c.quadraticCurveTo(w*.16,-h*.79,w*.06,-h*.3);c.quadraticCurveTo(w*.3,-h*.1,w/2,0);c.closePath();c.fill();
      c.strokeStyle='#edfff0';c.lineWidth=2.5;c.beginPath();c.moveTo(-w*.34,-3);c.quadraticCurveTo(-w*.18,-h*.84,w*.24,-h*.77);c.stroke();
      polygon(c,[[-w*.32,0],[-w*.23,-h*.35],[-w*.1,0]],'#def6ed');
    }c.restore();
  }
  function drawBoss(c,b){
    if(b.kind!=='bear'){base.drawBoss(c,b);return;}
    const {x,y,w=118,h=100,time:t=0,phase='idle',attackType='wave'}=b;
    const asleep=b.defeated||phase==='defeated',weak=phase==='recovery',warning=phase==='windup',floor=y+h;
    // Targets arrive from the engine as locked WORLD coordinates. They never
    // drift toward the player while the warning is displayed.
    if((warning||phase==='hail')&&attackType==='icicle'){
      c.save();const top=Number.isFinite(b.icicleSpawnY)?b.icicleSpawnY:210;
      for(const target of b.icicleTargets||[]){
        if(!Number.isFinite(target))continue;
        c.globalAlpha=warning?.9:.45;box(c,target-19,top,38,Math.max(1,floor-top),6,'#81e7f027');
        c.strokeStyle='#9debf3';c.lineWidth=2;c.setLineDash([5,8]);c.beginPath();c.moveTo(target,top+25);c.lineTo(target,floor-10);c.stroke();c.setLineDash([]);
        c.fillStyle='#73d9e853';c.beginPath();c.ellipse(target,floor-2,24,7,0,0,TAU);c.fill();c.strokeStyle='#68bdd0';c.lineWidth=2.5;c.stroke();
        c.beginPath();c.moveTo(target-7,top+14);c.lineTo(target,top+23);c.lineTo(target+7,top+14);c.strokeStyle='#638fa8';c.lineWidth=5;c.stroke();c.strokeStyle='#b3f5f7';c.lineWidth=2.5;c.stroke();
      }c.restore();
    }
    c.save();c.translate(x+w/2,floor);c.scale(w/118,h/100);
    oval(c,0,-1,64,8,'#213c5733');
    const lift=warning&&attackType==='wave'?-5:phase==='slam'?3:asleep?8:0;c.translate(0,lift);
    const fur=b.flash>0?'#fff0d2':asleep?'#d9e6e4':'#edf5ee',shade='#bfd5d9',edge='#7d9eab';
    for(const side of [-1,1]){oval(c,side*32,-11,21,12,shade);oval(c,side*32,-12,19,10,fur);for(let toe=0;toe<3;toe++){c.strokeStyle='#99b6bd';c.lineWidth=1;c.beginPath();c.moveTo(side*32-6+toe*6,-7);c.lineTo(side*32-6+toe*6,-3);c.stroke();}}
    oval(c,0,-46,48,42,shade);oval(c,-2,-48,44,39,fur);oval(c,1,-43,28,28,'#f8fbef');
    for(const side of [-1,1]){
      const raised=(warning&&attackType==='icicle')||phase==='hail',pawY=raised?-76:warning?-62:-39;
      oval(c,side*45,pawY,14,23,shade);oval(c,side*46-1,pawY-2,12,21,fur);
      if(raised){oval(c,side*47,pawY-6,6,8,'#c2d8d9');for(let toe=0;toe<3;toe++)oval(c,side*47-5+toe*5,pawY-17,2,3,'#c2d8d9');}
    }
    for(const side of [-1,1]){oval(c,side*27,-97,13,14,shade);oval(c,side*27,-99,10,10,fur);oval(c,side*27,-99,6,6,'#c4d7de');}
    oval(c,0,-79,37,29,shade);oval(c,-1,-81,35,28,fur);oval(c,1,-69,21,15,'#f9fbef');
    for(const side of [-1,1]){
      if(weak||asleep||phase==='hurt'){c.strokeStyle=edge;c.lineWidth=2;c.beginPath();c.arc(side*15,-82,5,0,Math.PI);c.stroke();}
      else {oval(c,side*15,-83,4,5,'#567687');oval(c,side*15-1,-85,1.2,1.6,'#f5fff5');}
      oval(c,side*25,-72,6,3,'#d1e7e2');
    }
    oval(c,1,-73,7,5,'#607e8c');c.strokeStyle='#87a5ad';c.lineWidth=1.5;c.beginPath();c.moveTo(1,-69);c.lineTo(1,-63);c.quadraticCurveTo(-5,-59,-9,-64);c.moveTo(1,-63);c.quadraticCurveTo(7,-59,11,-64);c.stroke();
    // Three translucent crown points echo the northern lights above the palace.
    polygon(c,[[-26,-107],[-29,-128],[-14,-119],[0,-139],[14,-119],[29,-129],[25,-107]],'#98d8c7','#d8ffea');
    polygon(c,[[0,-139],[14,-119],[29,-129],[25,-107],[0,-107]],'#bdb8dc80');box(c,-26,-110,52,7,3,'#c1e8d6');
    for(const [xx,yy] of [[-23,-125],[0,-135],[23,-125]])oval(c,xx,yy,3,3,'#f6ebc1');
    if(warning&&attackType==='wave'){
      c.strokeStyle='#f0d7aa';c.lineWidth=2;c.setLineDash([6,6]);c.beginPath();c.ellipse(0,-lift,92,12,0,0,TAU);c.stroke();c.setLineDash([]);
      for(const side of [-1,1]){c.beginPath();c.moveTo(side*77,-20-lift);c.lineTo(side*87,-12-lift);c.lineTo(side*78,-5-lift);c.stroke();}
      c.fillStyle='#ffe7b5';c.font='bold 21px sans-serif';c.textAlign='center';c.fillText('!',0,-157);
    }
    if(phase==='slam'){c.strokeStyle='#c7f7f1';c.lineWidth=3;c.beginPath();c.ellipse(0,0,99,16,0,Math.PI,TAU);c.stroke();}
    if(weak){c.strokeStyle='#ffe396';c.lineWidth=3;c.beginPath();c.ellipse(0,-149,36,9,0,0,TAU);c.stroke();sparkle(c,-44,-149,5,'#ffe396');sparkle(c,44,-149,5,'#ffe396');}
    if(asleep){c.fillStyle='#eef8e7';c.font='bold 17px sans-serif';c.textAlign='left';c.fillText('z Z',37,-109);}
    c.restore();
  }
  window.ForestArt=Object.freeze({...base,drawBackground,drawSnowTree,drawSnowPlatform,drawMovingPlatform,drawEnemy,drawProjectile,drawBoss});
})();
